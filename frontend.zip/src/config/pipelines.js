export const PIPELINE_TYPES = {
  SPEC_TO_CODE: 'spec-to-code',
  CODE_TO_CODE: 'code-to-code',
}

export const PIPELINES = {
  [PIPELINE_TYPES.SPEC_TO_CODE]: {
    id: 'spec-to-code',
    label: 'Spec-to-Code',
    description: 'Upload your spec directly — modernize from spec',
    steps: ['Data Loading', 'Modernization', 'Reflection'],
    stepDescriptions: [
      'Loading uploaded specification into workspace...',
      'Transforming specification into modernized code...',
      'Reviewing and validating the generated code...',
    ],
    promptKeys: ['spec', 'modernize', 'reflect'],
    promptLabels: ['Data Loading', 'Modernization', 'Reflection'],
    defaultPrompts: {
      spec: 'Review the uploaded specification documents and confirm all business logic, data structures, workflows, and integrations are captured.',
      modernize:
        'Using the specification document, generate modernized code in the target language following best practices, design patterns, and production-ready standards.',
      reflect:
        'Review the generated modern code against the original specification. Identify any gaps, inconsistencies, or improvements needed. Suggest corrections.',
    },
  },
  [PIPELINE_TYPES.CODE_TO_CODE]: {
    id: 'code-to-code',
    label: 'Code-to-Code',
    description: 'Analyze source code directly, then modernize',
    steps: ['Analysis', 'Modernization', 'Reflection'],
    stepDescriptions: [
      'Performing deep analysis of source code structure and patterns...',
      'Directly transforming analyzed code into modernized target language...',
      'Reviewing and validating the generated code...',
    ],
    promptKeys: ['analysis', 'modernize', 'reflect'],
    promptLabels: ['Analysis', 'Modernization', 'Reflection'],
    defaultPrompts: {
      analysis:
        'Analyze the provided source code to understand its structure, patterns, dependencies, and control flow. Identify key components and their relationships.',
      modernize:
        'Using the analysis, directly transform the source code into the target language following best practices, design patterns, and production-ready standards.',
      reflect:
        'Review the generated modern code against the original source. Identify any gaps, inconsistencies, or improvements needed. Suggest corrections.',
    },
  },
}

export const getPipeline = (type) =>
  PIPELINES[type] || PIPELINES[PIPELINE_TYPES.SPEC_TO_CODE]

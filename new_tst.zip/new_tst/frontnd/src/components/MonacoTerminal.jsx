import { useState, useEffect, useRef, useMemo, useCallback } from 'react'
import Editor from '@monaco-editor/react'

// ── Helpers ──────────────────────────────────────────────────────────────────

/** Map file extension → Monaco language id */
function detectLanguage(filepath) {
  if (!filepath) return 'plaintext'
  const ext = filepath.split('.').pop().toLowerCase()
  const map = {
    py: 'python', js: 'javascript', jsx: 'javascript',
    ts: 'typescript', tsx: 'typescript', java: 'java',
    kt: 'kotlin', html: 'html', htm: 'html', css: 'css',
    json: 'json', md: 'markdown', xml: 'xml', yaml: 'yaml',
    yml: 'yaml', sql: 'sql', sh: 'shell', bat: 'bat',
    txt: 'plaintext', log: 'plaintext', gradle: 'groovy',
    properties: 'ini', cfg: 'ini',
  }
  return map[ext] || 'plaintext'
}

/** Group file paths by their top-level directory (specs, target_codebase, validation) — excludes output.txt */
function groupByDir(files) {
  const groups = {}
  for (const [path] of files) {
    // Skip output.txt — shown in the summary div, not in the editor file tree
    if (path.split('/').pop() === 'output.txt') continue
    const topDir = path.split('/')[0]
    if (!groups[topDir]) groups[topDir] = []
    groups[topDir].push(path)
  }
  return groups
}

/** Extract output.txt content keyed by directory */
function extractSummaries(files) {
  const summaries = {}
  for (const [path, content] of files) {
    const parts = path.split('/')
    if (parts[parts.length - 1] === 'output.txt') {
      summaries[parts[0]] = content
    }
  }
  return summaries
}

/** Pretty label for a directory tab */
function dirLabel(dir) {
  const labels = {
    specs: 'Specs',
    target_codebase: 'Generated Code',
    validation: 'Validation',
  }
  return labels[dir] || dir
}

// ── Summary Banner ──────────────────────────────────────────────────────────

function SummaryBanner({ content, dirName }) {
  const [collapsed, setCollapsed] = useState(false)

  if (!content) return null

  return (
    <div className="border-b border-gray-700/50 bg-gradient-to-r from-indigo-950/40 via-[#1a1b26] to-[#1a1b26]" data-testid={`summary-banner-${dirName}`}>
      <button
        onClick={() => setCollapsed(prev => !prev)}
        className="w-full flex items-center gap-2.5 px-4 py-2.5 text-left hover:bg-white/[0.02] transition-colors"
      >
        {/* Icon */}
        <div className="w-6 h-6 rounded-md bg-indigo-500/20 flex items-center justify-center flex-shrink-0">
          <svg className="w-3.5 h-3.5 text-indigo-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
          </svg>
        </div>
        <span className="text-xs font-semibold text-indigo-300 tracking-wide uppercase">
          {dirLabel(dirName)} — Summary
        </span>
        <svg className={`w-3.5 h-3.5 text-gray-500 ml-auto transition-transform duration-200 ${collapsed ? '-rotate-90' : 'rotate-0'}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
        </svg>
      </button>
      {!collapsed && (
        <div className="px-4 pb-3">
          <pre className="text-xs text-gray-300 font-mono leading-relaxed whitespace-pre-wrap bg-black/20 rounded-lg px-3.5 py-2.5 border border-gray-700/30 max-h-40 overflow-y-auto">
            {content.trim()}
          </pre>
        </div>
      )}
    </div>
  )
}

// ── File Tree Sidebar ───────────────────────────────────────────────────────

function FileTree({ files, selected, onSelect }) {
  if (files.length === 0) return null
  return (
    <div className="w-52 flex-shrink-0 border-r border-gray-700/50 bg-[#1a1b26] overflow-y-auto">
      <div className="px-3 py-2 text-[10px] font-semibold text-gray-500 uppercase tracking-widest border-b border-gray-700/50">
        Files
      </div>
      <ul className="py-1">
        {files.map((path) => {
          const basename = path.split('/').pop()
          const isActive = path === selected
          return (
            <li key={path}>
              <button
                onClick={() => onSelect(path)}
                className={`w-full text-left px-3 py-1.5 text-xs font-mono truncate transition-colors flex items-center gap-1.5 ${
                  isActive
                    ? 'bg-blue-600/20 text-blue-300 border-l-2 border-blue-400'
                    : 'text-gray-400 hover:bg-white/5 hover:text-gray-200 border-l-2 border-transparent'
                }`}
                title={path}
              >
                <svg className="w-3.5 h-3.5 flex-shrink-0 opacity-60" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                </svg>
                {basename}
              </button>
            </li>
          )
        })}
      </ul>
    </div>
  )
}

// ── Monaco Terminal Component ───────────────────────────────────────────────

/**
 * MonacoTerminal — displays real-time streaming output from the deep agent.
 *
 * Props:
 *   fileContents: Map<string, string>  — { "specs/output.txt": "...", "specs/specification.md": "...", ... }
 *   activeSubagent: string | null      — currently running subagent name
 *   activeTab: string | null           — externally controlled active tab (directory name)
 *   onTabChange: (dir: string) => void — callback when user switches tab
 *   readOnly: boolean                  — if true, no editing allowed (default true)
 *   height: string                     — CSS height for the editor (default "450px")
 */
export default function MonacoTerminal({
  fileContents = new Map(),
  activeSubagent = null,
  activeTab = null,
  onTabChange,
  readOnly = true,
  height = '450px',
}) {
  const editorRef = useRef(null)
  const [internalTab, setInternalTab] = useState(null)
  const [selectedFile, setSelectedFile] = useState(null)

  // Group non-output.txt files into directory tabs
  const grouped = useMemo(() => groupByDir(fileContents), [fileContents])

  // Extract output.txt summaries per directory
  const summaries = useMemo(() => extractSummaries(fileContents), [fileContents])

  // Build tabs: include dirs that have either files OR summaries
  const tabs = useMemo(() => {
    const allDirs = new Set([...Object.keys(grouped), ...Object.keys(summaries)])
    return [...allDirs].sort()
  }, [grouped, summaries])

  // Effective active tab: external control takes priority
  const effectiveTab = activeTab && tabs.includes(activeTab) ? activeTab : (internalTab && tabs.includes(internalTab) ? internalTab : tabs[0] || null)

  // Files in the current tab (excluding output.txt)
  const currentFiles = useMemo(() => effectiveTab ? (grouped[effectiveTab] || []) : [], [grouped, effectiveTab])

  // Summary for the current tab
  const currentSummary = effectiveTab ? (summaries[effectiveTab] || null) : null

  // Auto-select first file when tab changes or when files arrive
  useEffect(() => {
    if (currentFiles.length > 0) {
      if (!selectedFile || !currentFiles.includes(selectedFile)) {
        setSelectedFile(currentFiles[0])
      }
    } else {
      setSelectedFile(null)
    }
  }, [currentFiles, selectedFile])

  // Auto-scroll to bottom when content changes
  const currentContent = selectedFile ? (fileContents.get(selectedFile) || '') : ''
  useEffect(() => {
    if (editorRef.current) {
      const model = editorRef.current.getModel()
      if (model) {
        const lineCount = model.getLineCount()
        editorRef.current.revealLine(lineCount)
      }
    }
  }, [currentContent])

  const handleEditorDidMount = useCallback((editor) => {
    editorRef.current = editor
  }, [])

  const handleTabClick = useCallback((dir) => {
    setInternalTab(dir)
    setSelectedFile(null) // reset file selection, will auto-select first
    if (onTabChange) onTabChange(dir)
  }, [onTabChange])

  const language = detectLanguage(selectedFile)

  // Determine which tab is "live" (receiving updates)
  const liveDir = useMemo(() => {
    if (!activeSubagent) return null
    const mapping = {
      spec_generator: 'specs',
      code_generator: 'target_codebase',
      code_translator: 'target_codebase',
      validator: 'validation',
    }
    return mapping[activeSubagent] || null
  }, [activeSubagent])

  if (tabs.length === 0) {
    return (
      <div
        className="rounded-xl border border-gray-700/50 bg-[#1a1b26] overflow-hidden"
        style={{ height }}
        data-testid="monaco-terminal-empty"
      >
        <div className="h-full flex items-center justify-center">
          <div className="text-center space-y-3">
            <div className="w-10 h-10 rounded-full bg-gray-800 flex items-center justify-center mx-auto">
              <svg className="w-5 h-5 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M8 9l3 3-3 3m5 0h3M5 20h14a2 2 0 002-2V6a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
              </svg>
            </div>
            <p className="text-gray-500 text-sm">Waiting for output…</p>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div
      className="rounded-xl border border-gray-700/50 bg-[#1a1b26] overflow-hidden shadow-2xl shadow-black/20"
      data-testid="monaco-terminal"
    >
      {/* ── Tab bar ─────────────────────────────────────────────────── */}
      <div className="flex items-center border-b border-gray-700/50 bg-[#13141c]">
        {tabs.map((dir) => {
          const isActive = dir === effectiveTab
          const isLive = dir === liveDir
          const fileCount = (grouped[dir] || []).length
          return (
            <button
              key={dir}
              onClick={() => handleTabClick(dir)}
              className={`relative px-5 py-2.5 text-xs font-medium transition-all duration-200 flex items-center gap-2 border-b-2 ${
                isActive
                  ? 'text-blue-300 border-blue-400 bg-[#1a1b26]'
                  : 'text-gray-500 border-transparent hover:text-gray-300 hover:bg-white/[0.03]'
              }`}
              data-testid={`tab-${dir}`}
            >
              {isLive && (
                <span className="relative flex h-2 w-2">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75" />
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-green-500" />
                </span>
              )}
              {dirLabel(dir)}
              {fileCount > 0 && (
                <span className="ml-1 text-[10px] text-gray-600 tabular-nums">
                  {fileCount}
                </span>
              )}
            </button>
          )
        })}

        {/* Right-side info */}
        <div className="ml-auto pr-4 flex items-center gap-2">
          {activeSubagent && (
            <span className="text-[10px] text-gray-500 font-mono flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse" />
              {activeSubagent}
            </span>
          )}
        </div>
      </div>

      {/* ── Summary banner (output.txt) ──────────────────────────────── */}
      <SummaryBanner content={currentSummary} dirName={effectiveTab} />

      {/* ── Content area: file tree + editor ──────────────────────── */}
      {currentFiles.length > 0 ? (
        <div className="flex" style={{ height }}>
          {/* File tree — shown when there are multiple files in the tab */}
          {currentFiles.length > 1 && (
            <FileTree
              files={currentFiles}
              selected={selectedFile}
              onSelect={setSelectedFile}
            />
          )}

          {/* Monaco editor */}
          <div className="flex-1 min-w-0">
            <Editor
              height={height}
              language={language}
              value={currentContent}
              theme="vs-dark"
              onMount={handleEditorDidMount}
              options={{
                readOnly,
                minimap: { enabled: currentContent.length > 2000 },
                scrollBeyondLastLine: false,
                wordWrap: 'on',
                fontSize: 13,
                fontFamily: "'JetBrains Mono', 'Fira Code', 'Cascadia Code', Consolas, monospace",
                lineNumbers: 'on',
                renderLineHighlight: 'gutter',
                smoothScrolling: true,
                padding: { top: 12, bottom: 12 },
                domReadOnly: readOnly,
                contextmenu: false,
                scrollbar: {
                  verticalScrollbarSize: 8,
                  horizontalScrollbarSize: 8,
                },
              }}
            />
          </div>
        </div>
      ) : (
        /* When only output.txt exists (no other files yet) — show a placeholder */
        <div className="flex items-center justify-center text-gray-500 text-sm" style={{ height: '120px' }}>
          {currentSummary ? 'See summary above — additional files will appear here.' : 'Waiting for files…'}
        </div>
      )}
    </div>
  )
}

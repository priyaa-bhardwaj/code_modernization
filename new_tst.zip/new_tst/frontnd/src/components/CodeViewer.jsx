import { useState, useMemo } from 'react'
import { Prism as SyntaxHighlighter } from 'react-syntax-highlighter'
import { vscDarkPlus } from 'react-syntax-highlighter/dist/esm/styles/prism'

// Map file extension to language identifier for syntax highlighting
function detectLanguage(filename) {
  if (!filename) return 'text'
  const ext = filename.split('.').pop().toLowerCase()
  const map = {
    py: 'python',
    js: 'javascript',
    jsx: 'javascript',
    ts: 'typescript',
    tsx: 'typescript',
    java: 'java',
    html: 'html',
    htm: 'html',
    css: 'css',
    json: 'json',
    md: 'markdown',
    markdown: 'markdown',
  }
  return map[ext] || 'text'
}

// Parse subagent output into a list of { path, content } file entries
function parseFiles(content) {
  if (!content) return [{ path: 'output.txt', content: '' }]

  // Match lines like: // FILE: path/to/file.ext  or  ### FILE: path/to/file.ext
  const splitRegex = /^(?:\/\/|###)\s*FILE:\s*.+$/gm

  const markers = [...content.matchAll(/^(?:\/\/|###)\s*FILE:\s*(.+)$/gm)]

  if (markers.length === 0) {
    return [{ path: 'output.txt', content }]
  }

  const files = []
  const parts = content.split(splitRegex)
  // parts[0] is content before the first marker (ignored), parts[1..n] are file contents
  markers.forEach((match, i) => {
    const path = match[1].trim()
    const fileContent = (parts[i + 1] || '').replace(/^\n/, '').replace(/\n$/, '')
    files.push({ path, content: fileContent })
  })

  return files
}

export default function CodeViewer({ content }) {
  const files = useMemo(() => parseFiles(content), [content])
  const [selectedPath, setSelectedPath] = useState(() => files[0]?.path || '')

  // If files change (new content), reset selection to first file
  const currentFiles = files
  const effectiveSelected = currentFiles.find(f => f.path === selectedPath)
    ? selectedPath
    : currentFiles[0]?.path || ''

  const selectedFile = currentFiles.find(f => f.path === effectiveSelected)
  const language = detectLanguage(effectiveSelected)

  return (
    <div className="flex border border-gray-200 dark:border-gray-700 rounded-lg overflow-hidden bg-white dark:bg-gray-900" style={{ minHeight: '300px' }} data-testid="code-viewer">
      {/* File tree sidebar */}
      <div className="w-56 flex-shrink-0 border-r border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-950 overflow-y-auto" data-testid="file-tree">
        <div className="px-3 py-2 text-xs font-semibold text-gray-500 dark:text-gray-500 uppercase tracking-wider border-b border-gray-200 dark:border-gray-800">
          Files
        </div>
        <ul>
          {currentFiles.map((file) => (
            <li key={file.path}>
              <button
                onClick={() => setSelectedPath(file.path)}
                className={`w-full text-left px-3 py-2 text-xs font-mono truncate transition-colors ${
                  file.path === effectiveSelected
                    ? 'bg-blue-100 dark:bg-blue-900/50 text-blue-700 dark:text-blue-300'
                    : 'text-gray-600 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-800 hover:text-gray-900 dark:hover:text-gray-200'
                }`}
                title={file.path}
                data-testid={`file-tree-item-${file.path}`}
              >
                {file.path}
              </button>
            </li>
          ))}
        </ul>
      </div>

      {/* Code panel */}
      <div className="flex-1 overflow-auto" data-testid="code-panel">
        {selectedFile ? (
          <SyntaxHighlighter
            language={language}
            style={vscDarkPlus}
            customStyle={{ margin: 0, borderRadius: 0, minHeight: '100%', fontSize: '0.8rem' }}
            showLineNumbers
            data-testid="syntax-highlighter"
          >
            {selectedFile.content}
          </SyntaxHighlighter>
        ) : (
          <div className="p-4 text-gray-500 text-sm">No file selected.</div>
        )}
      </div>
    </div>
  )
}

export default function Card({ from_code, to_code, description, onClick }) {
  return (
    <div
      onClick={onClick}
      className="cursor-pointer rounded-xl bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 p-6 hover:border-indigo-500 transition-colors duration-200 flex flex-col gap-2"
    >
      <div className="flex items-center gap-2 text-lg font-semibold text-gray-900 dark:text-white">
        <span>{from_code}</span>
        <span className="text-indigo-400">→</span>
        <span>{to_code}</span>
      </div>
      <p className="text-gray-600 dark:text-gray-400 text-sm">{description}</p>
    </div>
  )
}

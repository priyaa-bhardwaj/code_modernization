import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import Card from '../components/Card'

export default function Homepage() {
  const [cards, setCards] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const navigate = useNavigate()

  useEffect(() => {
    fetch('/api/cards')
      .then(res => {
        if (!res.ok) throw new Error('Failed to load pathways')
        return res.json()
      })
      .then(data => {
        setCards(data)
        setLoading(false)
      })
      .catch(() => {
        setError('Unable to load modernization pathways. Please try again later.')
        setLoading(false)
      })
  }, [])

  function handleCardClick(from_code, to_code) {
    navigate(`/config?from=${encodeURIComponent(from_code)}&to=${encodeURIComponent(to_code)}`)
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-950 text-gray-900 dark:text-white flex items-center justify-center">
        <p className="text-gray-600 dark:text-gray-400 text-lg">Loading pathways...</p>
      </div>
    )
  }

  if (error) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-950 text-gray-900 dark:text-white flex items-center justify-center">
        <p className="text-red-400 text-lg">{error}</p>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-950 text-gray-900 dark:text-white p-8">
      <h1 className="text-2xl font-bold mb-6">Select a Modernization Pathway</h1>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {cards.map((card, i) => (
          <Card
            key={i}
            from_code={card.from_code}
            to_code={card.to_code}
            description={card.description}
            onClick={() => handleCardClick(card.from_code, card.to_code)}
          />
        ))}
      </div>
    </div>
  )
}

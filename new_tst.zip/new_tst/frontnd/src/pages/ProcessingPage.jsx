import { useParams } from 'react-router-dom'
import { useState, useEffect, useRef, useCallback } from 'react'
import { useNavigate } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'
import MonacoTerminal from '../components/MonacoTerminal'

const STATUS = {
  INACTIVE: 'inactive',
  ACTIVE: 'active',
  PENDING: 'pending',
  COMPLETED: 'completed',
}

// ── Horizontal stepper ────────────────────────────────────────────────────────
function StepCircle({ status, index, label, onClick, isSelected, pipelineComplete }) {
  const circleBase = 'w-10 h-10 rounded-full flex items-center justify-center text-sm font-bold transition-all duration-500 z-10 relative'

  const circleStyle = {
    [STATUS.INACTIVE]: 'bg-gray-200 dark:bg-gray-700 text-gray-500 dark:text-gray-400',
    [STATUS.ACTIVE]:   'bg-blue-500 text-white shadow-lg shadow-blue-500/40',
    [STATUS.PENDING]:  'bg-yellow-400 text-white shadow-lg shadow-yellow-400/40',
    [STATUS.COMPLETED]:'bg-green-500 text-white shadow-lg shadow-green-500/40',
  }

  const labelStyle = {
    [STATUS.INACTIVE]: 'text-gray-400 dark:text-gray-500',
    [STATUS.ACTIVE]:   'text-blue-600 dark:text-blue-400 font-semibold',
    [STATUS.PENDING]:  'text-yellow-600 dark:text-yellow-400 font-semibold',
    [STATUS.COMPLETED]:'text-green-600 dark:text-green-400 font-semibold',
  }

  const isClickable = pipelineComplete && status === STATUS.COMPLETED

  return (
    <div
      className={`flex flex-col items-center gap-2 ${isClickable ? 'cursor-pointer group' : ''}`}
      onClick={isClickable ? onClick : undefined}
      data-testid={`status-indicator-${index}`}
      data-status={status}
    >
      <div className={`${circleBase} ${circleStyle[status]} ${isClickable ? 'ring-2 ring-offset-2 ring-offset-white dark:ring-offset-gray-900 ring-transparent group-hover:ring-green-400 transition-all' : ''} ${isSelected ? 'ring-green-500' : ''}`}>
        {status === STATUS.ACTIVE && (
          <span className="w-5 h-5 rounded-full border-2 border-white border-t-transparent animate-spin" />
        )}
        {status === STATUS.COMPLETED && (
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
          </svg>
        )}
        {status === STATUS.PENDING && (
          <span className="w-2.5 h-2.5 rounded-full bg-white animate-pulse" />
        )}
        {status === STATUS.INACTIVE && (
          <span className="text-xs">{index + 1}</span>
        )}
      </div>
      <span className={`text-xs text-center max-w-[80px] truncate ${labelStyle[status]}`}>
        {label || `Step ${index + 1}`}
      </span>
      {isClickable && (
        <span className="text-xs text-green-500 dark:text-green-400 opacity-0 group-hover:opacity-100 transition-opacity -mt-1">view</span>
      )}
    </div>
  )
}

function Stepper({ indicators, onStepClick, selectedStep, pipelineComplete }) {
  if (indicators.length === 0) return null

  return (
    <div className="w-full overflow-x-auto pb-2" data-testid="indicators-container">
      <div className="flex items-start min-w-max mx-auto px-4">
        {indicators.map((ind, i) => (
          <div key={i} className="flex items-center">
            <StepCircle
              status={ind.status}
              index={i}
              label={ind.label}
              onClick={() => onStepClick(i)}
              isSelected={selectedStep === i}
              pipelineComplete={pipelineComplete}
            />
            {i < indicators.length - 1 && (
              <div className={`h-0.5 w-16 mx-1 mt-[-18px] transition-colors duration-500 ${
                indicators[i].status === STATUS.COMPLETED
                  ? 'bg-green-400'
                  : 'bg-gray-200 dark:bg-gray-700'
              }`} />
            )}
          </div>
        ))}
      </div>
    </div>
  )
}

// ── Subagent → tab directory mapping ──────────────────────────────────────────
const SUBAGENT_DIR_MAP = {
  spec_generator: 'specs',
  code_generator: 'target_codebase',
  code_translator: 'target_codebase',
  validator: 'validation',
}

// ── Main page ─────────────────────────────────────────────────────────────────
export default function ProcessingPage() {
  const { jobId } = useParams()
  const navigate = useNavigate()
  const { authFetch } = useAuth()

  const [indicators, setIndicators] = useState([])
  const [activeLabel, setActiveLabel] = useState(null)
  const [currentOutput, setCurrentOutput] = useState('')
  const [currentIndex, setCurrentIndex] = useState(null)
  const [pipelineComplete, setPipelineComplete] = useState(false)
  const [connectionError, setConnectionError] = useState(false)
  const [approving, setApproving] = useState(false)
  const [approveError, setApproveError] = useState('')

  // History: map of step index -> { label, output }
  const [outputHistory, setOutputHistory] = useState({})
  // Which completed step is selected for read-only view (null = none)
  const [selectedHistoryStep, setSelectedHistoryStep] = useState(null)

  // ── Monaco terminal state ──────────────────────────────────
  // Map of file path -> content, e.g. { "specs/output.txt": "...", "target_codebase/Main.java": "..." }
  const [fileContents, setFileContents] = useState(new Map())
  const [activeMonacoTab, setActiveMonacoTab] = useState(null)

  const eventSourceRef = useRef(null)

  const ensureIndicators = useCallback((minLength, updates = {}) => {
    setIndicators(prev => {
      const next = [...prev]
      while (next.length < minLength) {
        next.push({ status: STATUS.INACTIVE, label: null })
      }
      Object.entries(updates).forEach(([idx, patch]) => {
        next[Number(idx)] = { ...next[Number(idx)], ...patch }
      })
      return next
    })
  }, [])

  // ── Fetch existing files on mount (for reconnection) ───────
  useEffect(() => {
    async function loadExistingFiles() {
      try {
        const res = await authFetch(`/api/jobs/${jobId}/files`)
        if (!res.ok) return
        const data = await res.json()
        if (!data.files || data.files.length === 0) return

        // Fetch each file's content
        const newMap = new Map()
        await Promise.all(
          data.files.map(async (f) => {
            try {
              const fRes = await authFetch(`/api/jobs/${jobId}/files?path=${encodeURIComponent(f.path)}`)
              if (fRes.ok) {
                const fData = await fRes.json()
                newMap.set(f.path, fData.content)
              }
            } catch { /* skip */ }
          })
        )
        if (newMap.size > 0) {
          setFileContents(prev => {
            const merged = new Map(prev)
            for (const [k, v] of newMap) merged.set(k, v)
            return merged
          })
        }
      } catch { /* ignore */ }
    }
    loadExistingFiles()
  }, [jobId, authFetch])

  // ── SSE connection ─────────────────────────────────────────
  const openEventSource = useCallback(() => {
    if (eventSourceRef.current) eventSourceRef.current.close()
    setConnectionError(false)

    const stored = localStorage.getItem('auth_user')
    const token = stored ? JSON.parse(stored).token : null
    const url = token
      ? `/api/jobs/${jobId}/stream?token=${encodeURIComponent(token)}`
      : `/api/jobs/${jobId}/stream`
    const es = new EventSource(url)
    eventSourceRef.current = es

    es.addEventListener('subagent_started', (e) => {
      const data = JSON.parse(e.data)
      const idx = data.index
      setActiveLabel(data.subagent)
      ensureIndicators(idx + 1, { [idx]: { status: STATUS.ACTIVE, label: data.subagent } })

      // Auto-switch Monaco tab to the relevant directory
      const dir = SUBAGENT_DIR_MAP[data.subagent]
      if (dir) setActiveMonacoTab(dir)
    })

    // ── Real-time file change events ───────────────────────────
    es.addEventListener('file_changed', (e) => {
      const data = JSON.parse(e.data)
      setFileContents(prev => {
        const next = new Map(prev)
        next.set(data.path, data.content)
        return next
      })
    })

    es.addEventListener('interrupt', (e) => {
      const data = JSON.parse(e.data)
      const idx = data.index
      setActiveLabel(null)
      ensureIndicators(idx + 1, { [idx]: { status: STATUS.PENDING, label: data.subagent } })
      setCurrentOutput(data.output || '')
      setCurrentIndex(idx)
      setApproveError('')
      // Store in history for later review
      setOutputHistory(prev => ({ ...prev, [idx]: { label: data.subagent, output: data.output || '' } }))
    })

    es.addEventListener('pipeline_complete', () => {
      setActiveLabel(null)
      setPipelineComplete(true)
      setCurrentIndex(null)
      setSelectedHistoryStep(null)
      es.close()
    })

    es.addEventListener('error', (e) => {
      try {
        const data = JSON.parse(e.data)
        setApproveError(data.message || 'Pipeline error occurred.')
      } catch { /* handled by onerror */ }
    })

    es.onerror = () => {
      // Only show connection error if we haven't completed the pipeline
      // and the error persists (EventSource will auto-retry a few times)
      setConnectionError(true)
      es.close()
    }
  }, [jobId, ensureIndicators])

  useEffect(() => {
    openEventSource()
    return () => eventSourceRef.current?.close()
  }, [openEventSource])

  async function handleApprove() {
    if (currentIndex === null) return
    setApproving(true)
    setApproveError('')
    try {
      const res = await authFetch(`/api/jobs/${jobId}/feedback`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ feedback: currentOutput }),
      })

      if (!res.ok) {
        const body = await res.json().catch(() => ({}))
        setApproveError(body.error || `Request failed (${res.status})`)
        return
      }

      // Mark current step completed, clear output panel
      setIndicators(prev => {
        const next = [...prev]
        if (next[currentIndex]) next[currentIndex] = { ...next[currentIndex], status: STATUS.COMPLETED }
        return next
      })
      setCurrentIndex(null)
      setCurrentOutput('')
    } catch (err) {
      setApproveError(err.message || 'Network error')
    } finally {
      setApproving(false)
    }
  }

  const currentLabel = currentIndex !== null ? (indicators[currentIndex]?.label || `Step ${currentIndex + 1}`) : null

  function handleStepClick(i) {
    if (!pipelineComplete) return
    setSelectedHistoryStep(prev => prev === i ? null : i)
  }

  const historyEntry = selectedHistoryStep !== null ? outputHistory[selectedHistoryStep] : null

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-950 text-gray-900 dark:text-white">
      <div className="max-w-6xl mx-auto px-6 py-8 space-y-6">

        {/* Header */}
        <div>
          <button
            onClick={() => navigate('/')}
            className="inline-flex items-center gap-1.5 text-sm text-gray-500 dark:text-gray-400 hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors mb-3"
          >
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
            </svg>
            Back to Home
          </button>
          <h1 className="text-2xl font-bold mb-1">Processing Job</h1>
          <p className="text-gray-400 text-xs font-mono">{jobId}</p>
        </div>

        {/* Connection error */}
        {connectionError && (
          <div className="bg-red-50 dark:bg-red-900/40 border border-red-300 dark:border-red-500 rounded-lg p-4 flex items-center justify-between" data-testid="connection-error">
            <span className="text-red-600 dark:text-red-300 text-sm">Connection lost.</span>
            <button onClick={openEventSource} className="ml-4 px-4 py-1.5 bg-red-600 hover:bg-red-500 text-white rounded-md text-sm font-medium transition-colors" data-testid="reconnect-button">
              Reconnect
            </button>
          </div>
        )}

        {/* Horizontal stepper */}
        <div className="bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-xl p-6">
          {indicators.length === 0 ? (
            <p className="text-center text-gray-400 text-sm">Connecting to pipeline…</p>
          ) : (
            <Stepper
              indicators={indicators}
              onStepClick={handleStepClick}
              selectedStep={selectedHistoryStep}
              pipelineComplete={pipelineComplete}
            />
          )}
          {pipelineComplete && indicators.length > 0 && (
            <p className="text-center text-xs text-gray-400 dark:text-gray-500 mt-3">Click a completed step to review its output</p>
          )}
        </div>

        {/* ── Monaco Output Terminal (always visible during execution) ──── */}
        <div className="space-y-2">
          <div className="flex items-center gap-2">
            <svg className="w-4 h-4 text-gray-500 dark:text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M8 9l3 3-3 3m5 0h3M5 20h14a2 2 0 002-2V6a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
            </svg>
            <h2 className="text-sm font-semibold text-gray-600 dark:text-gray-300">Output Terminal</h2>
            {activeLabel && (
              <span className="ml-2 inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[10px] font-medium bg-green-500/10 text-green-400 border border-green-500/20">
                <span className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse" />
                Live — {activeLabel}
              </span>
            )}
          </div>
          <MonacoTerminal
            fileContents={fileContents}
            activeSubagent={activeLabel}
            activeTab={activeMonacoTab}
            onTabChange={setActiveMonacoTab}
            readOnly={true}
            height="450px"
          />
        </div>

        {/* ── Read-only history panel — shown when a completed step is clicked after pipeline finishes */}
        {historyEntry && (
          <div className="space-y-4 bg-white dark:bg-gray-900 border border-green-200 dark:border-green-800 rounded-xl p-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <svg className="w-4 h-4 text-green-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M5 13l4 4L19 7" />
                </svg>
                <h2 className="text-base font-semibold text-green-700 dark:text-green-300">
                  <span className="font-mono">{historyEntry.label}</span> — output
                </h2>
              </div>
              <button
                onClick={() => setSelectedHistoryStep(null)}
                className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-200 transition-colors"
                aria-label="Close"
              >
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            </div>
            <textarea
              readOnly
              className="w-full h-48 bg-gray-50 dark:bg-gray-950 border border-gray-200 dark:border-gray-700 rounded-lg p-4 text-sm text-gray-900 dark:text-gray-100 font-mono resize-y focus:outline-none cursor-default"
              value={historyEntry.output}
            />
          </div>
        )}

        {/* ── Interrupt / Approval panel — shown when awaiting human feedback */}
        {currentIndex !== null && (
          <div className="space-y-4 bg-white dark:bg-gray-900 border border-yellow-200 dark:border-yellow-800/50 rounded-xl p-6" data-testid="interrupt-panel">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-yellow-400 animate-pulse" />
              <h2 className="text-base font-semibold text-yellow-600 dark:text-yellow-300">
                Awaiting Approval — <span className="font-mono">{currentLabel}</span>
              </h2>
            </div>

            <p className="text-sm text-gray-500 dark:text-gray-400">
              The <span className="font-mono text-gray-700 dark:text-gray-300">{currentLabel}</span> subagent has finished.
              Review the output in the terminal above, then approve to continue to the next step.
            </p>

            {/* Editable feedback textarea */}
            <div className="space-y-1">
              <label className="text-xs font-medium text-gray-500 dark:text-gray-400">
                Optional feedback (edits will be passed to the next subagent):
              </label>
              <textarea
                className="w-full h-24 bg-gray-50 dark:bg-gray-950 border border-gray-200 dark:border-gray-700 rounded-lg p-3 text-sm text-gray-900 dark:text-gray-100 font-mono resize-y focus:outline-none focus:border-blue-500 transition-colors"
                value={currentOutput}
                onChange={(e) => setCurrentOutput(e.target.value)}
                placeholder="Add feedback or edits here… (leave empty to approve as-is)"
                data-testid="output-textarea"
              />
            </div>

            {approveError && (
              <p className="text-red-400 text-sm" data-testid="approve-error">{approveError}</p>
            )}

            <button
              onClick={handleApprove}
              disabled={approving}
              className="px-6 py-2.5 bg-green-600 hover:bg-green-500 disabled:opacity-50 disabled:cursor-not-allowed text-white rounded-lg font-medium transition-colors flex items-center gap-2 shadow-lg shadow-green-600/20"
              data-testid="approve-button"
            >
              {approving ? (
                <>
                  <span className="w-4 h-4 rounded-full border-2 border-white border-t-transparent animate-spin" />
                  Approving…
                </>
              ) : (
                <>
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M5 13l4 4L19 7" />
                  </svg>
                  Approve & Continue
                </>
              )}
            </button>
          </div>
        )}

        {/* Pipeline complete */}
        {pipelineComplete && (
          <div className="bg-green-50 dark:bg-green-900/20 border border-green-300 dark:border-green-700 rounded-xl p-8 text-center space-y-4" data-testid="pipeline-complete-panel">
            <div className="w-14 h-14 rounded-full bg-green-500 flex items-center justify-center mx-auto shadow-lg shadow-green-500/30">
              <svg className="w-7 h-7 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
              </svg>
            </div>
            <p className="text-green-700 dark:text-green-300 text-lg font-semibold">Pipeline complete!</p>
            <button
              onClick={() => {
                const stored = localStorage.getItem('auth_user')
                const token = stored ? JSON.parse(stored).token : null
                window.location.href = token
                  ? `/api/jobs/${jobId}/download?token=${encodeURIComponent(token)}`
                  : `/api/jobs/${jobId}/download`
              }}
              className="px-8 py-3 bg-blue-600 hover:bg-blue-500 text-white rounded-lg font-medium transition-colors inline-flex items-center gap-2"
              data-testid="download-button"
            >
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
              </svg>
              Download Workspace
            </button>
          </div>
        )}

      </div>
    </div>
  )
}

import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'

const STATUS_STYLE = {
  pending:           'bg-gray-100 dark:bg-gray-800 text-gray-500 dark:text-gray-400',
  running:           'bg-blue-100 dark:bg-blue-900/40 text-blue-600 dark:text-blue-300',
  awaiting_feedback: 'bg-yellow-100 dark:bg-yellow-900/40 text-yellow-700 dark:text-yellow-300',
  completed:         'bg-green-100 dark:bg-green-900/40 text-green-700 dark:text-green-300',
  failed:            'bg-red-100 dark:bg-red-900/40 text-red-600 dark:text-red-300',
}

function StatusBadge({ status }) {
  return (
    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${STATUS_STYLE[status] || STATUS_STYLE.pending}`}>
      {status.replace('_', ' ')}
    </span>
  )
}

function formatDate(iso) {
  const d = new Date(iso)
  return d.toLocaleString(undefined, {
    year: 'numeric', month: 'short', day: 'numeric',
    hour: '2-digit', minute: '2-digit',
  })
}

function parseFromTo(pipelineKey) {
  // pipeline_key is like "code->spec->code" — extract first and last token
  const parts = pipelineKey.split('->')
  if (parts.length >= 2) return { from: parts[0], to: parts[parts.length - 1] }
  return { from: pipelineKey, to: '' }
}

export default function ListWorkflowPage() {
  const navigate = useNavigate()
  const { authFetch } = useAuth()
  const [jobs, setJobs] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)

  useEffect(() => {
    authFetch('/api/jobs')
      .then(res => {
        if (!res.ok) throw new Error('Failed to load workflows')
        return res.json()
      })
      .then(data => { setJobs(data); setLoading(false) })
      .catch(() => { setError('Unable to load workflows.'); setLoading(false) })
  }, [authFetch])

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-950 text-gray-900 dark:text-white">
      <div className="max-w-5xl mx-auto px-6 py-8">
        <div className="mb-6">
          <button
            onClick={() => navigate('/')}
            className="inline-flex items-center gap-1.5 text-sm text-gray-500 dark:text-gray-400 hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors mb-3"
          >
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
            </svg>
            Back to Home
          </button>
          <h1 className="text-2xl font-bold">Workflows</h1>
          <p className="text-gray-500 dark:text-gray-400 text-sm mt-1">All modernization jobs you have created</p>
        </div>

        {loading && (
          <div className="space-y-3">
            {[1, 2, 3].map(i => (
              <div key={i} className="h-16 bg-gray-200 dark:bg-gray-800 rounded-xl animate-pulse" />
            ))}
          </div>
        )}

        {error && (
          <div className="p-4 bg-red-50 dark:bg-red-900/30 border border-red-200 dark:border-red-700 rounded-xl text-red-600 dark:text-red-300 text-sm">
            {error}
          </div>
        )}

        {!loading && !error && jobs.length === 0 && (
          <div className="text-center py-20 text-gray-400">
            <svg className="w-12 h-12 mx-auto mb-4 opacity-40" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
            </svg>
            <p className="text-sm">No workflows yet. Start one from the homepage.</p>
          </div>
        )}

        {!loading && !error && jobs.length > 0 && (
          <div className="bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-xl overflow-hidden">
            {/* Table header */}
            <div className="grid grid-cols-[1fr_180px_160px_160px_100px_70px] gap-4 px-5 py-3 bg-gray-50 dark:bg-gray-800/60 border-b border-gray-200 dark:border-gray-700 text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider">
              <span>Job ID</span>
              <span>Pathway</span>
              <span>Pipeline</span>
              <span>Created</span>
              <span>Status</span>
              <span>Steps</span>
            </div>

            {/* Rows */}
            {jobs.map((job, i) => {
              const isResumable = job.status === 'awaiting_feedback' || job.status === 'running'
              return (
                <div
                  key={job.job_id}
                  onClick={() => isResumable && navigate(`/processing/${job.job_id}`)}
                  className={`grid grid-cols-[1fr_180px_160px_160px_100px_70px] gap-4 px-5 py-4 border-b border-gray-100 dark:border-gray-800 last:border-0 transition-colors ${
                    isResumable
                      ? 'cursor-pointer hover:bg-indigo-50 dark:hover:bg-indigo-900/20'
                      : 'cursor-default'
                  } ${i % 2 === 0 ? '' : 'bg-gray-50/50 dark:bg-gray-800/20'}`}
                >
                  {/* Job ID */}
                  <div className="min-w-0 self-center">
                    <p className="text-xs font-mono text-gray-500 dark:text-gray-400 truncate">{job.job_id}</p>
                    <p className="text-xs text-gray-400 dark:text-gray-500 mt-0.5">{job.model_name}</p>
                  </div>

                  {/* Pathway: from_code → to_code */}
                  <div className="flex items-center gap-1.5 text-sm font-medium self-center">
                    <span className="text-gray-800 dark:text-gray-100">{job.from_code || '—'}</span>
                    <svg className="w-3.5 h-3.5 text-indigo-400 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7l5 5m0 0l-5 5m5-5H6" />
                    </svg>
                    <span className="text-gray-800 dark:text-gray-100">{job.to_code || '—'}</span>
                  </div>

                  {/* Pipeline key */}
                  <div className="self-center">
                    <span className="text-xs font-mono bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-300 px-2 py-1 rounded">
                      {job.pipeline_key}
                    </span>
                  </div>

                  {/* Created at */}
                  <div className="text-xs text-gray-500 dark:text-gray-400 self-center">
                    {formatDate(job.created_at)}
                  </div>

                  {/* Status */}
                  <div className="self-center">
                    <StatusBadge status={job.status} />
                  </div>

                  {/* Steps completed */}
                  <div className="self-center text-sm font-semibold text-gray-700 dark:text-gray-300">
                    {job.steps_completed}
                    {isResumable && (
                      <div className="text-indigo-500 dark:text-indigo-400 text-xs font-normal mt-0.5">Resume →</div>
                    )}
                  </div>
                </div>
              )
            })}
          </div>
        )}
      </div>
    </div>
  )
}

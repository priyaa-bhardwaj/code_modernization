import { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'

export default function AuthPage({ mode = 'login' }) {
  const navigate = useNavigate()
  const { login } = useAuth()

  const [username, setUsername] = useState('')
  const [password, setPassword] = useState('')
  const [errors, setErrors] = useState({})
  const [generalError, setGeneralError] = useState('')

  const isLogin = mode === 'login'

  async function handleSubmit(e) {
    e.preventDefault()
    setErrors({})
    setGeneralError('')

    const url = isLogin ? '/api/auth/login' : '/api/auth/register'

    let res
    try {
      res = await fetch(url, {
        method: 'POST',
        credentials: 'include',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, password }),
      })
    } catch {
      setGeneralError('Network error. Please try again.')
      return
    }

    const data = await res.json().catch(() => ({}))

    if (res.ok) {
      login(username, data.token)
      navigate('/')
    } else if (res.status === 400) {
      setErrors(data.errors || {})
      if (data.error) setGeneralError(data.error)
    } else if (res.status === 401) {
      setGeneralError(data.error || 'Invalid credentials.')
    } else if (res.status === 409) {
      setErrors({ username: data.error || 'Username already exists.' })
    } else {
      setGeneralError(data.error || 'Something went wrong.')
    }
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-950 flex items-center justify-center px-4">
      <div className="w-full max-w-sm bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-xl p-8 shadow-xl">
        <h1 className="text-2xl font-semibold text-gray-900 dark:text-white mb-6 text-center">
          {isLogin ? 'Sign in' : 'Create account'}
        </h1>

        <form onSubmit={handleSubmit} noValidate>
          <div className="mb-4">
            <label className="block text-sm text-gray-600 dark:text-gray-400 mb-1" htmlFor="username">
              Username
            </label>
            <input
              id="username"
              type="text"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              className="w-full bg-gray-100 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg px-3 py-2 text-gray-900 dark:text-white placeholder-gray-400 dark:placeholder-gray-500 focus:outline-none focus:border-purple-500 focus:ring-1 focus:ring-purple-500"
              placeholder="Enter username"
              autoComplete="username"
            />
            {errors.username && (
              <p className="mt-1 text-sm text-red-400">{errors.username}</p>
            )}
          </div>

          <div className="mb-6">
            <label className="block text-sm text-gray-600 dark:text-gray-400 mb-1" htmlFor="password">
              Password
            </label>
            <input
              id="password"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full bg-gray-100 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg px-3 py-2 text-gray-900 dark:text-white placeholder-gray-400 dark:placeholder-gray-500 focus:outline-none focus:border-purple-500 focus:ring-1 focus:ring-purple-500"
              placeholder="Enter password"
              autoComplete={isLogin ? 'current-password' : 'new-password'}
            />
            {errors.password && (
              <p className="mt-1 text-sm text-red-400">{errors.password}</p>
            )}
          </div>

          {generalError && (
            <p className="mb-4 text-sm text-red-400 text-center">{generalError}</p>
          )}

          <button
            type="submit"
            className="w-full bg-purple-600 hover:bg-purple-700 text-white font-medium py-2 rounded-lg transition-colors"
          >
            {isLogin ? 'Sign in' : 'Register'}
          </button>
        </form>

        <p className="mt-6 text-center text-sm text-gray-500 dark:text-gray-500">
          {isLogin ? (
            <>
              Don&apos;t have an account?{' '}
              <Link to="/register" className="text-purple-400 hover:text-purple-300">
                Register
              </Link>
            </>
          ) : (
            <>
              Already have an account?{' '}
              <Link to="/login" className="text-purple-400 hover:text-purple-300">
                Sign in
              </Link>
            </>
          )}
        </p>
      </div>
    </div>
  )
}

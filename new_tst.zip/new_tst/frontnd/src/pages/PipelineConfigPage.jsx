import { useEffect, useState, useRef } from 'react'
import { useSearchParams, useNavigate } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'

function BackButton() {
  const navigate = useNavigate()
  return (
    <button
      onClick={() => navigate('/')}
      className="inline-flex items-center gap-1.5 text-sm text-gray-500 dark:text-gray-400 hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors mb-6"
    >
      <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
      </svg>
      Back to Home
    </button>
  )
}

// ── Prompt editor slide-in panel ─────────────────────────────────────────────
function PromptPanel({ pipelineKey, agent, onClose, onSaved, authFetch }) {
  const [draft, setDraft] = useState(agent.prompt || '')
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState(null)
  const textareaRef = useRef(null)

  useEffect(() => {
    setDraft(agent.prompt || '')
    setError(null)
    textareaRef.current?.focus()
  }, [agent])

  async function handleSave() {
    setSaving(true)
    setError(null)
    try {
      const encodedKey = encodeURIComponent(pipelineKey)
      const res = await authFetch(
        `/api/pipelines/${encodedKey}/subagents/${encodeURIComponent(agent.name)}`,
        {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ prompt: draft }),
        }
      )
      if (!res.ok) {
        const body = await res.json().catch(() => ({}))
        setError(body.error || 'Failed to save')
        return
      }
      onSaved(agent.name, draft)
      onClose()
    } catch {
      setError('Network error')
    } finally {
      setSaving(false)
    }
  }

  return (
    <div className="fixed inset-0 z-40 flex justify-end" onClick={onClose}>
      {/* Backdrop */}
      <div className="absolute inset-0 bg-black/30 dark:bg-black/50" />

      {/* Panel */}
      <div
        className="relative z-50 w-full max-w-lg h-full bg-white dark:bg-gray-900 border-l border-gray-200 dark:border-gray-700 flex flex-col shadow-2xl"
        onClick={e => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-gray-200 dark:border-gray-700">
          <div>
            <p className="text-xs text-gray-400 dark:text-gray-500 font-mono mb-0.5">{pipelineKey}</p>
            <h3 className="text-base font-semibold text-gray-900 dark:text-white">{agent.name}</h3>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={onClose}
              className="px-3 py-1.5 text-sm text-gray-500 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white border border-gray-200 dark:border-gray-700 rounded-lg transition-colors"
            >
              Cancel
            </button>
            <button
              onClick={handleSave}
              disabled={saving || draft === agent.prompt}
              className="px-4 py-1.5 text-sm font-medium bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 disabled:cursor-not-allowed text-white rounded-lg transition-colors flex items-center gap-1.5"
            >
              {saving && <span className="w-3.5 h-3.5 rounded-full border-2 border-white border-t-transparent animate-spin" />}
              Save
            </button>
          </div>
        </div>

        {/* Editor */}
        <div className="flex-1 p-5 flex flex-col gap-3 overflow-hidden">
          <p className="text-xs text-gray-500 dark:text-gray-400">Edit the system prompt for this subagent. Changes are saved to <span className="font-mono">pipeline.json</span>.</p>
          <textarea
            ref={textareaRef}
            value={draft}
            onChange={e => setDraft(e.target.value)}
            className="flex-1 w-full bg-gray-50 dark:bg-gray-950 border border-gray-200 dark:border-gray-700 rounded-lg p-4 text-sm text-gray-900 dark:text-gray-100 font-mono resize-none focus:outline-none focus:border-indigo-500"
          />
          {error && <p className="text-red-400 text-sm">{error}</p>}
        </div>
      </div>
    </div>
  )
}

export default function PipelineConfigPage() {
  const [searchParams] = useSearchParams()
  const navigate = useNavigate()
  const { authFetch } = useAuth()

  const fromCode = searchParams.get('from') || ''
  const toCode = searchParams.get('to') || ''

  const [pipelines, setPipelines] = useState({})
  const [models, setModels] = useState([])
  const [loadingPipelines, setLoadingPipelines] = useState(true)
  const [loadingModels, setLoadingModels] = useState(true)
  const [fetchError, setFetchError] = useState(null)

  const [selectedPipeline, setSelectedPipeline] = useState(null)
  const [selectedModel, setSelectedModel] = useState(null)
  const [sourceZip, setSourceZip] = useState(null)
  const [sourceZipError, setSourceZipError] = useState(null)
  const [contextFiles, setContextFiles] = useState([])

  const [submitting, setSubmitting] = useState(false)
  const [submitError, setSubmitError] = useState(null)

  // Prompt editor panel state
  const [promptPanel, setPromptPanel] = useState(null) // { pipelineKey, agent: {name, prompt} }

  useEffect(() => {
    authFetch('/api/pipelines')
      .then(res => {
        if (!res.ok) throw new Error('Failed to load pipelines')
        return res.json()
      })
      .then(data => { setPipelines(data); setLoadingPipelines(false) })
      .catch(() => { setFetchError('Unable to load pipeline options. Please try again later.'); setLoadingPipelines(false) })
  }, [authFetch])

  useEffect(() => {
    authFetch('/api/models')
      .then(res => {
        if (!res.ok) throw new Error('Failed to load models')
        return res.json()
      })
      .then(data => { setModels(data); setLoadingModels(false) })
      .catch(() => { setFetchError('Unable to load model options. Please try again later.'); setLoadingModels(false) })
  }, [authFetch])

  function handleSourceZipChange(e) {
    const file = e.target.files[0]
    if (!file) {
      setSourceZip(null)
      setSourceZipError(null)
      return
    }
    if (!file.name.endsWith('.zip')) {
      setSourceZip(null)
      setSourceZipError('Source file must be a ZIP archive (.zip)')
      return
    }
    setSourceZipError(null)
    setSourceZip(file)
  }

  function handleContextFilesChange(e) {
    setContextFiles(Array.from(e.target.files))
  }

  const canGenerate = selectedPipeline !== null && selectedModel !== null && sourceZip !== null

  // Update local pipeline state after a prompt is saved
  function handlePromptSaved(agentName, newPrompt) {
    setPipelines(prev => {
      const updated = { ...prev }
      if (promptPanel && updated[promptPanel.pipelineKey]) {
        updated[promptPanel.pipelineKey] = {
          ...updated[promptPanel.pipelineKey],
          subagents: updated[promptPanel.pipelineKey].subagents.map(a =>
            (typeof a === 'string' ? a : a.name) === agentName
              ? { ...(typeof a === 'string' ? { name: a } : a), prompt: newPrompt }
              : a
          ),
        }
      }
      return updated
    })
  }

  async function handleGenerate() {
    if (!canGenerate) return
    setSubmitting(true)
    setSubmitError(null)

    const formData = new FormData()
    formData.append('pipeline_key', selectedPipeline)
    formData.append('model_name', selectedModel)
    formData.append('from_code', fromCode)
    formData.append('to_code', toCode)
    formData.append('source_zip', sourceZip)
    contextFiles.forEach(f => formData.append('context_files', f))

    try {
      const res = await authFetch('/api/jobs', {
        method: 'POST',
        body: formData,
      })

      const data = await res.json()

      if (res.ok) {
        navigate(`/processing/${data.job_id}`)
      } else {
        setSubmitError(data.error || 'Failed to create job. Please try again.')
      }
    } catch {
      setSubmitError('Network error. Please try again.')
    } finally {
      setSubmitting(false)
    }
  }

  const isLoading = loadingPipelines || loadingModels

  return (
  <>
    <div className="min-h-screen bg-gray-50 dark:bg-gray-950 text-gray-900 dark:text-white p-8">
      {/* Pathway header */}
      <div className="mb-8">
        <BackButton />
        <h1 className="text-2xl font-bold mb-2">Configure Modernization Job</h1>
        <div className="flex items-center gap-2 text-lg text-gray-600 dark:text-gray-300">
          <span className="bg-gray-100 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg px-3 py-1 font-mono">
            {fromCode}
          </span>
          <span className="text-indigo-500 dark:text-indigo-400">→</span>
          <span className="bg-gray-100 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg px-3 py-1 font-mono">
            {toCode}
          </span>
        </div>
      </div>

      {fetchError && (
        <div className="mb-6 p-4 bg-red-50 dark:bg-red-900/40 border border-red-300 dark:border-red-700 rounded-lg text-red-600 dark:text-red-300">
          {fetchError}
        </div>
      )}

      {isLoading && !fetchError && (
        <p className="text-gray-600 dark:text-gray-400">Loading configuration options...</p>
      )}

      {!isLoading && !fetchError && (
        <>
          {/* Pipeline selection */}
          <section className="mb-8">
            <h2 className="text-lg font-semibold mb-3 text-gray-700 dark:text-gray-200">Select Pipeline</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {Object.entries(pipelines).map(([key, pipeline]) => {
                const isSelected = selectedPipeline === key
                const truncatedPrompt =
                  pipeline.system_prompt && pipeline.system_prompt.length > 120
                    ? pipeline.system_prompt.slice(0, 120) + '…'
                    : pipeline.system_prompt
                return (
                  <button
                    key={key}
                    onClick={() => setSelectedPipeline(key)}
                    className={`text-left rounded-xl border p-5 transition-colors duration-200 ${
                      isSelected
                        ? 'border-indigo-500 bg-indigo-50 dark:bg-indigo-900/30'
                        : 'border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 hover:border-indigo-400'
                    }`}
                  >
                    <div className="font-mono font-semibold text-gray-900 dark:text-white mb-1">{key}</div>
                    {truncatedPrompt && (
                      <p className="text-gray-600 dark:text-gray-400 text-sm mb-3">{truncatedPrompt}</p>
                    )}
                    {pipeline.subagents && pipeline.subagents.length > 0 && (
                      <div className="flex flex-wrap gap-2">
                        {pipeline.subagents.map(agent => {
                          const name = typeof agent === 'string' ? agent : agent.name
                          return (
                            <button
                              key={name}
                              type="button"
                              onClick={e => {
                                e.stopPropagation()
                                setPromptPanel({
                                  pipelineKey: key,
                                  agent: typeof agent === 'string'
                                    ? { name: agent, prompt: '' }
                                    : agent,
                                })
                              }}
                              className="bg-gray-100 dark:bg-gray-700 hover:bg-indigo-100 dark:hover:bg-indigo-900/40 hover:text-indigo-700 dark:hover:text-indigo-300 text-gray-600 dark:text-gray-300 text-xs px-2 py-1 rounded-full transition-colors flex items-center gap-1 group"
                              title="Click to view/edit prompt"
                            >
                              {name}
                              <svg className="w-3 h-3 opacity-0 group-hover:opacity-100 transition-opacity" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
                              </svg>
                            </button>
                          )
                        })}
                      </div>
                    )}
                  </button>
                )
              })}
            </div>
          </section>

          {/* Model selection */}
          <section className="mb-8">
            <h2 className="text-lg font-semibold mb-3 text-gray-700 dark:text-gray-200">Select Model</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {models.map((model, i) => {
                const isSelected = selectedModel === model.model_name
                return (
                  <button
                    key={i}
                    onClick={() => setSelectedModel(model.model_name)}
                    className={`text-left rounded-xl border p-4 transition-colors duration-200 ${
                      isSelected
                        ? 'border-indigo-500 bg-indigo-50 dark:bg-indigo-900/30'
                        : 'border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 hover:border-indigo-400'
                    }`}
                  >
                    <div className="font-semibold text-gray-900 dark:text-white">{model.model_name}</div>
                    <div className="text-gray-600 dark:text-gray-400 text-sm mt-1">{model.provider}</div>
                  </button>
                )
              })}
            </div>
          </section>

          {/* Source ZIP upload */}
          <section className="mb-8">
            <h2 className="text-lg font-semibold mb-3 text-gray-700 dark:text-gray-200">Source Code (ZIP)</h2>
            <label className="block">
              <input
                type="file"
                accept=".zip"
                onChange={handleSourceZipChange}
                className="block w-full text-sm text-gray-500 dark:text-gray-400
                  file:mr-4 file:py-2 file:px-4
                  file:rounded-lg file:border-0
                  file:text-sm file:font-medium
                  file:bg-indigo-600 file:text-white
                  hover:file:bg-indigo-700
                  cursor-pointer"
              />
            </label>
            {sourceZipError && (
              <p className="mt-2 text-sm text-red-400">{sourceZipError}</p>
            )}
            {sourceZip && !sourceZipError && (
              <div className="mt-3 flex items-center gap-3 px-4 py-3 bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-700 rounded-lg">
                <svg className="w-5 h-5 text-green-500 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
                <div className="min-w-0">
                  <p className="text-sm font-medium text-green-700 dark:text-green-300 truncate">{sourceZip.name}</p>
                  <p className="text-xs text-green-600 dark:text-green-400 mt-0.5">
                    {(sourceZip.size / 1024).toFixed(1)} KB &middot; {sourceZip.type || 'application/zip'}
                  </p>
                </div>
              </div>
            )}
          </section>

          {/* Optional context files */}
          <section className="mb-8">
            <h2 className="text-lg font-semibold mb-1 text-gray-700 dark:text-gray-200">
              Context Files{' '}
              <span className="text-gray-400 dark:text-gray-500 font-normal text-sm">(optional)</span>
            </h2>
            <p className="text-gray-500 text-sm mb-3">
              Upload additional files or a ZIP to provide enterprise context for the pipeline.
            </p>
            <label className="block">
              <input
                type="file"
                multiple
                onChange={handleContextFilesChange}
                className="block w-full text-sm text-gray-500 dark:text-gray-400
                  file:mr-4 file:py-2 file:px-4
                  file:rounded-lg file:border-0
                  file:text-sm file:font-medium
                  file:bg-gray-200 dark:file:bg-gray-700 file:text-gray-700 dark:file:text-gray-200
                  hover:file:bg-gray-300 dark:hover:file:bg-gray-600
                  cursor-pointer"
              />
            </label>
            {contextFiles.length > 0 && (
              <p className="mt-2 text-sm text-gray-500 dark:text-gray-400">
                {contextFiles.length} file{contextFiles.length !== 1 ? 's' : ''} selected
              </p>
            )}
          </section>

          {/* Submit error */}
          {submitError && (
            <div className="mb-4 p-4 bg-red-50 dark:bg-red-900/40 border border-red-300 dark:border-red-700 rounded-lg text-red-600 dark:text-red-300">
              {submitError}
            </div>
          )}

          {/* Generate button */}
          <button
            onClick={handleGenerate}
            disabled={!canGenerate || submitting}
            className={`px-8 py-3 rounded-xl font-semibold text-white transition-colors duration-200 ${
              canGenerate && !submitting
                ? 'bg-indigo-600 hover:bg-indigo-700 cursor-pointer'
                : 'bg-gray-200 dark:bg-gray-700 text-gray-400 dark:text-gray-500 cursor-not-allowed'
            }`}
          >
            {submitting ? 'Generating…' : 'Generate'}
          </button>
        </>
      )}
    </div>

    {/* Prompt editor panel */}
    {promptPanel && (
      <PromptPanel
        pipelineKey={promptPanel.pipelineKey}
        agent={promptPanel.agent}
        onClose={() => setPromptPanel(null)}
        onSaved={handlePromptSaved}
        authFetch={authFetch}
      />
    )}
  </>
  )
}

import { createContext, useContext, useState, useCallback } from 'react'

const AuthContext = createContext(null)

export function AuthProvider({ children }) {
  const [user, setUser] = useState(() => {
    const stored = localStorage.getItem('auth_user')
    return stored ? JSON.parse(stored) : null
  })

  function login(username, token) {
    const userData = { username, token }
    localStorage.setItem('auth_user', JSON.stringify(userData))
    setUser(userData)
  }

  function logout() {
    localStorage.removeItem('auth_user')
    setUser(null)
  }

  // Wrapper around fetch that injects Authorization header automatically
  const authFetch = useCallback((url, options = {}) => {
    const stored = localStorage.getItem('auth_user')
    const token = stored ? JSON.parse(stored).token : null
    const headers = { ...(options.headers || {}) }
    if (token) headers['Authorization'] = `Bearer ${token}`
    return fetch(url, { ...options, headers })
  }, [])

  return (
    <AuthContext.Provider value={{ user, login, logout, authFetch }}>
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  return useContext(AuthContext)
}

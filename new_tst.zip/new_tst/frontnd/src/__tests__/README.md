# Frontend Tests

Tests are organized per component. Run with `npm test` (vitest --run).

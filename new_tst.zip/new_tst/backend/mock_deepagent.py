"""
MockDeepAgent — simulates the real DeepAgent pipeline without any LLM calls.

Used for demo/UI testing. It writes realistic sample files to the workspace
directories (specs/, target_codebase/, validation/) with delays to simulate
execution time, emits the same SSE events as the real agent, and uses the
same HITL interrupt/approval flow.

Usage:
    Set MOCK_AGENT=1 in your .env or environment before starting the backend.
"""

import os
import time
import threading
import zipfile
from queue import Queue

from watchdog.observers import Observer
from deepagent import _WorkspaceFileHandler


# ── Sample outputs ────────────────────────────────────────────────────────────

_SPEC_OUTPUT_TXT = """\
Specification Generation Summary
=================================
Analyzed 3 source files (Java legacy codebase).
Generated detailed specifications covering:
  - 5 REST API endpoints
  - 2 data models (User, Order)
  - 1 service layer (OrderService)
  - Database schema mapping

All specifications written to specs/ directory.
"""

_SPEC_FILE_CONTENT = """\
# Technical Specification: Order Management System

## 1. Overview
This document describes the modernization specification for a legacy Java
Order Management System, targeting Spring Boot 3.x.

## 2. Data Models

### 2.1 User
| Field    | Type   | Constraints       |
|----------|--------|-------------------|
| id       | Long   | Primary Key, Auto |
| username | String | Unique, Not Null  |
| email    | String | Unique, Not Null  |
| role     | Enum   | ADMIN, USER       |

### 2.2 Order
| Field      | Type      | Constraints          |
|------------|-----------|----------------------|
| id         | Long      | Primary Key, Auto    |
| userId     | Long      | FK → User.id         |
| status     | Enum      | PENDING, COMPLETED   |
| totalAmount| BigDecimal| Not Null             |
| createdAt  | Timestamp | Auto-generated       |

## 3. API Endpoints
- `GET    /api/users`       — List all users
- `POST   /api/users`       — Create a new user
- `GET    /api/orders`      — List orders (filterable)
- `POST   /api/orders`      — Place a new order
- `GET    /api/orders/{id}` — Get order details

## 4. Business Rules
1. Only authenticated users can place orders
2. Order total must be > 0
3. Users with ADMIN role can view all orders
"""

_CODE_OUTPUT_TXT = """\
Code Generation Summary
========================
Generated Spring Boot 3.x project structure:
  - 2 Entity classes (User.java, Order.java)
  - 2 Repository interfaces
  - 1 Service class (OrderService.java)
  - 2 REST Controllers
  - 1 Application entry point
  - application.yml configuration

Total files generated: 8
Target framework: Spring Boot 3.2
"""

_CODE_FILES = {
    "target_codebase/springboot/src/main/java/com/example/model/User.java": """\
package com.example.model;

import jakarta.persistence.*;
import lombok.Data;

@Data
@Entity
@Table(name = "users")
public class User {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(unique = true, nullable = false)
    private String username;

    @Column(unique = true, nullable = false)
    private String email;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private Role role = Role.USER;

    public enum Role { ADMIN, USER }
}
""",
    "target_codebase/springboot/src/main/java/com/example/model/Order.java": """\
package com.example.model;

import jakarta.persistence.*;
import lombok.Data;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
@Entity
@Table(name = "orders")
public class Order {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private Status status = Status.PENDING;

    @Column(nullable = false, precision = 10, scale = 2)
    private BigDecimal totalAmount;

    @Column(nullable = false, updatable = false)
    private LocalDateTime createdAt = LocalDateTime.now();

    public enum Status { PENDING, COMPLETED, CANCELLED }
}
""",
    "target_codebase/springboot/src/main/java/com/example/service/OrderService.java": """\
package com.example.service;

import com.example.model.Order;
import com.example.model.User;
import com.example.repository.OrderRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;

@Service
@RequiredArgsConstructor
public class OrderService {
    private final OrderRepository orderRepository;

    @Transactional
    public Order placeOrder(User user, BigDecimal amount) {
        if (amount.compareTo(BigDecimal.ZERO) <= 0) {
            throw new IllegalArgumentException("Order total must be > 0");
        }
        Order order = new Order();
        order.setUser(user);
        order.setTotalAmount(amount);
        order.setStatus(Order.Status.PENDING);
        return orderRepository.save(order);
    }

    public List<Order> findByUser(User user) {
        return orderRepository.findByUser(user);
    }

    public List<Order> findAll() {
        return orderRepository.findAll();
    }
}
""",
    "target_codebase/springboot/src/main/java/com/example/controller/OrderController.java": """\
package com.example.controller;

import com.example.model.Order;
import com.example.service.OrderService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/orders")
@RequiredArgsConstructor
public class OrderController {
    private final OrderService orderService;

    @GetMapping
    public ResponseEntity<List<Order>> listOrders() {
        return ResponseEntity.ok(orderService.findAll());
    }

    @GetMapping("/{id}")
    public ResponseEntity<Order> getOrder(@PathVariable Long id) {
        // Implementation here
        return ResponseEntity.ok().build();
    }
}
""",
    "target_codebase/springboot/src/main/resources/application.yml": """\
spring:
  application:
    name: order-management
  datasource:
    url: jdbc:postgresql://localhost:5432/orders_db
    username: ${DB_USER:postgres}
    password: ${DB_PASS:postgres}
  jpa:
    hibernate:
      ddl-auto: validate
    show-sql: false
    properties:
      hibernate.format_sql: true

server:
  port: 8080
""",
}

_VALIDATION_OUTPUT_TXT = """\
Validation Report Summary
===========================
Compared original source with generated Spring Boot code.

Results:
  ✅ All 5 API endpoints mapped correctly
  ✅ Data models match specification (User, Order)
  ✅ Business rules implemented (order total > 0)
  ⚠️  Minor: Missing pagination on list endpoints
  ⚠️  Minor: No input validation annotations (@Valid)

Overall: PASS with minor suggestions.
"""

_VALIDATION_REPORT = """\
# Validation Report

## Endpoint Mapping
| Original          | Generated              | Status |
|-------------------|------------------------|--------|
| GET /users        | GET /api/users         | ✅ OK  |
| POST /users       | POST /api/users        | ✅ OK  |
| GET /orders       | GET /api/orders        | ✅ OK  |
| POST /orders      | POST /api/orders       | ✅ OK  |
| GET /orders/{id}  | GET /api/orders/{id}   | ✅ OK  |

## Data Model Validation
- User entity: All fields present ✅
- Order entity: All fields present ✅
- Relationships mapped correctly ✅

## Business Logic
- Order total > 0 validation: ✅ Implemented in OrderService
- Role-based access: ⚠️ Not yet implemented (needs Spring Security)

## Recommendations
1. Add `@Valid` annotation to request bodies
2. Add pagination with `Pageable` to list endpoints
3. Configure Spring Security for role-based access
4. Add integration tests
"""


# ── MockDeepAgent ─────────────────────────────────────────────────────────────

class MockDeepAgent:
    """
    Simulates the real DeepAgent pipeline for UI testing.
    Writes sample files progressively with delays and emits the same SSE events.
    """

    def __init__(self, job_id: str, pipeline: dict, model: dict, workspace_path: str):
        self.job_id = job_id
        self.pipeline = pipeline
        self.model = model
        self.workspace_path = workspace_path

        self._feedback: str = ""
        self._feedback_event = threading.Event()
        self._app = None
        self._current_subagent: str = ""

    def run(self, sse_queue: Queue) -> None:
        """Execute the mock pipeline."""
        from flask import current_app
        try:
            app = current_app._get_current_object()
        except RuntimeError:
            app = self._app

        subagents = self.pipeline.get("subagents", [])
        self._update_status(app, "running")
        self._prepare_workspace()

        # Start filesystem watcher (same as real agent)
        observer = Observer()
        handler = _WorkspaceFileHandler(
            workspace_path=self.workspace_path,
            sse_queue=sse_queue,
            get_current_subagent=lambda: self._current_subagent,
        )
        observer.schedule(handler, self.workspace_path, recursive=True)
        observer.start()

        try:
            previous_output = ""

            for i, subagent in enumerate(subagents):
                if isinstance(subagent, dict):
                    subagent_name = subagent.get("name", f"subagent_{i}")
                else:
                    subagent_name = str(subagent)

                self._current_subagent = subagent_name

                # Notify frontend: subagent starting
                sse_queue.put({
                    "event": "subagent_started",
                    "data": {"subagent": subagent_name, "index": i},
                })

                # Determine output directory
                output_dir = self._subagent_output_dir(subagent_name)
                os.makedirs(output_dir, exist_ok=True)

                # Simulate work — write files progressively
                output = self._simulate_subagent(subagent_name, output_dir)

                # Write output.txt summary
                with open(os.path.join(output_dir, "output.txt"), "w", encoding="utf-8") as fh:
                    fh.write(output)

                # Small delay for file watcher to pick up the last write
                time.sleep(0.3)

                # Emit interrupt — frontend shows output for review
                sse_queue.put({
                    "event": "interrupt",
                    "data": {"subagent": subagent_name, "index": i, "output": output},
                })
                self._update_status(app, "awaiting_feedback")

                # Wait for user approval
                self._feedback_event.clear()
                self._feedback_event.wait()
                self._update_status(app, "running")

                previous_output = self._feedback if self._feedback.strip() else output
                self._feedback = ""

            # All subagents done
            self._update_status(app, "completed")
            sse_queue.put({
                "event": "pipeline_complete",
                "data": {"job_id": self.job_id},
            })

        except Exception as exc:
            import traceback
            traceback.print_exc()
            sse_queue.put({
                "event": "error",
                "data": {"message": f"{type(exc).__name__}: {exc}"},
            })
            self._update_status(app, "failed")
        finally:
            observer.stop()
            observer.join(timeout=2)

    def submit_feedback(self, feedback: str) -> None:
        self._feedback = feedback
        self._feedback_event.set()

    def _prepare_workspace(self) -> None:
        source_zip = os.path.join(self.workspace_path, "source.zip")
        source_dir = os.path.join(self.workspace_path, "source_code")
        if os.path.isfile(source_zip) and not os.path.isdir(source_dir):
            os.makedirs(source_dir, exist_ok=True)
            with zipfile.ZipFile(source_zip, "r") as zf:
                zf.extractall(source_dir)

    def _subagent_output_dir(self, subagent_name: str) -> str:
        mapping = {
            "spec_generator": "specs",
            "code_generator": "target_codebase",
            "code_translator": "target_codebase",
            "validator": "validation",
        }
        folder = mapping.get(subagent_name, subagent_name)
        return os.path.join(self.workspace_path, folder)

    def _simulate_subagent(self, subagent_name: str, output_dir: str) -> str:
        """Write mock files progressively with delays and return the output.txt summary."""

        if subagent_name == "spec_generator":
            # Write spec document
            spec_path = os.path.join(output_dir, "specification.md")
            self._write_progressively(spec_path, _SPEC_FILE_CONTENT, chunk_delay=0.3)
            return _SPEC_OUTPUT_TXT

        elif subagent_name in ("code_generator", "code_translator"):
            # Write multiple code files
            for rel_path, content in _CODE_FILES.items():
                full_path = os.path.join(self.workspace_path, rel_path)
                os.makedirs(os.path.dirname(full_path), exist_ok=True)
                self._write_progressively(full_path, content, chunk_delay=0.2)
                time.sleep(0.5)  # gap between files
            return _CODE_OUTPUT_TXT

        elif subagent_name == "validator":
            # Write validation report
            report_path = os.path.join(output_dir, "validation_report.md")
            self._write_progressively(report_path, _VALIDATION_REPORT, chunk_delay=0.3)
            return _VALIDATION_OUTPUT_TXT

        else:
            # Generic fallback
            generic_path = os.path.join(output_dir, "result.txt")
            content = f"Mock output for subagent: {subagent_name}\nCompleted successfully."
            self._write_progressively(generic_path, content, chunk_delay=0.2)
            return f"[{subagent_name}] completed — see output files."

    def _write_progressively(self, filepath: str, content: str, chunk_delay: float = 0.3):
        """Write content in chunks to simulate progressive file generation."""
        lines = content.split('\n')
        chunk_size = max(3, len(lines) // 5)  # ~5 chunks

        os.makedirs(os.path.dirname(filepath), exist_ok=True)

        written = []
        for i in range(0, len(lines), chunk_size):
            written.extend(lines[i:i + chunk_size])
            with open(filepath, "w", encoding="utf-8") as fh:
                fh.write('\n'.join(written))
            time.sleep(chunk_delay)

        # Final complete write
        with open(filepath, "w", encoding="utf-8") as fh:
            fh.write(content)

    def _update_status(self, app, status: str) -> None:
        if app is None:
            return
        with app.app_context():
            from models import db, Job
            job = db.session.get(Job, self.job_id)
            if job:
                job.status = status
                db.session.commit()

# pip install langchain-google-genai
from langchain_google_genai import ChatGoogleGenerativeAI
encrpt= "AIzaSyCB_VayEqAB6KUN9kn_THt63HcMV5syt9Q"
gemini = ChatGoogleGenerativeAI(
    model="gemini-2.5-flash",
    google_api_key=encrpt,
    temperature=0,
)

print(gemini.invoke("what's your name"))

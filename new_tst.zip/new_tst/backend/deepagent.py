"""
DeepAgent orchestration engine.

Uses the `deepagents` library (create_deep_agent) with:
- langchain_github_copilot as the LLM provider
- FilesystemBackend rooted at the job workspace
- MemorySaver checkpointer for human-in-the-loop (HITL) support
- interrupt_on write_file / edit_file so the user reviews every file write

Each subagent in the pipeline is run sequentially. After each subagent
completes, an SSE interrupt event is emitted and execution pauses until
the user approves (optionally with edited feedback).
"""

import os
import time
import threading
import zipfile
from queue import Queue

from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler


# ---------------------------------------------------------------------------
# LLM factory
# ---------------------------------------------------------------------------

def _build_llm(model_cfg: dict):
    # """
    # Build a LangChain chat model from the model config dict.
    # Falls back to ChatGitHubCopilot if provider is unrecognised.
    # """
    # model_name = model_cfg.get("model_name", "gpt-4o")
    # provider = (model_cfg.get("provider") or "").lower()

    # if "github" in provider or "copilot" in provider or not provider:
    # from langchain_github_copilot import ChatGitHubCopilot
    # return ChatGitHubCopilot(model_name="gpt-4o")
    # pip install langchain-google-genai
    from langchain_google_genai import ChatGoogleGenerativeAI
    encrpt= "AIzaSyCB_VayEqAB6KUN9kn_THt63HcMV5syt9Q"
    gemini = ChatGoogleGenerativeAI(
        model="gemini-2.5-flash",
        google_api_key=encrpt,
        temperature=0,
    )
    return gemini

# ---------------------------------------------------------------------------
# DeepAgent class
# ---------------------------------------------------------------------------

# ---------------------------------------------------------------------------
# Workspace file watcher for real-time SSE streaming
# ---------------------------------------------------------------------------

# Directories to watch for file changes
_WATCHED_DIRS = {"specs", "target_codebase", "validation"}


class _WorkspaceFileHandler(FileSystemEventHandler):
    """Debounced watchdog handler that pushes file_changed SSE events."""

    def __init__(self, workspace_path: str, sse_queue: Queue, get_current_subagent):
        super().__init__()
        self.workspace_path = workspace_path
        self.sse_queue = sse_queue
        self._get_current_subagent = get_current_subagent
        self._last_sent: dict[str, float] = {}   # path -> timestamp
        self._debounce_sec = 0.1

    def _should_handle(self, path: str) -> bool:
        rel = os.path.relpath(path, self.workspace_path).replace("\\", "/")
        top_dir = rel.split("/")[0]
        return top_dir in _WATCHED_DIRS and os.path.isfile(path)

    def _emit(self, path: str):
        now = time.time()
        if now - self._last_sent.get(path, 0) < self._debounce_sec:
            return
        self._last_sent[path] = now

        rel = os.path.relpath(path, self.workspace_path).replace("\\", "/")
        try:
            with open(path, "r", encoding="utf-8", errors="replace") as fh:
                content = fh.read()
        except Exception:
            return

        self.sse_queue.put({
            "event": "file_changed",
            "data": {
                "path": rel,
                "content": content,
                "subagent": self._get_current_subagent(),
            },
        })

    def on_modified(self, event):
        if not event.is_directory and self._should_handle(event.src_path):
            self._emit(event.src_path)

    def on_created(self, event):
        if not event.is_directory and self._should_handle(event.src_path):
            self._emit(event.src_path)


class DeepAgent:
    """
    Orchestrates sequential subagent execution using the deepagents library.

    Flow per subagent:
      1. Unzip source code into workspace/source_code/ (first subagent only)
      2. Build a create_deep_agent with FilesystemBackend rooted at workspace
      3. Stream the agent; collect final assistant message as output
      4. Emit SSE interrupt event and pause for user feedback
      5. On resume, pass feedback as additional context to next subagent
    """

    def __init__(self, job_id: str, pipeline: dict, model: dict, workspace_path: str):
        self.job_id = job_id
        self.pipeline = pipeline          # {'system_prompt': ..., 'subagents': [...]}
        self.model = model                # {'model_name': ..., 'provider': ..., ...}
        self.workspace_path = workspace_path

        self._feedback: str = ""
        self._feedback_event = threading.Event()
        self._app = None                  # Flask app reference for DB access
        self._current_subagent: str = ""  # Tracks active subagent for file watcher

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def run(self, sse_queue: Queue) -> None:
        """Execute the pipeline. Must be called in a background thread."""
        from flask import current_app
        try:
            app = current_app._get_current_object()
        except RuntimeError:
            app = self._app

        subagents = self.pipeline.get("subagents", [])
        pipeline_system_prompt = self.pipeline.get("system_prompt", "")

        self._update_status(app, "running")
        # Unzip source code on first run
        self._prepare_workspace()

        # Start filesystem watcher for real-time SSE updates
        observer = Observer()
        handler = _WorkspaceFileHandler(
            workspace_path=self.workspace_path,
            sse_queue=sse_queue,
            get_current_subagent=lambda: self._current_subagent,
        )
        observer.schedule(handler, self.workspace_path, recursive=True)
        observer.start()

        try:
            previous_output = ""

            for i, subagent in enumerate(subagents):
                if isinstance(subagent, dict):
                    subagent_name = subagent.get("name", f"subagent_{i}")
                    subagent_prompt = subagent.get("prompt", "")
                else:
                    subagent_name = str(subagent)
                    subagent_prompt = ""

                # Track active subagent for file watcher
                self._current_subagent = subagent_name

                # Notify frontend: subagent starting
                sse_queue.put({
                    "event": "subagent_started",
                    "data": {"subagent": subagent_name, "index": i},
                })

                # Determine output directory for this subagent
                output_dir = self._subagent_output_dir(subagent_name)
                os.makedirs(output_dir, exist_ok=True)

                try:
                    output = self._run_subagent(
                        subagent_name=subagent_name,
                        subagent_prompt=subagent_prompt,
                        pipeline_system_prompt=pipeline_system_prompt,
                        previous_output=previous_output,
                        feedback=self._feedback,
                        output_dir=output_dir,
                    )
                except Exception as exc:
                    import traceback
                    tb = traceback.format_exc()
                    if app:
                        try:
                            with app.app_context():
                                app.logger.error("Subagent %s failed:\n%s", subagent_name, tb)
                        except Exception:
                            pass
                    sse_queue.put({
                        "event": "error",
                        "data": {"message": f"{subagent_name} failed: {type(exc).__name__}: {exc}"},
                    })
                    self._update_status(app, "failed")
                    return

                # Persist output summary
                self._persist_output(subagent_name, output)

                # Emit interrupt — frontend shows output for review
                sse_queue.put({
                    "event": "interrupt",
                    "data": {"subagent": subagent_name, "index": i, "output": output},
                })
                self._update_status(app, "awaiting_feedback")

                # Wait for user approval / feedback
                self._feedback_event.clear()
                self._feedback_event.wait()
                self._update_status(app, "running")

                # Carry output (possibly edited by user) forward
                previous_output = self._feedback if self._feedback.strip() else output
                self._feedback = ""

            # All subagents done
            self._update_status(app, "completed")
            sse_queue.put({
                "event": "pipeline_complete",
                "data": {"job_id": self.job_id},
            })

        except Exception as exc:
            import traceback
            tb = traceback.format_exc()
            if app:
                try:
                    with app.app_context():
                        app.logger.error("DeepAgent run() failed:\n%s", tb)
                except Exception:
                    pass
            sse_queue.put({
                "event": "error",
                "data": {"message": f"{type(exc).__name__}: {exc}"},
            })
            self._update_status(app, "failed")
        finally:
            # Stop filesystem watcher
            observer.stop()
            observer.join(timeout=2)

    def submit_feedback(self, feedback: str) -> None:
        """Unblock the paused pipeline with user feedback/approval."""
        self._feedback = feedback
        self._feedback_event.set()

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    def _prepare_workspace(self) -> None:
        """Unzip source.zip into workspace/source_code/ if not already done."""
        source_zip = os.path.join(self.workspace_path, "source.zip")
        source_dir = os.path.join(self.workspace_path, "source_code")
        if os.path.isfile(source_zip) and not os.path.isdir(source_dir):
            os.makedirs(source_dir, exist_ok=True)
            with zipfile.ZipFile(source_zip, "r") as zf:
                zf.extractall(source_dir)

    def _subagent_output_dir(self, subagent_name: str) -> str:
        """Map subagent name to its workspace output directory."""
        mapping = {
            "spec_generator": "specs",
            "code_generator": "target_codebase",
            "code_translator": "target_codebase",
            "validator": "validation",
        }
        folder = mapping.get(subagent_name, subagent_name)
        return os.path.join(self.workspace_path, folder)

    def _run_subagent(
        self,
        subagent_name: str,
        subagent_prompt: str,
        pipeline_system_prompt: str,
        previous_output: str,
        feedback: str,
        output_dir: str,
    ) -> str:
        """
        Run a single subagent using create_deep_agent with FilesystemBackend.
        Returns the final assistant message content.
        """
        from deepagents import create_deep_agent
        from deepagents.backends import FilesystemBackend
        from langgraph.checkpoint.memory import MemorySaver

        llm = _build_llm(self.model)

        # FilesystemBackend rooted at workspace so agent can read/write files
        backend = FilesystemBackend(
            root_dir=self.workspace_path,
            virtual_mode=True,
        )

        # HITL: interrupt on file writes so user can review
        checkpointer = MemorySaver()

        # Compose system prompt
        system_prompt = "\n\n".join(filter(None, [
            pipeline_system_prompt,
            subagent_prompt,
            f"Write all output files to the directory: {os.path.relpath(output_dir, self.workspace_path)}",
        ]))
        print("---------------",self.workspace_path)
        print("test,--------",backend)
        agent = create_deep_agent(
            model=llm,
            system_prompt=system_prompt,
            backend=backend,
            checkpointer=checkpointer,
            # interrupt_on={
            #     "write_file": True,
            #     "edit_file": True,
            # },
        )

        # Build user message
        user_message = self._build_user_message(
            subagent_name=subagent_name,
            previous_output=previous_output,
            feedback=feedback,
        )

        thread_id = f"{self.job_id}-{subagent_name}"
        config = {"configurable": {"thread_id": thread_id}}

        # Stream the agent, collecting the final response
        final_content = ""
        for chunk in agent.stream(
            {"messages": [{"role": "user", "content": user_message}]},
            config=config,
            stream_mode="values",
        ):
            messages = chunk.get("messages", [])
            if messages:
                last = messages[-1]
                content = getattr(last, "content", None)
                print("\ncontent >>", content)
                if content and hasattr(last, "type") and last.type == "ai":
                    final_content = content

        return final_content or f"[{subagent_name} completed — see output files in workspace]"

    def _build_user_message(
        self,
        subagent_name: str,
        previous_output: str,
        feedback: str,
    ) -> str:
        """Compose the user message for a subagent invocation."""
        source_dir = os.path.join(self.workspace_path, "source_code")
        parts = [
            f"You are running as the **{subagent_name}** subagent.",
        ]

        if previous_output:
            parts.append(
                f"\n## Previous subagent output\n{previous_output}"
            )

        if feedback and feedback.strip():
            parts.append(
                f"\n## User feedback / instructions\n{feedback}"
            )

        parts.append("\nPlease proceed with your task.")
        return "\n".join(parts)

    def _persist_output(self, subagent_name: str, output: str) -> None:
        """Write the subagent's final response to output.txt in its directory."""
        out_dir = self._subagent_output_dir(subagent_name)
        os.makedirs(out_dir, exist_ok=True)
        with open(os.path.join(out_dir, "output.txt"), "w", encoding="utf-8") as fh:
            fh.write(output)

    def _update_status(self, app, status: str) -> None:
        """Update Job.status in the DB within an app context."""
        if app is None:
            return
        with app.app_context():
            from models import db, Job
            job = db.session.get(Job, self.job_id)
            if job:
                job.status = status
                db.session.commit()

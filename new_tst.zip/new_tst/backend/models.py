from datetime import datetime, timezone
from flask_sqlalchemy import SQLAlchemy
from flask_login import UserMixin

db = SQLAlchemy()


class User(UserMixin, db.Model):
    __tablename__ = "users"

    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    username = db.Column(db.String(150), unique=True, nullable=False)
    password_hash = db.Column(db.String(256), nullable=False)
    created_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc), nullable=False)

    jobs = db.relationship("Job", backref="user", lazy=True)

    def __repr__(self):
        return f"<User {self.username}>"


class Job(db.Model):
    __tablename__ = "jobs"

    id = db.Column(db.String(36), primary_key=True)  # UUID
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    pipeline_key = db.Column(db.String(100), nullable=False)
    model_name = db.Column(db.String(100), nullable=False)
    from_code = db.Column(db.String(100), nullable=True)
    to_code = db.Column(db.String(100), nullable=True)
    workspace_path = db.Column(db.String(512), nullable=False)
    status = db.Column(db.String(50), nullable=False, default="pending")
    # status values: pending | running | awaiting_feedback | completed | failed
    created_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc), nullable=False)
    updated_at = db.Column(
        db.DateTime,
        default=lambda: datetime.now(timezone.utc),
        onupdate=lambda: datetime.now(timezone.utc),
        nullable=False,
    )

    def __repr__(self):
        return f"<Job {self.id} status={self.status}>"

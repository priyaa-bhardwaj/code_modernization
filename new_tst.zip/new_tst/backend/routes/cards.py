import json
from flask import Blueprint, jsonify, current_app

cards_bp = Blueprint("cards", __name__)


@cards_bp.route("/cards", methods=["GET"])
def get_cards():
    try:
        with open(current_app.config["CARDS_CONFIG"], "r") as f:
            cards = json.load(f)
        return jsonify(cards), 200
    except Exception as e:
        return jsonify({"error": f"Failed to load configuration: {e}"}), 500

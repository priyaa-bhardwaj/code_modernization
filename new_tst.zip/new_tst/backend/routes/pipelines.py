import json
from flask import Blueprint, jsonify, request, current_app
from routes.auth import token_required

pipelines_bp = Blueprint("pipelines", __name__)


@pipelines_bp.route("/pipelines", methods=["GET"])
def get_pipelines():
    try:
        with open(current_app.config["PIPELINE_CONFIG"], "r") as f:
            pipelines = json.load(f)
        return jsonify(pipelines), 200
    except Exception as e:
        return jsonify({"error": f"Failed to load configuration: {e}"}), 500


@pipelines_bp.route("/pipelines/<pipeline_key>/subagents/<subagent_name>", methods=["PUT"])
@token_required
def update_subagent_prompt(pipeline_key, subagent_name):
    """Update the prompt for a specific subagent in a pipeline."""
    body = request.get_json(silent=True) or {}
    new_prompt = body.get("prompt")
    if new_prompt is None:
        return jsonify({"error": "prompt is required"}), 400

    config_path = current_app.config["PIPELINE_CONFIG"]
    try:
        with open(config_path, "r", encoding="utf-8") as f:
            pipelines = json.load(f)
    except Exception as e:
        return jsonify({"error": f"Failed to load configuration: {e}"}), 500

    # pipeline_key may contain "->" which gets URL-encoded; decode handled by Flask
    if pipeline_key not in pipelines:
        return jsonify({"error": "Pipeline not found"}), 404

    subagents = pipelines[pipeline_key].get("subagents", [])
    updated = False
    for agent in subagents:
        if isinstance(agent, dict) and agent.get("name") == subagent_name:
            agent["prompt"] = new_prompt
            updated = True
            break

    if not updated:
        return jsonify({"error": "Subagent not found"}), 404

    try:
        with open(config_path, "w", encoding="utf-8") as f:
            json.dump(pipelines, f, indent=2)
    except Exception as e:
        return jsonify({"error": f"Failed to save configuration: {e}"}), 500

    return jsonify({"message": "Prompt updated"}), 200


@pipelines_bp.route("/models", methods=["GET"])
def get_models():
    try:
        with open(current_app.config["MODEL_CONFIG"], "r") as f:
            models = json.load(f)
        return jsonify(models), 200
    except Exception as e:
        return jsonify({"error": f"Failed to load configuration: {e}"}), 500

from flask import Blueprint, request, jsonify
from flask_login import login_user, logout_user, current_user
from werkzeug.security import generate_password_hash, check_password_hash
from itsdangerous import URLSafeTimedSerializer, BadSignature, SignatureExpired
from flask import current_app

from models import db, User

auth_bp = Blueprint("auth", __name__)


def _make_token(user_id):
    s = URLSafeTimedSerializer(current_app.config["SECRET_KEY"])
    return s.dumps(user_id, salt="auth")


def _verify_token(token, max_age=86400 * 30):
    s = URLSafeTimedSerializer(current_app.config["SECRET_KEY"])
    try:
        return s.loads(token, salt="auth", max_age=max_age)
    except (BadSignature, SignatureExpired):
        return None


def token_required(f):
    """Decorator: validates Bearer token (header or query param) and sets flask_login current_user."""
    from functools import wraps

    @wraps(f)
    def decorated(*args, **kwargs):
        auth_header = request.headers.get("Authorization", "")
        token = None
        if auth_header.startswith("Bearer "):
            token = auth_header[7:]
        if not token:
            token = request.args.get("token")
        if not token:
            return jsonify({"error": "Authentication required"}), 401
        user_id = _verify_token(token)
        if user_id is None:
            return jsonify({"error": "Authentication required"}), 401
        user = db.session.get(User, user_id)
        if user is None:
            return jsonify({"error": "Authentication required"}), 401
        login_user(user)
        return f(*args, **kwargs)
    return decorated


def _validate_credentials(username, password):
    """Return error message if username or password is empty/whitespace, else None."""
    if not username or not username.strip():
        return "Username cannot be empty"
    if not password or not password.strip():
        return "Password cannot be empty"
    return None


@auth_bp.route("/register", methods=["POST"])
def register():
    data = request.get_json(silent=True) or {}
    username = data.get("username", "")
    password = data.get("password", "")

    error = _validate_credentials(username, password)
    if error:
        return jsonify({"error": error}), 400

    username = username.strip()

    if User.query.filter_by(username=username).first():
        return jsonify({"error": "Username already exists"}), 409

    user = User(
        username=username,
        password_hash=generate_password_hash(password),
    )
    db.session.add(user)
    db.session.commit()

    login_user(user)
    return jsonify({"message": "registered", "username": user.username, "token": _make_token(user.id)}), 201


@auth_bp.route("/login", methods=["POST"])
def login():
    data = request.get_json(silent=True) or {}
    username = data.get("username", "")
    password = data.get("password", "")

    error = _validate_credentials(username, password)
    if error:
        return jsonify({"error": error}), 400

    username = username.strip()

    user = User.query.filter_by(username=username).first()
    if not user or not check_password_hash(user.password_hash, password):
        return jsonify({"error": "Invalid credentials"}), 401

    login_user(user)
    return jsonify({"message": "logged in", "username": user.username, "token": _make_token(user.id)}), 200


@auth_bp.route("/logout", methods=["POST"])
def logout():
    logout_user()
    return jsonify({"message": "logged out"}), 200


@auth_bp.route("/password", methods=["PUT"])
@token_required
def change_password():
    data = request.get_json(silent=True) or {}
    old_password = data.get("old_password", "")
    new_password = data.get("new_password", "")

    if not old_password or not new_password:
        return jsonify({"error": "old_password and new_password are required"}), 400

    if not check_password_hash(current_user.password_hash, old_password):
        return jsonify({"error": "Invalid credentials"}), 401

    current_user.password_hash = generate_password_hash(new_password)
    db.session.commit()

    return jsonify({"message": "password updated"}), 200

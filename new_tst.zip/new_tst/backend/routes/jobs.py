import io
import json
import os
import threading
import uuid
import shutil
import zipfile
from queue import Queue

from flask import Blueprint, request, jsonify, current_app, Response, stream_with_context, send_file
from flask_login import login_required, current_user

from models import db, Job, User
from routes.auth import token_required

jobs_bp = Blueprint("jobs", __name__)

# Module-level dict mapping job_id -> (DeepAgent instance, Queue)
_active_agents: dict = {}


@jobs_bp.route("", methods=["GET"])
@token_required
def list_jobs():
    """GET /api/jobs — list all jobs for the current user."""
    jobs = Job.query.filter_by(user_id=current_user.id).order_by(Job.created_at.desc()).all()
    result = []
    for job in jobs:
        # Count completed subagent steps by counting subdirs in workspace (excluding 'context')
        steps_completed = 0
        if job.workspace_path and os.path.isdir(job.workspace_path):
            steps_completed = sum(
                1 for entry in os.scandir(job.workspace_path)
                if entry.is_dir() and entry.name not in ("context",)
            )
        result.append({
            "job_id": job.id,
            "pipeline_key": job.pipeline_key,
            "from_code": job.from_code or "",
            "to_code": job.to_code or "",
            "model_name": job.model_name,
            "status": job.status,
            "steps_completed": steps_completed,
            "created_at": job.created_at.isoformat(),
        })
    return jsonify(result), 200


@jobs_bp.route("", methods=["POST"])
@token_required
def create_job():
    """POST /api/jobs — create a new modernization job."""
    # Validate required form fields
    pipeline_key = request.form.get("pipeline_key", "").strip()
    model_name = request.form.get("model_name", "").strip()
    from_code = request.form.get("from_code", "").strip()
    to_code = request.form.get("to_code", "").strip()

    if not pipeline_key:
        return jsonify({"error": "pipeline_key is required"}), 400
    if not model_name:
        return jsonify({"error": "model_name is required"}), 400

    # Validate source_zip
    source_zip = request.files.get("source_zip")
    if not source_zip:
        return jsonify({"error": "source_zip is required"}), 400

    filename = source_zip.filename or ""
    content_type = source_zip.content_type or ""
    is_zip = filename.lower().endswith(".zip") or content_type in (
        "application/zip",
        "application/x-zip-compressed",
        "application/octet-stream",
    )
    # Prefer filename check; if filename doesn't end with .zip, reject
    if not filename.lower().endswith(".zip"):
        return jsonify({"error": "Source file must be a ZIP archive"}), 400

    context_files = request.files.getlist("context_files")

    job_id = str(uuid.uuid4())
    workspaces_dir = current_app.config["WORKSPACES_DIR"]
    workspace_path = os.path.join(workspaces_dir, job_id)

    try:
        # Create workspace directory
        os.makedirs(workspace_path, exist_ok=True)

        # Save source ZIP
        source_zip.save(os.path.join(workspace_path, "source.zip"))

        # Save context files
        if context_files:
            context_dir = os.path.join(workspace_path, "context")
            os.makedirs(context_dir, exist_ok=True)
            for cf in context_files:
                if cf and cf.filename:
                    cf.save(os.path.join(context_dir, cf.filename))

        # Create Job DB record
        job = Job(
            id=job_id,
            user_id=current_user.id,
            pipeline_key=pipeline_key,
            model_name=model_name,
            from_code=from_code or None,
            to_code=to_code or None,
            workspace_path=workspace_path,
            status="pending",
        )
        db.session.add(job)
        db.session.commit()

        return jsonify({"job_id": job_id}), 201

    except Exception as exc:
        db.session.rollback()
        # Clean up workspace directory on failure
        if os.path.exists(workspace_path):
            shutil.rmtree(workspace_path, ignore_errors=True)
        current_app.logger.error("Job creation failed: %s", exc)
        return jsonify({"error": f"Failed to create job: {exc}"}), 500


@jobs_bp.route("/<job_id>/stream", methods=["GET"])
def stream_job(job_id):
    """GET /api/jobs/<job_id>/stream — SSE endpoint for job progress."""
    from routes.auth import _verify_token
    from flask_login import login_user as _login_user
    token = request.args.get("token")
    if token:
        user_id = _verify_token(token)
        if user_id:
            u = db.session.get(User, user_id)
            if u:
                _login_user(u)

    app = current_app._get_current_object()

    with app.app_context():
        job = db.session.get(Job, job_id)
        if job is None:
            return jsonify({"error": "Job not found"}), 404

        if job_id not in _active_agents:
            # Always load pipeline + model config when starting a new agent
            pipeline_config_path = app.config["PIPELINE_CONFIG"]
            with open(pipeline_config_path, "r", encoding="utf-8") as f:
                all_pipelines = json.load(f)
            pipeline = all_pipelines.get(job.pipeline_key, {})

            model_config_path = app.config["MODEL_CONFIG"]
            with open(model_config_path, "r", encoding="utf-8") as f:
                all_models = json.load(f)
            model = next((m for m in all_models if m["model_name"] == job.model_name), {})

            workspace_path = job.workspace_path
        else:
            # Re-attach to existing running agent
            pipeline = None
            model = None
            workspace_path = None

    def generate():
        import traceback

        # Use MockDeepAgent when MOCK_AGENT=1 is set
        use_mock = os.environ.get("MOCK_AGENT", "0") == "1"
        if use_mock:
            from mock_deepagent import MockDeepAgent as AgentClass
        else:
            from deepagent import DeepAgent as AgentClass

        try:
            if job_id not in _active_agents:
                q = Queue()
                agent = AgentClass(
                    job_id=job_id,
                    pipeline=pipeline,
                    model=model,
                    workspace_path=workspace_path,
                )
                agent._app = app
                _active_agents[job_id] = (agent, q)

                t = threading.Thread(target=agent.run, args=(q,), daemon=True)
                t.name = f"deepagent-{job_id[:8]}"
                t.start()
            else:
                agent, q = _active_agents[job_id]

            # Send a heartbeat comment immediately so the browser knows the connection is alive
            yield ": connected\n\n"

            while True:
                # Use timeout so we can send keepalive pings and detect dead connections
                try:
                    event_dict = q.get(timeout=25)
                except Exception:
                    # Send SSE comment as keepalive ping
                    yield ": ping\n\n"
                    continue

                event_name = event_dict.get("event", "message")
                data = event_dict.get("data", {})
                yield f"event: {event_name}\ndata: {json.dumps(data)}\n\n"

                if event_name in ("pipeline_complete", "error"):
                    _active_agents.pop(job_id, None)
                    break

        except GeneratorExit:
            # Client disconnected — leave agent running, it will be re-attached on reconnect
            pass
        except Exception as exc:
            err_detail = traceback.format_exc()
            app.logger.error("SSE generator error for job %s:\n%s", job_id, err_detail)
            try:
                yield f"event: error\ndata: {json.dumps({'message': str(exc)})}\n\n"
            except Exception:
                pass
            _active_agents.pop(job_id, None)

    response = Response(
        stream_with_context(generate()),
        content_type="text/event-stream",
    )
    response.headers["Cache-Control"] = "no-cache"
    response.headers["X-Accel-Buffering"] = "no"
    return response


@jobs_bp.route("/<job_id>/feedback", methods=["POST"])
@token_required
def submit_feedback(job_id):
    """POST /api/jobs/<job_id>/feedback — submit user feedback at an interrupt."""
    app = current_app._get_current_object()

    with app.app_context():
        job = db.session.get(Job, job_id)
        if job is None:
            return jsonify({"error": "Job not found"}), 404

        if job.status != "awaiting_feedback":
            return jsonify({"error": "Job is not awaiting feedback"}), 400

    if job_id not in _active_agents:
        return jsonify({"error": "No active agent found for this job"}), 400

    body = request.get_json(silent=True) or {}
    feedback = body.get("feedback", "")

    agent, _ = _active_agents[job_id]
    agent.submit_feedback(feedback)

    with app.app_context():
        job = db.session.get(Job, job_id)
        if job:
            job.status = "running"
            db.session.commit()

    return jsonify({"message": "feedback submitted"}), 200


@jobs_bp.route("/<job_id>/files", methods=["GET"])
@token_required
def list_workspace_files(job_id):
    """GET /api/jobs/<job_id>/files — list output files or get a single file's content.

    Query params:
      ?path=<relative-path>  — return content of a single file
      (no path)              — return a tree of all files in specs/, target_codebase/, validation/
    """
    job = db.session.get(Job, job_id)
    if job is None:
        return jsonify({"error": "Job not found"}), 404

    workspace_path = job.workspace_path
    if not os.path.isdir(workspace_path):
        return jsonify({"error": "Workspace not found"}), 404

    requested_path = request.args.get("path")
    output_dirs = ("specs", "target_codebase", "validation")

    if requested_path:
        # Serve a single file
        # Normalize and prevent path traversal
        safe_path = os.path.normpath(requested_path).replace("\\", "/")
        if safe_path.startswith("..") or os.path.isabs(safe_path):
            return jsonify({"error": "Invalid path"}), 400

        top_dir = safe_path.split("/")[0]
        if top_dir not in output_dirs:
            return jsonify({"error": f"Path must be within: {', '.join(output_dirs)}"}), 400

        full_path = os.path.join(workspace_path, safe_path)
        if not os.path.isfile(full_path):
            return jsonify({"error": "File not found"}), 404

        try:
            with open(full_path, "r", encoding="utf-8", errors="replace") as fh:
                content = fh.read()
        except Exception as exc:
            return jsonify({"error": f"Could not read file: {exc}"}), 500

        return jsonify({"path": safe_path, "content": content}), 200

    # List all files across the output directories
    files = []
    for d in output_dirs:
        dir_path = os.path.join(workspace_path, d)
        if not os.path.isdir(dir_path):
            continue
        for root, _dirs, filenames in os.walk(dir_path):
            for fname in filenames:
                file_path = os.path.join(root, fname)
                rel = os.path.relpath(file_path, workspace_path).replace("\\", "/")
                try:
                    size = os.path.getsize(file_path)
                except OSError:
                    size = 0
                files.append({"path": rel, "size": size})

    return jsonify({"files": files}), 200


@jobs_bp.route("/<job_id>/download", methods=["GET"])
@token_required
def download_workspace(job_id):
    """GET /api/jobs/<job_id>/download — download workspace as a ZIP archive."""
    """GET /api/jobs/<job_id>/download — download workspace as a ZIP archive."""
    job = db.session.get(Job, job_id)
    if job is None:
        return jsonify({"error": "Job not found"}), 404

    workspace_path = job.workspace_path
    if not os.path.isdir(workspace_path):
        return jsonify({"error": "Workspace not found"}), 404

    # Build ZIP in memory
    zip_buffer = io.BytesIO()
    with zipfile.ZipFile(zip_buffer, "w", zipfile.ZIP_DEFLATED) as zf:
        for root, _dirs, files in os.walk(workspace_path):
            for filename in files:
                file_path = os.path.join(root, filename)
                arcname = os.path.relpath(file_path, workspace_path)
                zf.write(file_path, arcname)
    zip_buffer.seek(0)

    return send_file(
        zip_buffer,
        mimetype="application/zip",
        as_attachment=True,
        download_name=f"workspace_{job_id}.zip",
    )

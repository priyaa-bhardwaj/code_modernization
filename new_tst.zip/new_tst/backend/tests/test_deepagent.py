"""
Unit tests for DeepAgent.

Covers:
- Subagents execute in pipeline order (SSE events order)
- Pipeline pauses at interrupt and does not advance until submit_feedback is called
- Error SSE event emitted and job status set to 'failed' on subagent exception
- Subagent output persisted to workspace directory
"""

import os
import threading
import time
import uuid
from queue import Queue, Empty

import pytest

from app import create_app
from models import db as _db, Job, User
from deepagent import DeepAgent


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture(scope="module")
def app():
    _app = create_app("testing")
    with _app.app_context():
        _db.create_all()
        yield _app
        _db.drop_all()


@pytest.fixture()
def db_session(app, tmp_path):
    """Provide a clean DB session and a temp workspace for each test."""
    with app.app_context():
        # Create a dummy user
        user = User(username=f"u_{uuid.uuid4().hex[:8]}", password_hash="x")
        _db.session.add(user)
        _db.session.flush()

        job_id = str(uuid.uuid4())
        workspace = str(tmp_path / job_id)
        os.makedirs(workspace, exist_ok=True)

        job = Job(
            id=job_id,
            user_id=user.id,
            pipeline_key="test-pipeline",
            model_name="test-model",
            workspace_path=workspace,
            status="pending",
        )
        _db.session.add(job)
        _db.session.commit()

        yield app, job_id, workspace

        _db.session.query(Job).filter_by(id=job_id).delete()
        _db.session.query(User).filter_by(id=user.id).delete()
        _db.session.commit()


def make_agent(app, job_id, workspace, subagents, system_prompt="sys"):
    pipeline = {"system_prompt": system_prompt, "subagents": subagents}
    model = {"model_name": "test-model"}
    agent = DeepAgent(job_id, pipeline, model, workspace)
    agent._app = app
    return agent


def drain_queue(q, timeout=2.0):
    """Collect all items currently in the queue (with a short timeout)."""
    items = []
    deadline = time.time() + timeout
    while time.time() < deadline:
        try:
            items.append(q.get(timeout=0.05))
        except Empty:
            break
    return items


# ---------------------------------------------------------------------------
# Test: subagents execute in pipeline order
# ---------------------------------------------------------------------------

def test_subagents_execute_in_pipeline_order(db_session):
    """SSE subagent_started events must appear in the same order as the pipeline."""
    app, job_id, workspace = db_session
    subagents = ["alpha", "beta", "gamma"]
    agent = make_agent(app, job_id, workspace, subagents)
    q = Queue()

    def run_and_auto_approve():
        # Run in a thread; auto-approve each interrupt immediately
        def _runner():
            # Monkey-patch _feedback_event.wait to auto-set after a tiny delay
            original_wait = agent._feedback_event.wait

            def auto_wait():
                # Give the queue a moment to receive the interrupt event, then unblock
                time.sleep(0.05)
                agent._feedback_event.set()

            agent._feedback_event.wait = auto_wait
            agent.run(q)

        t = threading.Thread(target=_runner, daemon=True)
        t.start()
        t.join(timeout=5)

    run_and_auto_approve()

    events = drain_queue(q)
    started_events = [e for e in events if e["event"] == "subagent_started"]
    assert len(started_events) == len(subagents)
    for i, ev in enumerate(started_events):
        assert ev["data"]["subagent"] == subagents[i]
        assert ev["data"]["index"] == i


# ---------------------------------------------------------------------------
# Test: pipeline pauses at interrupt until submit_feedback is called
# ---------------------------------------------------------------------------

def test_pipeline_pauses_at_interrupt_until_feedback(db_session):
    """After the first interrupt, the second subagent_started must NOT appear
    until submit_feedback() is called."""
    app, job_id, workspace = db_session
    subagents = ["step1", "step2"]
    agent = make_agent(app, job_id, workspace, subagents)
    q = Queue()

    t = threading.Thread(target=agent.run, args=(q,), daemon=True)
    t.start()

    # Wait for the interrupt event from step1
    interrupt_received = False
    deadline = time.time() + 3.0
    while time.time() < deadline:
        try:
            ev = q.get(timeout=0.1)
            if ev["event"] == "interrupt" and ev["data"]["subagent"] == "step1":
                interrupt_received = True
                break
        except Empty:
            pass

    assert interrupt_received, "Expected interrupt event for step1"

    # Give the pipeline a moment — step2 should NOT have started yet
    time.sleep(0.2)
    buffered = drain_queue(q, timeout=0.1)
    step2_started = any(
        e["event"] == "subagent_started" and e["data"]["subagent"] == "step2"
        for e in buffered
    )
    assert not step2_started, "step2 should not start before feedback is submitted"

    # Now submit feedback — pipeline should advance
    agent.submit_feedback("approved")
    t.join(timeout=5)

    remaining = drain_queue(q)
    step2_started_after = any(
        e["event"] == "subagent_started" and e["data"]["subagent"] == "step2"
        for e in remaining
    )
    assert step2_started_after, "step2 should start after feedback is submitted"


# ---------------------------------------------------------------------------
# Test: error SSE event emitted and job status set to 'failed' on exception
# ---------------------------------------------------------------------------

def test_error_event_and_failed_status_on_subagent_exception(db_session):
    """When a subagent raises, an error SSE event is emitted and job status → failed."""
    app, job_id, workspace = db_session
    subagents = ["bad_agent"]
    agent = make_agent(app, job_id, workspace, subagents)

    # Override _invoke_subagent to raise
    def _failing_invoke(name, feedback):
        raise RuntimeError("subagent exploded")

    agent._invoke_subagent = _failing_invoke

    q = Queue()
    agent.run(q)  # runs synchronously (no wait needed — fails immediately)

    events = drain_queue(q)
    error_events = [e for e in events if e["event"] == "error"]
    assert len(error_events) == 1
    assert "subagent exploded" in error_events[0]["data"]["message"]

    # Verify DB status
    with app.app_context():
        job = _db.session.get(Job, job_id)
        assert job.status == "failed"


# ---------------------------------------------------------------------------
# Test: subagent output persisted to workspace directory
# ---------------------------------------------------------------------------

def test_subagent_output_persisted_to_workspace(db_session):
    """Each subagent's output must be written to {workspace}/{subagent}/output.txt."""
    app, job_id, workspace = db_session
    subagents = ["writer_agent"]
    agent = make_agent(app, job_id, workspace, subagents)
    q = Queue()

    def run_with_auto_approve():
        original_wait = agent._feedback_event.wait

        def auto_wait():
            time.sleep(0.05)
            agent._feedback_event.set()

        agent._feedback_event.wait = auto_wait
        agent.run(q)

    run_with_auto_approve()

    output_file = os.path.join(workspace, "writer_agent", "output.txt")
    assert os.path.isfile(output_file), f"Expected output file at {output_file}"
    content = open(output_file).read()
    assert "writer_agent" in content

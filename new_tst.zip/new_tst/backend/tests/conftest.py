import sys
import os
import pytest

# Ensure backend/ is on the path so imports work
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from app import create_app
from models import db as _db


@pytest.fixture(scope="session")
def app():
    """Create application with in-memory SQLite for the test session."""
    _app = create_app("testing")
    with _app.app_context():
        _db.create_all()
        yield _app
        _db.drop_all()


@pytest.fixture(scope="function")
def db(app):
    """Provide a clean DB for each test function (rolls back after each test)."""
    with app.app_context():
        connection = _db.engine.connect()
        transaction = connection.begin()

        # Bind session to the connection so we can roll back
        _db.session.bind = connection

        yield _db

        _db.session.remove()
        transaction.rollback()
        connection.close()


@pytest.fixture(scope="function")
def client(app, db):
    """Flask test client with a clean DB per test."""
    with app.test_client() as c:
        yield c

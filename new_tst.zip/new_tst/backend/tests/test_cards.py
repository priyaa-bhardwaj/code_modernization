import json
import pytest


def test_get_cards_returns_200_with_correct_fields(client, tmp_path, app):
    """Test that GET /api/cards returns 200 with all required fields."""
    cards_data = [
        {"from_code": "Smalltalk", "to_code": "Java", "description": "Migrate Smalltalk to Java"},
        {"from_code": "COBOL", "to_code": "Python", "description": "Modernize COBOL to Python"},
    ]
    cards_file = tmp_path / "cards_config.json"
    cards_file.write_text(json.dumps(cards_data))

    with app.test_request_context():
        app.config["CARDS_CONFIG"] = str(cards_file)

    with app.test_client() as c:
        app.config["CARDS_CONFIG"] = str(cards_file)
        response = c.get("/api/cards")

    assert response.status_code == 200
    data = response.get_json()
    assert isinstance(data, list)
    assert len(data) == 2
    for card in data:
        assert "from_code" in card
        assert "to_code" in card
        assert "description" in card


def test_get_cards_returns_500_when_file_missing(app):
    """Test that GET /api/cards returns 500 when config file is missing."""
    with app.test_client() as c:
        app.config["CARDS_CONFIG"] = "/nonexistent/path/cards_config.json"
        response = c.get("/api/cards")

    assert response.status_code == 500
    data = response.get_json()
    assert "error" in data
    assert "Failed to load configuration" in data["error"]

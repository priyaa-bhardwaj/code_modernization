import pytest


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def register(client, username, password):
    return client.post(
        "/api/auth/register",
        json={"username": username, "password": password},
    )


def login(client, username, password):
    return client.post(
        "/api/auth/login",
        json={"username": username, "password": password},
    )


def logout(client):
    return client.post("/api/auth/logout")


def change_password(client, old_password, new_password):
    return client.put(
        "/api/auth/password",
        json={"old_password": old_password, "new_password": new_password},
    )


# ---------------------------------------------------------------------------
# Register — 400 on empty / whitespace
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("username,password", [
    ("", "secret"),
    ("   ", "secret"),
    ("alice", ""),
    ("alice", "   "),
])
def test_register_400_on_empty_or_whitespace(client, username, password):
    resp = register(client, username, password)
    assert resp.status_code == 400


# ---------------------------------------------------------------------------
# Login — 400 on empty / whitespace
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("username,password", [
    ("", "secret"),
    ("   ", "secret"),
    ("alice", ""),
    ("alice", "   "),
])
def test_login_400_on_empty_or_whitespace(client, username, password):
    resp = login(client, username, password)
    assert resp.status_code == 400


# ---------------------------------------------------------------------------
# Register — 409 on duplicate username
# ---------------------------------------------------------------------------

def test_register_409_on_duplicate_username(client):
    register(client, "bob", "pass1")
    resp = register(client, "bob", "pass2")
    assert resp.status_code == 409
    assert "already exists" in resp.get_json()["error"].lower()


# ---------------------------------------------------------------------------
# Login — 401 on invalid credentials
# ---------------------------------------------------------------------------

def test_login_401_on_wrong_password(client):
    register(client, "carol", "correct")
    resp = login(client, "carol", "wrong")
    assert resp.status_code == 401


def test_login_401_on_unknown_user(client):
    resp = login(client, "nobody", "pass")
    assert resp.status_code == 401


# ---------------------------------------------------------------------------
# Successful register → 201
# ---------------------------------------------------------------------------

def test_register_success_returns_201(client):
    resp = register(client, "dave", "mypassword")
    assert resp.status_code == 201
    assert resp.get_json()["message"] == "registered"


# ---------------------------------------------------------------------------
# Successful login → 200 with username
# ---------------------------------------------------------------------------

def test_login_success_returns_200_with_username(client):
    register(client, "eve", "evespass")
    resp = login(client, "eve", "evespass")
    assert resp.status_code == 200
    data = resp.get_json()
    assert data["message"] == "logged in"
    assert data["username"] == "eve"


# ---------------------------------------------------------------------------
# Logout → 200
# ---------------------------------------------------------------------------

def test_logout_returns_200(client):
    register(client, "frank", "frankpass")
    login(client, "frank", "frankpass")
    resp = logout(client)
    assert resp.status_code == 200
    assert resp.get_json()["message"] == "logged out"


# ---------------------------------------------------------------------------
# Password change — requires authentication
# ---------------------------------------------------------------------------

def test_password_change_requires_auth(client):
    # Not logged in — should get 401
    resp = change_password(client, "old", "new")
    assert resp.status_code == 401


# ---------------------------------------------------------------------------
# Successful password change → 200
# ---------------------------------------------------------------------------

def test_password_change_success(client):
    register(client, "grace", "oldpass")
    login(client, "grace", "oldpass")
    resp = change_password(client, "oldpass", "newpass")
    assert resp.status_code == 200
    assert resp.get_json()["message"] == "password updated"

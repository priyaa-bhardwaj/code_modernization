import json
import pytest


def test_get_pipelines_returns_200(app, tmp_path):
    """Test that GET /api/pipelines returns 200 with pipeline data."""
    pipeline_data = {
        "code->spec->code": {
            "system_prompt": "You are a code modernization assistant.",
            "subagents": ["spec_generator", "code_generator", "validator"],
        }
    }
    pipeline_file = tmp_path / "pipeline.json"
    pipeline_file.write_text(json.dumps(pipeline_data))

    with app.test_client() as c:
        app.config["PIPELINE_CONFIG"] = str(pipeline_file)
        response = c.get("/api/pipelines")

    assert response.status_code == 200
    data = response.get_json()
    assert isinstance(data, dict)
    assert "code->spec->code" in data
    entry = data["code->spec->code"]
    assert "system_prompt" in entry
    assert "subagents" in entry


def test_get_models_returns_200(app, tmp_path):
    """Test that GET /api/models returns 200 with model data."""
    model_data = [
        {"model_name": "gpt-4o", "provider": "OpenAI", "key": "", "url": "https://api.openai.com/v1"}
    ]
    model_file = tmp_path / "model.json"
    model_file.write_text(json.dumps(model_data))

    with app.test_client() as c:
        app.config["MODEL_CONFIG"] = str(model_file)
        response = c.get("/api/models")

    assert response.status_code == 200
    data = response.get_json()
    assert isinstance(data, list)
    assert len(data) == 1
    model = data[0]
    assert "model_name" in model
    assert "provider" in model
    assert "key" in model
    assert "url" in model


def test_get_pipelines_returns_500_when_file_missing(app):
    """Test that GET /api/pipelines returns 500 when config file is missing."""
    with app.test_client() as c:
        app.config["PIPELINE_CONFIG"] = "/nonexistent/path/pipeline.json"
        response = c.get("/api/pipelines")

    assert response.status_code == 500
    data = response.get_json()
    assert "error" in data
    assert "Failed to load configuration" in data["error"]


def test_get_models_returns_500_when_file_missing(app):
    """Test that GET /api/models returns 500 when config file is missing."""
    with app.test_client() as c:
        app.config["MODEL_CONFIG"] = "/nonexistent/path/model.json"
        response = c.get("/api/models")

    assert response.status_code == 500
    data = response.get_json()
    assert "error" in data
    assert "Failed to load configuration" in data["error"]

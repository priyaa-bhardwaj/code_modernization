import io
import os
import pytest


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def register_and_login(client, username="testuser", password="testpass"):
    client.post("/api/auth/register", json={"username": username, "password": password})
    client.post("/api/auth/login", json={"username": username, "password": password})


def make_zip_file(filename="source.zip"):
    """Return a FileStorage-compatible tuple for a fake ZIP file."""
    # A minimal valid ZIP magic bytes header
    zip_bytes = b"PK\x03\x04" + b"\x00" * 26
    return (io.BytesIO(zip_bytes), filename)


def post_job(client, pipeline_key="code->spec->code", model_name="gpt-4o",
             source_zip=None, context_files=None):
    data = {}
    if pipeline_key is not None:
        data["pipeline_key"] = pipeline_key
    if model_name is not None:
        data["model_name"] = model_name
    if source_zip is not None:
        data["source_zip"] = source_zip
    if context_files is not None:
        data["context_files"] = context_files
    return client.post("/api/jobs", data=data, content_type="multipart/form-data")


# ---------------------------------------------------------------------------
# 400 — non-ZIP source file
# ---------------------------------------------------------------------------

def test_400_on_non_zip_source_file(client):
    register_and_login(client, "user_nonzip", "pass")
    txt_file = (io.BytesIO(b"hello world"), "source.txt")
    resp = post_job(client, source_zip=txt_file)
    assert resp.status_code == 400
    assert "zip" in resp.get_json()["error"].lower()


# ---------------------------------------------------------------------------
# 400 — missing required fields
# ---------------------------------------------------------------------------

def test_400_on_missing_source_zip(client):
    register_and_login(client, "user_nzip", "pass")
    resp = post_job(client, source_zip=None)
    assert resp.status_code == 400


def test_400_on_missing_pipeline_key(client):
    register_and_login(client, "user_nopipe", "pass")
    resp = post_job(client, pipeline_key=None, source_zip=make_zip_file())
    assert resp.status_code == 400
    assert "pipeline_key" in resp.get_json()["error"].lower()


def test_400_on_missing_model_name(client):
    register_and_login(client, "user_nomodel", "pass")
    resp = post_job(client, model_name=None, source_zip=make_zip_file())
    assert resp.status_code == 400
    assert "model_name" in resp.get_json()["error"].lower()


# ---------------------------------------------------------------------------
# 401 — unauthenticated
# ---------------------------------------------------------------------------

def test_401_when_not_logged_in(client):
    resp = post_job(client, source_zip=make_zip_file())
    assert resp.status_code == 401


# ---------------------------------------------------------------------------
# 201 — successful job creation
# ---------------------------------------------------------------------------

def test_successful_job_creation_returns_201_with_job_id(client):
    register_and_login(client, "user_ok", "pass")
    resp = post_job(client, source_zip=make_zip_file())
    assert resp.status_code == 201
    data = resp.get_json()
    assert "job_id" in data
    assert len(data["job_id"]) == 36  # UUID format


# ---------------------------------------------------------------------------
# DB record created with correct fields
# ---------------------------------------------------------------------------

def test_job_record_created_in_db_with_correct_fields(client, db, app):
    register_and_login(client, "user_db", "pass")
    resp = post_job(
        client,
        pipeline_key="code->spec->code",
        model_name="gpt-4o",
        source_zip=make_zip_file(),
    )
    assert resp.status_code == 201
    job_id = resp.get_json()["job_id"]

    from models import Job
    with app.app_context():
        job = db.session.get(Job, job_id)
        assert job is not None
        assert job.pipeline_key == "code->spec->code"
        assert job.model_name == "gpt-4o"
        assert job.status == "pending"
        assert job.workspace_path is not None
        assert job.user_id is not None


# ---------------------------------------------------------------------------
# Workspace directory and source.zip created
# ---------------------------------------------------------------------------

def test_workspace_directory_created_with_source_zip(client, app):
    register_and_login(client, "user_ws", "pass")
    resp = post_job(client, source_zip=make_zip_file())
    assert resp.status_code == 201
    job_id = resp.get_json()["job_id"]

    workspaces_dir = app.config["WORKSPACES_DIR"]
    workspace_path = os.path.join(workspaces_dir, job_id)
    assert os.path.isdir(workspace_path)
    assert os.path.isfile(os.path.join(workspace_path, "source.zip"))

# Technical Specification: Order Management System

## 1. Overview
This document describes the modernization specification for a legacy Java
Order Management System, targeting Spring Boot 3.x.

## 2. Data Models

### 2.1 User
| Field    | Type   | Constraints       |
|----------|--------|-------------------|
| id       | Long   | Primary Key, Auto |
| username | String | Unique, Not Null  |
| email    | String | Unique, Not Null  |
| role     | Enum   | ADMIN, USER       |

### 2.2 Order
| Field      | Type      | Constraints          |
|------------|-----------|----------------------|
| id         | Long      | Primary Key, Auto    |
| userId     | Long      | FK → User.id         |
| status     | Enum      | PENDING, COMPLETED   |
| totalAmount| BigDecimal| Not Null             |
| createdAt  | Timestamp | Auto-generated       |

## 3. API Endpoints
- `GET    /api/users`       — List all users
- `POST   /api/users`       — Create a new user
- `GET    /api/orders`      — List orders (filterable)
- `POST   /api/orders`      — Place a new order
- `GET    /api/orders/{id}` — Get order details

## 4. Business Rules
1. Only authenticated users can place orders
2. Order total must be > 0
3. Users with ADMIN role can view all orders

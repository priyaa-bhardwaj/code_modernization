# Account Class Technical Specification

## 1. Overview
The `Account` class in Smalltalk represents a single bank account or checkbook. It manages a ledger of financial transactions, calculates various balances, and provides functionalities for deposits, withdrawals, fee additions, interest crediting, and transaction management. It supports different account types such as checking, savings, credit card, and cash.

## 2. Data Structures

### 2.1 Instance Variables
The `Account` class has the following instance variables:
- `accountId`: A unique identifier for the account (String).
- `accountName`: The name of the account (String).
- `accountType`: The type of account, represented as a Symbol (e.g., `#checking`, `#savings`, `#creditCard`, `#cash`).
- `currency`: The currency of the account (String).
- `transactions`: An `OrderedCollection` of `Transaction` objects, representing the ledger of all financial movements.
- `openedOn`: The date the account was opened (Date).
- `interestRate`: The annual interest rate applicable to the account (Float).
- `overdraftLimit`: The maximum allowed overdraft for the account (Money object).
- `owner`: The owner of the account (presumably an `AccountHolder` object or similar identifier).

### 2.2 Class Variables
- None.

### 2.3 Pool Dictionaries
- None.

## 3. Functionality and Methods

### 3.1 Class Methods for Instance Creation

#### `id: anId name: aName type: aSymbol currency: aCurrency owner: anOwner`
- **Description**: Creates a new `Account` instance with specified details.
- **Parameters**:
    - `anId`: Account ID (String).
    - `aName`: Account name (String).
    - `aSymbol`: Account type (Symbol).
    - `aCurrency`: Account currency (String).
    - `anOwner`: Account owner.
- **Returns**: A new `Account` object.

#### `checking: aName currency: aCurrency owner: anOwner`
- **Description**: Convenience method to create a new checking account. Generates a unique ID.
- **Parameters**:
    - `aName`: Account name (String).
    - `aCurrency`: Account currency (String).
    - `anOwner`: Account owner.
- **Returns**: A new `Account` object of type `#checking`.

#### `savings: aName currency: aCurrency owner: anOwner`
- **Description**: Convenience method to create a new savings account. Generates a unique ID.
- **Parameters**:
    - `aName`: Account name (String).
    - `aCurrency`: Account currency (String).
    - `anOwner`: Account owner.
- **Returns**: A new `Account` object of type `#savings`.

#### `generateId`
- **Description**: Generates a unique account ID in the format `ACCT-YYYYMMDD-XXXX` (where XXXX is a random 4-digit number).
- **Returns**: A String representing the generated ID.

#### `fromDictionary: aDict`
- **Description**: Reconstructs an `Account` object from a dictionary representation.
- **Parameters**:
    - `aDict`: A Dictionary containing account data.
- **Returns**: A new `Account` object populated from the dictionary.

### 3.2 Private Methods

#### `pvtSetId: anId name: aName type: aSymbol currency: aCurrency owner: anOwner`
- **Description**: Initializes the instance variables of a new `Account` object. Sets `openedOn` to today's date and initializes `transactions` as an empty `OrderedCollection`, `interestRate` to 0.0, and `overdraftLimit` to zero.
- **Parameters**: Same as `id:name:type:currency:owner:`.

#### `pvtFromDictionary: aDict`
- **Description**: Populates instance variables from a dictionary, handling type conversions and default values for optional fields like `interestRate` and `overdraftLimit`. It also reconstructs `Transaction` objects from their dictionary representations.
- **Parameters**:
    - `aDict`: A Dictionary containing account data.

### 3.3 Accessing Methods (Getters and Setters)

#### Getters:
- `accountId`: Returns the account ID.
- `accountName`: Returns the account name.
- `accountType`: Returns the account type.
- `currency`: Returns the account currency.
- `openedOn`: Returns the date the account was opened.
- `interestRate`: Returns the interest rate.
- `overdraftLimit`: Returns the overdraft limit.
- `owner`: Returns the account owner.
- `transactions`: Returns a copy of the transactions collection to prevent external modification.

#### Setters:
- `accountName: aString`: Sets the account name.
- `interestRate: aRate`: Sets the interest rate (converts `aRate` to Float).
- `overdraftLimit: aMoney`: Sets the overdraft limit (expects a `Money` object).

### 3.4 Balance Query Methods

#### `balance`
- **Description**: Calculates the current balance by summing all transaction amounts.
- **Returns**: A `Money` object representing the total balance.

#### `clearedBalance`
- **Description**: Calculates the balance considering only cleared transactions.
- **Returns**: A `Money` object representing the cleared balance.

#### `availableBalance`
- **Description**: Calculates the available balance (cleared balance plus overdraft limit).
- **Returns**: A `Money` object representing the available balance.

#### `runningBalance`
- **Description**: Computes a running balance for all transactions, sorted by date.
- **Returns**: An `OrderedCollection` of `(Transaction -> Money)` pairs, where `Money` is the balance after that transaction.

### 3.5 Transaction Operations

#### `deposit: aMoney description: aString`
- **Description**: Records a deposit transaction with today's date.
- **Parameters**:
    - `aMoney`: The amount to deposit (Money object).
    - `aString`: Description of the deposit.
- **Returns**: The newly created `Transaction` object.

#### `deposit: aMoney description: aString on: aDate`
- **Description**: Records a deposit transaction on a specified date.
- **Parameters**:
    - `aMoney`: The amount to deposit (Money object).
    - `aString`: Description of the deposit.
    - `aDate`: The date of the deposit (Date object).
- **Returns**: The newly created `Transaction` object.

#### `withdraw: aMoney description: aString`
- **Description**: Records a withdrawal transaction with today's date. Checks for overdraft limits.
- **Parameters**:
    - `aMoney`: The amount to withdraw (Money object).
    - `aString`: Description of the withdrawal.
- **Returns**: The newly created `Transaction` object.
- **Raises**: `InsufficientFundsError` if the withdrawal would exceed the overdraft limit.

#### `withdraw: aMoney description: aString on: aDate`
- **Description**: Records a withdrawal transaction on a specified date. Checks for overdraft limits.
- **Parameters**:
    - `aMoney`: The amount to withdraw (Money object).
    - `aString`: Description of the withdrawal.
    - `aDate`: The date of the withdrawal (Date object).
- **Returns**: The newly created `Transaction` object.
- **Raises**: `InsufficientFundsError` if the withdrawal would exceed the overdraft limit.

#### `addFee: aMoney description: aString on: aDate`
- **Description**: Adds a fee transaction to the account.
- **Parameters**:
    - `aMoney`: The fee amount (Money object).
    - `aString`: Description of the fee.
    - `aDate`: The date of the fee (Date object).
- **Returns**: The newly created `Transaction` object.

#### `creditInterest`
- **Description**: Calculates and credits interest to the account based on the current balance and `interestRate`. Interest is credited monthly (rate / 12.0).
- **Returns**: The newly created `Transaction` object for the interest credit, or `nil` if the calculated interest is negative.

#### `removeTransaction: aTransactionId`
- **Description**: Removes a transaction from the ledger based on its ID.
- **Parameters**:
    - `aTransactionId`: The ID of the transaction to remove.

#### `clearTransaction: aTransactionId`
- **Description**: Marks a specific transaction as cleared.
- **Parameters**:
    - `aTransactionId`: The ID of the transaction to clear.
- **Raises**: `TransactionNotFoundError` if the transaction ID is not found.

### 3.6 Searching & Filtering Methods

#### `transactionsFrom: startDate to: endDate`
- **Description**: Filters transactions within a specified date range (inclusive).
- **Parameters**:
    - `startDate`: The start date (Date object).
    - `endDate`: The end date (Date object).
- **Returns**: An `OrderedCollection` of `Transaction` objects.

#### `transactionsOfType: aSymbol`
- **Description**: Filters transactions by their type (e.g., `#deposit`, `#withdrawal`).
- **Parameters**:
    - `aSymbol`: The transaction type (Symbol).
- **Returns**: An `OrderedCollection` of `Transaction` objects.

#### `transactionsInCategory: aCategory`
- **Description**: Filters transactions by their category.
- **Parameters**:
    - `aCategory`: The transaction category.
- **Returns**: An `OrderedCollection` of `Transaction` objects.

#### `searchDescription: aString`
- **Description**: Searches for transactions whose description contains the given string (case-insensitive).
- **Parameters**:
    - `aString`: The string to search for in transaction descriptions.
- **Returns**: An `OrderedCollection` of `Transaction` objects.

### 3.7 Statistics Methods

#### `totalDebits`
- **Description**: Calculates the sum of all debit transaction amounts (as positive values).
- **Returns**: A `Money` object representing the total debits.

#### `totalCredits`
- **Description**: Calculates the sum of all credit transaction amounts.
- **Returns**: A `Money` object representing the total credits.

#### `spendingByCategory`
- **Description**: Aggregates spending (debit transactions) by category.
- **Returns**: A `Dictionary` where keys are categories and values are `Money` objects representing the total spent in that category.

#### `transactionCount`
- **Description**: Returns the total number of transactions in the ledger.
- **Returns**: An Integer.

### 3.8 Converting Methods

#### `asDictionary`
- **Description**: Converts the `Account` object into a dictionary representation, suitable for serialization. It includes all instance variables, with `openedOn` and `transactions` converted to their dictionary forms.
- **Returns**: A `Dictionary` representing the account.

### 3.9 Printing Methods

#### `printOn: aStream`
- **Description**: Defines how the `Account` object should be printed to a stream. It outputs the account name, type, and current balance.
- **Parameters**:
    - `aStream`: The stream to print to.

## 4. Algorithms

- **Balance Calculation**: Simple summation of transaction amounts.
- **Cleared Balance Calculation**: Summation of only transactions marked as cleared.
- **Available Balance Calculation**: Cleared balance + overdraft limit.
- **Running Balance**: Iterates through transactions sorted by date, accumulating the balance.
- **Transaction ID Generation**: Combines date and a random number.
- **Withdrawal Check**: Compares projected balance after withdrawal against the negated overdraft limit.
- **Interest Calculation**: `balance * (interestRate / 12.0)`.
- **Transaction Filtering**: Uses `select:` and `detect:ifFound:ifNone:` for filtering and searching transactions.
- **Spending by Category**: Iterates through debit transactions, accumulating amounts in a dictionary keyed by category.

## 5. Interfaces

The `Account` class interacts with:
- `Money` class: For all monetary operations and representations.
- `Transaction` class: For creating, managing, and querying individual transactions.
- `Date` class: For handling dates (e.g., `openedOn`, transaction dates).
- `OrderedCollection` class: For storing and managing transactions.
- `Dictionary` class: For serialization/deserialization and `spendingByCategory`.
- `Random` class: For generating unique account IDs.
- Error classes: `InsufficientFundsError`, `TransactionNotFoundError` for error handling.

## 6. Error Handling

- `InsufficientFundsError`: Signaled when a withdrawal would cause the account balance to exceed the overdraft limit.
- `TransactionNotFoundError`: Signaled when an attempt is made to clear a transaction with an ID that does not exist in the ledger.

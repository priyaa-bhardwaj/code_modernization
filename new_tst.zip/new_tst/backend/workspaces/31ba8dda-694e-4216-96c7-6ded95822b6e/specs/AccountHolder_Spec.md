# AccountHolder Class Technical Specification

## 1. Overview
The `AccountHolder` class in Smalltalk represents a person or entity that owns one or more bank accounts. It acts as a root aggregate, meaning that operations related to an account holder's accounts typically flow through this class. It manages personal information, a collection of `Account` objects, and provides methods for account management, transfers between accounts, and reporting.

## 2. Data Structures

### 2.1 Instance Variables
The `AccountHolder` class has the following instance variables:
- `holderId`: A unique identifier for the account holder (String, generated using UUID).
- `firstName`: The first name of the account holder (String).
- `lastName`: The last name of the account holder (String).
- `email`: The email address of the account holder (String).
- `phone`: The phone number of the account holder (String, initialized as empty).
- `accounts`: An `OrderedCollection` of `Account` objects owned by this holder.
- `createdAt`: The date the account holder record was created (Date).

### 2.2 Class Variables
- None.

### 2.3 Pool Dictionaries
- None.

## 3. Functionality and Methods

### 3.1 Class Methods for Instance Creation

#### `firstName: aFirst lastName: aLast email: anEmail`
- **Description**: Creates a new `AccountHolder` instance with basic personal information.
- **Parameters**:
    - `aFirst`: First name (String).
    - `aLast`: Last name (String).
    - `anEmail`: Email address (String).
- **Returns**: A new `AccountHolder` object.

#### `fromDictionary: aDict`
- **Description**: Reconstructs an `AccountHolder` object from a dictionary representation.
- **Parameters**:
    - `aDict`: A Dictionary containing account holder data.
- **Returns**: A new `AccountHolder` object populated from the dictionary.

### 3.2 Private Methods

#### `pvtSetFirstName: aFirst lastName: aLast email: anEmail`
- **Description**: Initializes the instance variables of a new `AccountHolder` object. Generates a `holderId` using UUID, sets `createdAt` to today's date, and initializes `phone` as an empty string and `accounts` as an empty `OrderedCollection`.
- **Parameters**: Same as `firstName:lastName:email:`.

#### `pvtFromDictionary: aDict`
- **Description**: Populates instance variables from a dictionary, handling type conversions and default values for optional fields like `phone`. It also reconstructs `Account` objects from their dictionary representations.
- **Parameters**:
    - `aDict`: A Dictionary containing account holder data.

### 3.3 Accessing Methods (Getters and Setters)

#### Getters:
- `holderId`: Returns the account holder's ID.
- `firstName`: Returns the first name.
- `lastName`: Returns the last name.
- `fullName`: Returns the full name (concatenation of first and last names).
- `email`: Returns the email address.
- `phone`: Returns the phone number.
- `accounts`: Returns a copy of the accounts collection.
- `createdAt`: Returns the creation date.

#### Setters:
- `email: aString`: Sets the email address.
- `phone: aString`: Sets the phone number.

### 3.4 Account Management Methods

#### `openCheckingAccount: aName currency: aCurrency`
- **Description**: Creates and adds a new checking account to the holder's accounts. The owner of the new account is set to the `AccountHolder`'s full name.
- **Parameters**:
    - `aName`: The name of the checking account (String).
    - `aCurrency`: The currency of the checking account (String).
- **Returns**: The newly created `Account` object.

#### `openSavingsAccount: aName currency: aCurrency`
- **Description**: Creates and adds a new savings account to the holder's accounts. The owner of the new account is set to the `AccountHolder`'s full name.
- **Parameters**:
    - `aName`: The name of the savings account (String).
    - `aCurrency`: The currency of the savings account (String).
- **Returns**: The newly created `Account` object.

#### `closeAccount: anAccountId`
- **Description**: Removes an account from the holder's collection based on its ID.
- **Parameters**:
    - `anAccountId`: The ID of the account to close.

#### `findAccount: anAccountId`
- **Description**: Locates an account by its ID within the holder's accounts.
- **Parameters**:
    - `anAccountId`: The ID of the account to find.
- **Returns**: The `Account` object if found.
- **Raises**: `AccountNotFoundError` if no account with the given ID is found.

#### `accountsOfType: aSymbol`
- **Description**: Filters the holder's accounts by their type (e.g., `#checking`, `#savings`).
- **Parameters**:
    - `aSymbol`: The account type (Symbol).
- **Returns**: An `OrderedCollection` of `Account` objects matching the type.

### 3.5 Transfer Methods

#### `transfer: aMoney from: sourceId to: destId description: aString`
- **Description**: Facilitates the transfer of money between two accounts owned by the same `AccountHolder`. It performs a withdrawal from the source account and a deposit into the destination account.
- **Parameters**:
    - `aMoney`: The amount of money to transfer (Money object).
    - `sourceId`: The ID of the source account.
    - `destId`: The ID of the destination account.
    - `aString`: A description for the transfer.
- **Raises**: `InsufficientFundsError` if the source account has insufficient funds, or `AccountNotFoundError` if either account ID is not found.

### 3.6 Reporting Methods

#### `netWorth`
- **Description**: Calculates the sum of balances across all accounts owned by the holder. (Note: This implementation simplifies by summing `amount` from `Money` objects, which might be problematic if accounts have different currencies without conversion).
- **Returns**: A Float representing the total net worth.

#### `summary`
- **Description**: Generates a formatted multi-line string summary of the account holder's details and a brief overview of each owned account (name, type, balance, transaction count).
- **Returns**: A String containing the formatted summary.

### 3.7 Converting Methods

#### `asDictionary`
- **Description**: Converts the `AccountHolder` object into a dictionary representation, suitable for serialization. It includes all instance variables, with `createdAt` and `accounts` converted to their dictionary forms.
- **Returns**: A `Dictionary` representing the account holder.

### 3.8 Printing Methods

#### `printOn: aStream`
- **Description**: Defines how the `AccountHolder` object should be printed to a stream. It outputs "AccountHolder(" followed by the full name, the number of accounts, and ")".
- **Parameters**:
    - `aStream`: The stream to print to.

## 4. Algorithms

- **Holder ID Generation**: Uses `UUID new printString` for unique ID generation.
- **Account Creation**: Delegates to `Account` class methods (`checking:currency:owner:`, `savings:currency:owner:`).
- **Account Finding**: Uses `detect:ifNone:` to find an account by ID.
- **Account Filtering**: Uses `select:` to filter accounts by type.
- **Money Transfer**: Involves finding two accounts, performing a `withdraw:` on the source, and a `deposit:` on the destination.
- **Net Worth Calculation**: Simple summation of account balances.
- **Summary Generation**: Uses a `WriteStream` to build a formatted string by iterating through accounts and calling their respective accessors.

## 5. Interfaces

The `AccountHolder` class interacts with:
- `Account` class: For creating, managing, and querying individual accounts.
- `UUID` class: For generating unique holder IDs.
- `Date` class: For handling creation dates.
- `OrderedCollection` class: For storing and managing accounts.
- `Dictionary` class: For serialization/deserialization.
- `WriteStream` class: For generating formatted summaries.
- Error classes: `AccountNotFoundError`, `InsufficientFundsError` (propagated from `Account` class) for error handling.

## 6. Error Handling

- `AccountNotFoundError`: Signaled when an attempt is made to find an account with an ID that does not exist for the account holder.
- `InsufficientFundsError`: Can be propagated from the `Account` class during a `transfer:` operation if the source account does not have sufficient funds.

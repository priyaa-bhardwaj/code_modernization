import os
from flask import Flask
from flask_cors import CORS
from flask_login import LoginManager

from config import config
from models import db, User


def create_app(config_name=None):
    if config_name is None:
        config_name = os.environ.get("FLASK_ENV", "default")

    app = Flask(__name__)
    app.config.from_object(config[config_name])

    # Extensions
    db.init_app(app)
    CORS(app, supports_credentials=True, origins=["http://localhost:5173"])

    login_manager = LoginManager()
    login_manager.init_app(app)
    login_manager.login_view = "auth.login"

    @login_manager.user_loader
    def load_user(user_id):
        return db.session.get(User, int(user_id))

    @login_manager.unauthorized_handler
    def unauthorized():
        from flask import jsonify
        return jsonify({"error": "Authentication required"}), 401

    # Ensure workspaces directory exists
    os.makedirs(app.config["WORKSPACES_DIR"], exist_ok=True)

    # Register blueprints
    from routes.auth import auth_bp
    from routes.cards import cards_bp
    from routes.pipelines import pipelines_bp
    from routes.jobs import jobs_bp

    app.register_blueprint(auth_bp, url_prefix="/api/auth")
    app.register_blueprint(cards_bp, url_prefix="/api")
    app.register_blueprint(pipelines_bp, url_prefix="/api")
    app.register_blueprint(jobs_bp, url_prefix="/api/jobs")

    with app.app_context():
        db.create_all()

    return app


if __name__ == "__main__":
    app = create_app("development")
    app.run(debug=True, use_reloader=False)

# Task Management System (TMS) — Software Specification Document

**Version:** 1.0  
**Date:** April 7, 2026  
**Status:** Reverse-Engineered from Source  
**Language/Platform:** Smalltalk (Pharo-compatible)

---

## 1. Executive Summary

The Task Management System (TMS) is a priority-based task management application implemented in Smalltalk. It provides task creation, assignment, lifecycle management, deadline tracking, hierarchical subtasks, tagging, search, event-driven notifications, role-based access control, file-based persistence, and reporting. The system follows a layered architecture with clear separation between domain model, service logic, persistence, and event handling.

---

## 2. System Architecture

### 2.1 Architectural Style

The system adopts a **layered architecture** consisting of four primary layers:

**Domain Model Layer** (`TMS-Model` category) contains the core business entities `TMSTask` and `TMSUser`, which encapsulate domain logic such as validation, state transitions, and completion calculations.

**Service Layer** (`TMS-Service` category) contains `TMSTaskService`, which orchestrates business operations, enforces authorization, and coordinates between the repository and notification subsystems.

**Persistence Layer** (`TMS-Persistence` category) contains `TMSTaskRepository`, which manages in-memory storage backed by file-based serialization using STON (Smalltalk Object Notation).

**Event/Notification Layer** (`TMS-Events` and `TMS-Notifications` categories) implements the Observer pattern through `TMSNotificationCenter`, `TMSTaskEvent`, and `TMSEmailNotifier` to decouple domain events from side effects.

### 2.2 Design Patterns

The following design patterns are employed throughout the codebase:

**Observer Pattern** — `TMSNotificationCenter` maintains a subscriber registry keyed by event type. Subscribers register for specific event types and receive `TMSTaskEvent` instances when events fire. This decouples task lifecycle transitions from notification delivery.

**Repository Pattern** — `TMSTaskRepository` abstracts storage behind a query interface, providing methods like `findById:`, `findByStatus:`, `findByAssignee:`, and `findOverdue`. The underlying storage is a `Dictionary` keyed by task ID.

**Singleton Pattern** — `TMSNotificationCenter` uses a class-side `DefaultInstance` variable with lazy initialization to ensure a single global notification hub.

**Service Facade** — `TMSTaskService` acts as the primary API surface, coordinating repository access, authorization checks, and event emission behind a simplified interface.

---

## 3. Domain Model Specification

### 3.1 TMSTask

**Purpose:** Represents a unit of work with priority, lifecycle status, deadline, hierarchical subtasks, and tagging.

**Instance Variables:**

| Variable | Type | Description |
|----------|------|-------------|
| `id` | Integer | Auto-incremented unique identifier (class-side `NextId` counter) |
| `title` | String | Short descriptive name of the task |
| `description` | String | Detailed description of the work |
| `priority` | Symbol | One of `#critical`, `#high`, `#medium`, `#low` |
| `status` | Symbol | One of `#pending`, `#inProgress`, `#completed`, `#cancelled` |
| `category` | Object | Arbitrary category label (no type enforcement) |
| `deadline` | DateAndTime | Optional due date/time |
| `assignee` | TMSUser | Optional assigned user |
| `createdAt` | DateAndTime | Immutable creation timestamp |
| `updatedAt` | DateAndTime | Last modification timestamp (auto-updated on mutation) |
| `subtasks` | OrderedCollection | Child tasks forming a one-level hierarchy |
| `tags` | Set | Lowercase string tags for search and classification |

**State Transition Rules:**

A task begins in `#pending` status upon creation. The following transitions are supported:

- `#pending` → `#inProgress` via `markInProgress`
- `#inProgress` → `#completed` via `markCompleted` (precondition: all subtasks must have `#completed` status)
- Any status → `#cancelled` via `markCancelled`

Note: The current implementation does not enforce a strict state machine — transitions from `#completed` back to other states are not explicitly blocked.

**Validation Rules:**

- Priority must be one of the values returned by `TMSTask class >> validPriorities`. Setting an invalid priority raises a `TMSValidationError`.
- Duplicate subtasks are rejected with a `TMSValidationError`.
- Completing a task with incomplete subtasks raises a `TMSValidationError`.

**Computed Properties:**

- `isOverdue` returns `true` if the deadline has passed and the task is not completed.
- `completionPercentage` returns the percentage of subtasks with `#completed` status. If there are no subtasks, it returns 100 for completed tasks and 0 otherwise.

**Events Emitted:**

- `#statusChanged` when `markInProgress` is called.
- `#completed` when `markCompleted` is called.
- `#cancelled` when `markCancelled` is called.

### 3.2 TMSUser

**Purpose:** Represents a system user with role-based permissions.

**Instance Variables:**

| Variable | Type | Description |
|----------|------|-------------|
| `userId` | String | UUID-based unique identifier |
| `name` | String | Display name |
| `email` | String | Email address (used for notifications) |
| `role` | Symbol | One of `#admin`, `#manager`, or other custom roles |
| `preferences` | Dictionary | User-specific key-value settings |

**Authorization Model:**

- `canManageTasks` returns `true` for `#admin` and `#manager` roles. This gates task creation and cancellation.
- `canAssignTasks` returns `true` only for `#admin`. This gates task assignment operations.

---

## 4. Event System Specification

### 4.1 TMSTaskEvent

A value object representing a domain event, carrying the originating task, an event type symbol, a timestamp, and an extensible metadata dictionary.

**Supported Event Types:** `#created`, `#assigned`, `#statusChanged`, `#completed`, `#cancelled`.

### 4.2 TMSNotificationCenter

A global singleton that implements publish/subscribe messaging. Subscribers register for specific event types via `subscribe:toEvent:` and are invoked by calling `handleEvent:` on each subscriber when a matching event is published.

The notification center also maintains a chronological `eventLog` (an `OrderedCollection` of all published events), queryable via `eventLogSince:` to support audit and reporting use cases.

**Contract for Subscribers:** Any object subscribing to events must implement the `handleEvent:` method accepting a `TMSTaskEvent` argument.

### 4.3 TMSEmailNotifier

A concrete event subscriber that formats task events into email notifications. It registers for all five event types via `registerForAllEvents`. The current implementation writes to the `Transcript` as a placeholder; integration with an SMTP library is noted as pending.

Email notifications are only sent if the task has a non-nil assignee. The email body includes the task title, status, priority, and deadline.

---

## 5. Persistence Specification

### 5.1 TMSTaskRepository

**Storage Model:** In-memory `Dictionary` keyed by integer task ID, backed by STON file serialization.

**Construction:** Instantiated via the factory method `TMSTaskRepository class >> onFile:`, which sets the file path and attempts to load existing data from disk.

**Query Interface:**

| Method | Description |
|--------|-------------|
| `findById:` | Returns task by ID or `nil` |
| `findByStatus:` | Returns all tasks matching a given status symbol |
| `findByAssignee:` | Matches by `userId` comparison on the task's assignee |
| `findByCategory:` | Exact match on category |
| `findByTag:` | Case-insensitive tag membership check |
| `findOverdue` | Delegates to `TMSTask >> isOverdue` |
| `allTasks` | Returns all stored tasks as an `OrderedCollection` |

**Write Operations:** `save:` inserts or updates a task and triggers `persistToDisk`. `delete:` removes a task by ID and persists.

**Persistence Mechanism:** Serialization uses `STON toStringPretty:` for human-readable output. Deserialization uses `STON fromString:`. Load errors are caught and logged to the Transcript without raising exceptions to the caller.

**Limitations and Risks:**

- No transactional guarantees — a crash during write may corrupt the file.
- Full file rewrite on every save, which does not scale to large task volumes.
- No locking or concurrency control for multi-image or multi-process access.

---

## 6. Service Layer Specification

### 6.1 TMSTaskService

**Dependencies:** Requires a `TMSTaskRepository` and a `TMSUser` (the current authenticated user) at construction time.

**Operations:**

**`createTask:description:priority:category:deadline:`** — Verifies the current user has `canManageTasks` permission, creates a new `TMSTask`, persists it, and emits a `#created` event. Raises `TMSAuthorizationError` on unauthorized access.

**`assignTask:to:`** — Verifies `canAssignTasks` permission on the current user, sets the task's assignee, persists, and emits an `#assigned` event.

**`completeTask:`** — Delegates to `TMSTask >> markCompleted`, which enforces the subtask completion precondition, then persists.

**`cancelTask:`** — Verifies `canManageTasks` permission, delegates to `markCancelled`, and persists.

**`dashboard`** — Returns a `Dictionary` with aggregate statistics: `#total`, `#overdue`, `#inProgress`, `#completed`, and `#completionRate` (percentage, rounded).

**`searchTasks:`** — Performs case-insensitive substring matching across `title`, `description`, and `tags`. Returns an `OrderedCollection` of matching tasks.

**`sortedByPriority:`** — Sorts a collection of tasks by priority order: critical → high → medium → low.

**`generateReport`** — Produces a plain-text report string containing total counts by priority and a listing of overdue tasks with their deadlines.

---

## 7. Exception Hierarchy

**`TMSValidationError`** (subclass of `Error`) — Raised for domain rule violations such as invalid priority values, duplicate subtasks, or attempting to complete a task with incomplete subtasks.

**`TMSAuthorizationError`** (subclass of `Error`) — Raised when the current user lacks the required role-based permission for an operation.

---

## 8. Known Limitations and Technical Debt

**Incomplete State Machine Enforcement.** The task status transitions are not enforced by a formal state machine. Reverse transitions (e.g., completed → pending) are possible through direct `status:` setter access, bypassing lifecycle methods and event emission.

**Category Type Not Enforced.** The `category` field accepts any object with no validation, which could lead to inconsistent data if callers use mixed types.

**Single-Level Subtask Hierarchy.** Subtasks cannot themselves have subtasks in a meaningful way — the `completionPercentage` and `markCompleted` logic only inspect one level deep.

**No Indexing.** All queries iterate the full task collection. For large datasets, indexed lookups or a database-backed repository would be necessary.

**File-Based Persistence.** STON file serialization has no transactional safety, no concurrent access control, and performs full rewrites on every mutation.

**Email Notifier Not Implemented.** SMTP integration is stubbed out. The notifier currently writes to the Transcript.

**No Input Sanitization.** Title, description, and tag strings are not sanitized or length-validated.

**No Pagination.** Query methods return full result sets with no support for pagination or result limiting.

---

## 9. Class/Category Summary

| Class | Category | Role |
|-------|----------|------|
| `TMSTask` | TMS-Model | Core task entity with lifecycle and validation |
| `TMSUser` | TMS-Model | User entity with role-based permissions |
| `TMSTaskEvent` | TMS-Events | Domain event value object |
| `TMSNotificationCenter` | TMS-Events | Singleton pub/sub event dispatcher |
| `TMSTaskRepository` | TMS-Persistence | In-memory + file-backed task storage |
| `TMSTaskService` | TMS-Service | Business operation orchestrator |
| `TMSEmailNotifier` | TMS-Notifications | Event subscriber for email delivery |
| `TMSValidationError` | TMS-Exceptions | Domain validation exception |
| `TMSAuthorizationError` | TMS-Exceptions | Authorization failure exception |

---

## 10. Dependency Graph

```
TMSTaskService
  ├── TMSTaskRepository (persistence)
  ├── TMSUser (authorization context)
  ├── TMSTask (domain entity)
  ├── TMSNotificationCenter (event emission)
  └── TMSTaskEvent (event payload)

TMSNotificationCenter
  └── TMSEmailNotifier (subscriber)

TMSTask
  └── TMSTask (subtasks, recursive reference)
```

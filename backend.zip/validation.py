import os
import zipfile
import tarfile

# Maps each translation_id to expected source file extensions
EXTENSION_MAP = {
    "smalltalk-java-springboot": {
        "extensions": {".st", ".cls"},
        "language": "Smalltalk",
    },
    "cobol-python": {
        "extensions": {".cbl", ".cob", ".cpy"},
        "language": "COBOL",
    },
    "powerbuilder-react": {
        "extensions": {".pbl", ".pbt", ".srw", ".srd", ".srf"},
        "language": "PowerBuilder",
    },
    "vb6-csharp-dotnet": {
        "extensions": {".bas", ".cls", ".frm", ".vbp"},
        "language": "VB6",
    },
    "delphi-typescript": {
        "extensions": {".pas", ".dfm", ".dpr", ".dpk"},
        "language": "Delphi",
    },
    "rpg-nodejs": {
        "extensions": {".rpg", ".rpgle", ".sqlrpgle", ".clle"},
        "language": "RPG",
    },
    "fortran-rust": {
        "extensions": {".f", ".f90", ".f95", ".f03", ".for"},
        "language": "Fortran",
    },
    "pli-go": {
        "extensions": {".pl1", ".pli", ".plinc"},
        "language": "PL/I",
    },
}


def validate_upload(upload_path: str, translation_id: str) -> tuple[bool, str | None]:
    """
    Check that the uploaded archive contains at least one file with an
    extension matching the source language of the selected translation path.

    Returns (is_valid, error_message).
    """
    cfg = EXTENSION_MAP.get(translation_id)
    if not cfg:
        return False, f"Unknown translation path: {translation_id}"

    # List files in the archive
    try:
        if zipfile.is_zipfile(upload_path):
            with zipfile.ZipFile(upload_path, "r") as zf:
                file_names = [n for n in zf.namelist() if not n.endswith("/")]
        elif tarfile.is_tarfile(upload_path):
            with tarfile.open(upload_path, "r:*") as tf:
                file_names = [m.name for m in tf.getmembers() if m.isfile()]
        else:
            return False, "Uploaded file is not a valid zip or tar.gz archive"
    except Exception as e:
        return False, f"Failed to read archive: {e}"

    if not file_names:
        return False, "The uploaded archive is empty"

    found_extensions = {os.path.splitext(f)[1].lower() for f in file_names if os.path.splitext(f)[1]}
    matching = found_extensions & cfg["extensions"]

    if not matching:
        expected = ", ".join(sorted(cfg["extensions"]))
        return False, (
            f"No {cfg['language']} source files found in the upload. "
            f"Expected file extensions: {expected}"
        )

    return True, None

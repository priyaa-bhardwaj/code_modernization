"""
Code modernization orchestrator using LangChain's deepagents library.

Uses create_deep_agent with SubAgent and FilesystemMiddleware to run
a 3-step pipeline: Spec/Analysis → Modernization → Reflection.
"""

import os
import threading
import traceback

from database import SessionLocal, Job, Step

# ---------------------------------------------------------------------------
# Deep agent imports (from the deepagents library)
# ---------------------------------------------------------------------------
try:
    from deepagents import create_deep_agent
    from deepagents.types import SubAgent
    from deepagents.middleware import FilesystemMiddleware
    from deepagents.backends import FilesystemBackend

    DEEPAGENT_AVAILABLE = True
except ImportError:
    DEEPAGENT_AVAILABLE = False


# ---------------------------------------------------------------------------
# In-memory state for human-intervention jobs
# ---------------------------------------------------------------------------

_active_jobs: dict[str, dict] = {}


# ---------------------------------------------------------------------------
# Prompt builders
# ---------------------------------------------------------------------------

def _orchestrator_prompt(job: Job) -> str:
    """Build the top-level system prompt for the orchestrator agent."""
    return (
        f"You are a code modernization orchestrator. Your task is to modernize "
        f"legacy {job.translation_id.split('-')[0].title()} code into "
        f"{' '.join(job.translation_id.split('-')[1:]).title()}.\n\n"
        f"The workspace has the following structure:\n"
        f"  /chunks/     — Source code files (parsed and chunked from user upload)\n"
        f"  /context/    — Enterprise context documents uploaded by the user\n"
        f"  /spec/       — Write the specification or analysis document here\n"
        f"  /output/     — Write the modernized code files here\n"
        f"  /validation/ — Write the reflection/validation report here\n\n"
        f"Execute the subagents in order: first analyze/spec, then modernize, then reflect.\n"
        f"Each subagent reads from and writes to the appropriate directories."
    )


def _build_subagents(job: Job) -> list:
    """Build the list of SubAgent objects based on pipeline type."""
    prompts = job.prompts

    if job.pipeline_type == "spec-to-code":
        # Spec-to-code: the spec is already in /spec/ (uploaded by user).
        # Step 0 = data_loader: reads /spec/ and summarizes what was loaded.
        # Step 1 = modernizer: generates code from the spec.
        # Step 2 = reflector: validates the generated code.
        return [
            SubAgent(
                name="data_loader",
                description="Load and summarize the user-provided specification",
                system_prompt=(
                    "You are a specification reviewer. The user has uploaded their spec "
                    "documents directly into /spec/. Read all files in /spec/ and any "
                    "context in /context/. Produce a structured summary confirming what "
                    "was loaded: list every file, its type, and key contents. "
                    "If the spec needs consolidation, write a consolidated version to "
                    "/spec/specification.md. Otherwise, confirm the spec is ready.\n\n"
                    f"User instructions: {prompts.get('spec', '')}\n\n"
                    "Write your summary to /spec/specification.md"
                ),
            ),
            SubAgent(
                name="modernizer",
                description="Generate modernized code from the specification",
                system_prompt=(
                    "You are an expert code modernizer. Read the specification files in "
                    "/spec/ and any context in /context/. Generate "
                    "production-ready modernized code in the target language/framework.\n\n"
                    f"User instructions: {prompts.get('modernize', '')}\n\n"
                    "Write all output files to the /output/ directory with proper folder structure."
                ),
            ),
            SubAgent(
                name="reflector",
                description="Review and validate the modernized code",
                system_prompt=(
                    "You are a code review expert. Read the modernized code in /output/ "
                    "and compare it against the specification in /spec/. "
                    "Identify gaps, issues, and improvements.\n\n"
                    f"User instructions: {prompts.get('reflect', '')}\n\n"
                    "Write a detailed reflection report to /validation/reflection.md"
                ),
            ),
        ]
    else:
        # code-to-code
        return [
            SubAgent(
                name="analyzer",
                description="Perform deep analysis of the source code",
                system_prompt=(
                    "You are an expert code analyst. Read all files in /chunks/ and "
                    "any context in /context/. Analyze the code structure, patterns, "
                    "dependencies, and control flow.\n\n"
                    f"User instructions: {prompts.get('analysis', '')}\n\n"
                    "Write the complete analysis report to /spec/analysis.md"
                ),
            ),
            SubAgent(
                name="modernizer",
                description="Transform analyzed code into the target language",
                system_prompt=(
                    "You are an expert code modernizer. Read the analysis at "
                    "/spec/analysis.md, the original code in /chunks/, and context "
                    "in /context/. Directly transform the code into the target "
                    "language/framework.\n\n"
                    f"User instructions: {prompts.get('modernize', '')}\n\n"
                    "Write all output files to the /output/ directory with proper folder structure."
                ),
            ),
            SubAgent(
                name="reflector",
                description="Review and validate the modernized code",
                system_prompt=(
                    "You are a code review expert. Read the modernized code in /output/ "
                    "and compare it against the original code in /chunks/. "
                    "Identify gaps, issues, and improvements.\n\n"
                    f"User instructions: {prompts.get('reflect', '')}\n\n"
                    "Write a detailed reflection report to /validation/reflection.md"
                ),
            ),
        ]


# ---------------------------------------------------------------------------
# Step output readers
# ---------------------------------------------------------------------------

def _read_step_output(workspace: str, step_index: int, pipeline_type: str):
    """
    Read the output for a given step from the workspace filesystem.
    Step 0: string (spec or analysis markdown)
    Step 1: dict {relative_path: content} (all files in output/)
    Step 2: string (reflection markdown)
    """
    if step_index == 0:
        if pipeline_type == "spec-to-code":
            path = os.path.join(workspace, "spec", "specification.md")
        else:
            path = os.path.join(workspace, "spec", "analysis.md")
        if os.path.exists(path):
            with open(path, "r", encoding="utf-8") as f:
                return f.read()
        return "No output generated for this step."

    elif step_index == 1:
        output_dir = os.path.join(workspace, "output")
        files = {}
        if os.path.isdir(output_dir):
            for root, _, fnames in os.walk(output_dir):
                for fname in fnames:
                    fpath = os.path.join(root, fname)
                    rel = os.path.relpath(fpath, output_dir)
                    with open(fpath, "r", encoding="utf-8", errors="replace") as f:
                        files[rel] = f.read()
        return files if files else {"README.md": "No output files were generated."}

    elif step_index == 2:
        path = os.path.join(workspace, "validation", "reflection.md")
        if os.path.exists(path):
            with open(path, "r", encoding="utf-8") as f:
                return f.read()
        return "No reflection output generated."

    return None


# ---------------------------------------------------------------------------
# DB helpers (run from background threads, so they use their own sessions)
# ---------------------------------------------------------------------------

def _update_step(db, job_id: str, index: int, status: str, output=None, error=None):
    step = db.query(Step).filter(Step.job_id == job_id, Step.index == index).first()
    if step:
        step.status = status
        if output is not None:
            step.output = output
        if error is not None:
            step.error = error
        db.commit()


def _update_job(db, job_id: str, **kwargs):
    job = db.query(Job).filter(Job.id == job_id).first()
    if job:
        for k, v in kwargs.items():
            setattr(job, k, v)
        db.commit()


# ---------------------------------------------------------------------------
# Agent runner
# ---------------------------------------------------------------------------

def _run_with_deepagent(job_id: str, db):
    """Run the job using the actual deepagents library."""
    job = db.query(Job).filter(Job.id == job_id).first()
    if not job:
        return

    workspace = job.workspace_path
    backend = FilesystemBackend(root_dir=workspace, virtual_mode=True)
    subagents = _build_subagents(job)

    agent = create_deep_agent(
        model=job.model,
        system_prompt=_orchestrator_prompt(job),
        subagents=subagents,
        middleware=[FilesystemMiddleware()],
        backend=backend,
    )

    step_count = len(subagents)

    for i in range(step_count):
        _update_step(db, job_id, i, "running")
        _update_job(db, job_id, current_step=i, status="running")

        try:
            # Invoke the agent to run the i-th subagent via the task tool
            subagent_name = subagents[i]["name"] if isinstance(subagents[i], dict) else subagents[i].name
            result = agent.invoke({
                "messages": [
                    {"role": "user", "content": f"Execute the '{subagent_name}' subagent now."}
                ]
            })

            # Read output from workspace filesystem
            output = _read_step_output(workspace, i, job.pipeline_type)
            _update_step(db, job_id, i, "complete", output=output)

        except Exception as e:
            _update_step(db, job_id, i, "error", error=str(e))
            _update_job(db, job_id, status="failed")
            return

        # Human intervention: wait for approval before next step
        if job.execution_mode == "human" and i < step_count - 1:
            _update_job(db, job_id, status="waiting_approval")
            event = threading.Event()
            _active_jobs[job_id] = {"event": event, "reprompt": None}

            event.wait()  # Blocks until approve/reprompt endpoint signals

            # Check for reprompt
            entry = _active_jobs.get(job_id)
            if entry and entry.get("reprompt"):
                reprompt_info = entry["reprompt"]
                entry["reprompt"] = None
                # Re-run the same step (i doesn't advance)
                # For simplicity, we just let the loop continue
                # The reprompt is handled by the endpoint resetting the step status

    _update_job(db, job_id, status="completed")
    _active_jobs.pop(job_id, None)


def _run_mock(job_id: str, db):
    """
    Fallback mock runner when deepagents is not installed.
    Writes placeholder outputs to the workspace so the frontend can display them.
    """
    import time

    job = db.query(Job).filter(Job.id == job_id).first()
    if not job:
        return

    workspace = job.workspace_path
    step_count = 3

    # Mock step 0 output
    def _build_spec_loading_summary(spec_dir):
        """Read files already in workspace/spec/ and produce a loading summary."""
        lines = ["# Data Loading Summary\n"]
        lines.append("## Spec files loaded into workspace\n")
        if os.path.isdir(spec_dir):
            for root, _, fnames in os.walk(spec_dir):
                for fname in sorted(fnames):
                    fpath = os.path.join(root, fname)
                    rel = os.path.relpath(fpath, spec_dir)
                    size = os.path.getsize(fpath)
                    lines.append(f"- `{rel}` ({size:,} bytes)")
        if len(lines) <= 2:
            lines.append("- No spec files found.")
        lines.append("\n## Status\nSpec documents loaded and ready for modernization.")
        return "\n".join(lines)

    spec_content = _build_spec_loading_summary(os.path.join(workspace, "spec"))
    analysis_content = (
        "# Code Analysis Report\n\n"
        "## Architecture\n"
        "- Monolithic with procedural modules\n"
        "- Direct database calls via embedded SQL\n\n"
        "## Component Inventory\n"
        "| Component | Type | Complexity |\n"
        "|-----------|------|------------|\n"
        "| AuthModule | Authentication | Medium |\n"
        "| OrderProcessor | Business Logic | High |\n\n"
        "## Migration Considerations\n"
        "- Global state must be refactored into scoped services\n"
        "- Return-code error handling → exception-based patterns\n"
    )

    for i in range(step_count):
        _update_step(db, job_id, i, "running")
        _update_job(db, job_id, current_step=i, status="running")

        time.sleep(3)  # Simulate processing time

        if i == 0:
            # Step 0: For spec-to-code, spec is already in workspace (user uploaded).
            # Just write the loading summary. For code-to-code, write mock analysis.
            if job.pipeline_type == "spec-to-code":
                fpath = os.path.join(workspace, "spec", "specification.md")
                with open(fpath, "w") as f:
                    f.write(spec_content)
            else:
                fpath = os.path.join(workspace, "spec", "analysis.md")
                with open(fpath, "w") as f:
                    f.write(analysis_content)

        elif i == 1:
            # Write mock modernized files to workspace/output/
            output_dir = os.path.join(workspace, "output")
            mock_files = {
                "src/main/java/com/codeplus/Application.java": (
                    "package com.codeplus;\n\n"
                    "import org.springframework.boot.SpringApplication;\n"
                    "import org.springframework.boot.autoconfigure.SpringBootApplication;\n\n"
                    "@SpringBootApplication\n"
                    "public class Application {\n"
                    "    public static void main(String[] args) {\n"
                    "        SpringApplication.run(Application.class, args);\n"
                    "    }\n"
                    "}\n"
                ),
                "src/main/java/com/codeplus/controller/OrderController.java": (
                    "package com.codeplus.controller;\n\n"
                    "import org.springframework.web.bind.annotation.*;\n\n"
                    "@RestController\n"
                    "@RequestMapping(\"/api/orders\")\n"
                    "public class OrderController {\n\n"
                    "    @GetMapping\n"
                    "    public List<Order> getOrders() {\n"
                    "        return orderService.findAll();\n"
                    "    }\n"
                    "}\n"
                ),
                "src/main/resources/application.yml": (
                    "server:\n  port: 8080\n\n"
                    "spring:\n  application:\n    name: codeplus-modernized\n"
                ),
                "pom.xml": (
                    "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
                    "<project>\n"
                    "    <groupId>com.codeplus</groupId>\n"
                    "    <artifactId>modernized</artifactId>\n"
                    "    <version>1.0.0</version>\n"
                    "</project>\n"
                ),
            }
            for rel_path, content in mock_files.items():
                full_path = os.path.join(output_dir, rel_path)
                os.makedirs(os.path.dirname(full_path), exist_ok=True)
                with open(full_path, "w") as f:
                    f.write(content)

        elif i == 2:
            # Write reflection to workspace/validation/
            reflection = (
                "# Reflection Report\n\n"
                "## Coverage Analysis\n"
                "✅ All API endpoints implemented\n"
                "✅ Data models translated correctly\n\n"
                "## Code Quality\n"
                "- Clean layered architecture\n"
                "- Input validation via annotations\n\n"
                "## Recommendations\n"
                "1. Add integration tests\n"
                "2. Configure Spring Security\n"
                "3. Add API documentation\n\n"
                "## Confidence Score: 92%\n"
            )
            fpath = os.path.join(workspace, "validation", "reflection.md")
            with open(fpath, "w") as f:
                f.write(reflection)

        # Read output from workspace
        output = _read_step_output(workspace, i, job.pipeline_type)
        _update_step(db, job_id, i, "complete", output=output)

        # Human mode: wait for approval
        if job.execution_mode == "human" and i < step_count - 1:
            _update_job(db, job_id, status="waiting_approval")
            event = threading.Event()
            _active_jobs[job_id] = {"event": event, "reprompt": None}

            event.wait()

            # Check for reprompt
            entry = _active_jobs.get(job_id)
            if entry and entry.get("reprompt"):
                entry["reprompt"] = None
                # In mock mode, just continue (the step was already reset by endpoint)

    _update_job(db, job_id, status="completed")
    _active_jobs.pop(job_id, None)


# ---------------------------------------------------------------------------
# Public entry point
# ---------------------------------------------------------------------------

def run_job(job_id: str):
    """
    Main entry point. Called from a background thread by app.py.
    Creates its own DB session since it runs outside the request context.
    """
    db = SessionLocal()
    try:
        if DEEPAGENT_AVAILABLE:
            _run_with_deepagent(job_id, db)
        else:
            _run_mock(job_id, db)
    except Exception:
        traceback.print_exc()
        _update_job(db, job_id, status="failed")
    finally:
        db.close()

import os

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

# JWT
JWT_SECRET = os.environ.get("JWT_SECRET", "codeplus-dev-secret-change-in-prod")
JWT_ALGORITHM = "HS256"
JWT_EXPIRY_HOURS = 24

# Database
DATA_DIR = os.path.join(BASE_DIR, "data")
DATABASE_URL = f"sqlite:///{os.path.join(DATA_DIR, 'codeplus.db')}"

# Uploads
UPLOADS_DIR = os.path.join(BASE_DIR, "uploads")
CONTEXT_DIR = os.path.join(UPLOADS_DIR, "context")

# Workspaces
WORKSPACES_DIR = os.path.join(BASE_DIR, "workspaces")

# Workspace subdirs created per job
WORKSPACE_SUBDIRS = ["chunks", "context", "output", "validation", "spec"]

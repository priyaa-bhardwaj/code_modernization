import json
from datetime import datetime
from uuid import uuid4

from sqlalchemy import (
    Column, DateTime, ForeignKey, Integer, String, Text,
    create_engine,
)
from sqlalchemy.orm import declarative_base, relationship, sessionmaker

from config import DATABASE_URL

engine = create_engine(DATABASE_URL, connect_args={"check_same_thread": False})
SessionLocal = sessionmaker(bind=engine)
Base = declarative_base()


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def new_id():
    return str(uuid4())


def now():
    return datetime.utcnow()


# ---------------------------------------------------------------------------
# Models
# ---------------------------------------------------------------------------

class User(Base):
    __tablename__ = "users"

    id = Column(String(36), primary_key=True, default=new_id)
    name = Column(String(255), nullable=False)
    email = Column(String(255), unique=True, nullable=False, index=True)
    password_hash = Column(String(255), nullable=False)
    created_at = Column(DateTime, default=now)

    jobs = relationship("Job", back_populates="user", cascade="all, delete-orphan")


class Job(Base):
    __tablename__ = "jobs"

    id = Column(String(36), primary_key=True, default=new_id)
    user_id = Column(String(36), ForeignKey("users.id"), nullable=False, index=True)
    file_id = Column(String(36), nullable=False)
    translation_id = Column(String(100), nullable=False)
    model = Column(String(50), nullable=False)
    pipeline_type = Column(String(20), nullable=False)
    execution_mode = Column(String(20), nullable=False)
    prompts_json = Column(Text, nullable=False)  # JSON string
    context_ids_json = Column(Text, nullable=True)  # JSON string
    status = Column(String(20), default="pending")
    current_step = Column(Integer, default=0)
    workspace_path = Column(String(500), nullable=False)
    created_at = Column(DateTime, default=now)
    updated_at = Column(DateTime, default=now, onupdate=now)

    user = relationship("User", back_populates="jobs")
    steps = relationship("Step", back_populates="job", cascade="all, delete-orphan", order_by="Step.index")

    @property
    def prompts(self):
        return json.loads(self.prompts_json) if self.prompts_json else {}

    @prompts.setter
    def prompts(self, value):
        self.prompts_json = json.dumps(value)

    @property
    def context_ids(self):
        return json.loads(self.context_ids_json) if self.context_ids_json else []

    @context_ids.setter
    def context_ids(self, value):
        self.context_ids_json = json.dumps(value)


class Step(Base):
    __tablename__ = "steps"

    id = Column(String(36), primary_key=True, default=new_id)
    job_id = Column(String(36), ForeignKey("jobs.id"), nullable=False, index=True)
    index = Column(Integer, nullable=False)
    name = Column(String(100), nullable=False)
    status = Column(String(20), default="pending")
    output_json = Column(Text, nullable=True)  # JSON string (str or dict)
    error = Column(Text, nullable=True)

    job = relationship("Job", back_populates="steps")

    @property
    def output(self):
        if self.output_json is None:
            return None
        return json.loads(self.output_json)

    @output.setter
    def output(self, value):
        self.output_json = json.dumps(value) if value is not None else None


def init_db():
    """Create all tables."""
    Base.metadata.create_all(bind=engine)


def get_db():
    """Yield a database session."""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

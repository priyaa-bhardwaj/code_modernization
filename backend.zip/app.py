import os
import json
import shutil
import zipfile
import threading
from datetime import datetime, timedelta, timezone
from functools import wraps
from io import BytesIO
from uuid import uuid4

import bcrypt
import jwt
from flask import Flask, g, jsonify, request, send_file
from flask_cors import CORS

import config
from database import SessionLocal, User, Job, Step, init_db

app = Flask(__name__)
CORS(
    app,
    origins=["http://localhost:5173", "http://localhost:3000"],
    supports_credentials=True,
    expose_headers=["Content-Disposition"],
)


# ---------------------------------------------------------------------------
# Startup
# ---------------------------------------------------------------------------

def ensure_dirs():
    for d in [config.DATA_DIR, config.UPLOADS_DIR, config.CONTEXT_DIR, config.WORKSPACES_DIR]:
        os.makedirs(d, exist_ok=True)


ensure_dirs()
init_db()


# ---------------------------------------------------------------------------
# Auth helpers
# ---------------------------------------------------------------------------

def hash_password(password: str) -> str:
    return bcrypt.hashpw(password.encode(), bcrypt.gensalt()).decode()


def check_password(password: str, hashed: str) -> bool:
    return bcrypt.checkpw(password.encode(), hashed.encode())


def create_token(user_id: str) -> str:
    payload = {
        "sub": user_id,
        "exp": datetime.now(timezone.utc) + timedelta(hours=config.JWT_EXPIRY_HOURS),
    }
    return jwt.encode(payload, config.JWT_SECRET, algorithm=config.JWT_ALGORITHM)


def decode_token(token: str) -> dict | None:
    try:
        return jwt.decode(token, config.JWT_SECRET, algorithms=[config.JWT_ALGORITHM])
    except (jwt.ExpiredSignatureError, jwt.InvalidTokenError):
        return None


def login_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        auth = request.headers.get("Authorization", "")
        if not auth.startswith("Bearer "):
            return jsonify(message="Missing token"), 401
        payload = decode_token(auth[7:])
        if not payload:
            return jsonify(message="Invalid or expired token"), 401
        db = SessionLocal()
        user = db.query(User).filter(User.id == payload["sub"]).first()
        if not user:
            db.close()
            return jsonify(message="User not found"), 401
        g.user = user
        g.db = db
        try:
            return f(*args, **kwargs)
        finally:
            db.close()
    return decorated


# ---------------------------------------------------------------------------
# Health check
# ---------------------------------------------------------------------------

@app.route("/", methods=["GET"])
@app.route("/api", methods=["GET"])
def health():
    return jsonify(status="ok", service="CODEPLUS API", version="1.0.0")


# ---------------------------------------------------------------------------
# Auth routes
# ---------------------------------------------------------------------------

@app.route("/api/auth/signup", methods=["POST"])
def signup():
    data = request.get_json(silent=True) or {}
    name = data.get("name", "").strip()
    email = data.get("email", "").strip().lower()
    password = data.get("password", "")

    if not name or not email or not password:
        return jsonify(message="All fields are required"), 400

    db = SessionLocal()
    try:
        if db.query(User).filter(User.email == email).first():
            return jsonify(message="Email already registered"), 409
        user = User(name=name, email=email, password_hash=hash_password(password))
        db.add(user)
        db.commit()
        db.refresh(user)
        token = create_token(user.id)
        return jsonify(token=token, user=dict(name=user.name, email=user.email))
    finally:
        db.close()


@app.route("/api/auth/login", methods=["POST"])
def login():
    data = request.get_json(silent=True) or {}
    email = data.get("email", "").strip().lower()
    password = data.get("password", "")

    if not email or not password:
        return jsonify(message="Email and password are required"), 400

    db = SessionLocal()
    try:
        user = db.query(User).filter(User.email == email).first()
        if not user or not check_password(password, user.password_hash):
            return jsonify(message="Invalid email or password"), 401
        token = create_token(user.id)
        return jsonify(token=token, user=dict(name=user.name, email=user.email))
    finally:
        db.close()


# ---------------------------------------------------------------------------
# Upload routes
# ---------------------------------------------------------------------------

@app.route("/api/translate/upload", methods=["POST"])
@login_required
def upload_zip():
    file = request.files.get("file")
    if not file:
        return jsonify(message="No file uploaded"), 400

    file_id = f"file-{uuid4().hex[:12]}"
    ext = os.path.splitext(file.filename)[1].lower()
    save_path = os.path.join(config.UPLOADS_DIR, f"{file_id}{ext}")
    file.save(save_path)
    return jsonify(fileId=file_id)


@app.route("/api/translate/context", methods=["POST"])
@login_required
def upload_context():
    files = request.files.getlist("context")
    if not files:
        return jsonify(message="No context files uploaded"), 400

    context_ids = []
    for f in files:
        ctx_id = f"ctx-{uuid4().hex[:12]}"
        ext = os.path.splitext(f.filename)[1].lower()
        save_path = os.path.join(config.CONTEXT_DIR, f"{ctx_id}{ext}")
        f.save(save_path)
        context_ids.append(ctx_id)

    return jsonify(contextIds=context_ids)


# ---------------------------------------------------------------------------
# Generate route
# ---------------------------------------------------------------------------

PIPELINE_STEPS = {
    "spec-to-code": ["Data Loading", "Modernization", "Reflection"],
    "code-to-code": ["Analysis", "Modernization", "Reflection"],
}


def _find_upload(file_id: str) -> str | None:
    """Find the uploaded file by file_id prefix."""
    for fname in os.listdir(config.UPLOADS_DIR):
        if fname.startswith(file_id):
            return os.path.join(config.UPLOADS_DIR, fname)
    return None


def _create_workspace(job_id: str) -> str:
    workspace = os.path.join(config.WORKSPACES_DIR, job_id)
    for subdir in config.WORKSPACE_SUBDIRS:
        os.makedirs(os.path.join(workspace, subdir), exist_ok=True)
    return workspace


def _extract_and_parse(upload_path: str, workspace: str, translation_id: str):
    """Extract zip and run parser to populate chunks/."""
    from parsers.registry import get_parser

    extract_dir = os.path.join(workspace, "_extracted")
    os.makedirs(extract_dir, exist_ok=True)

    if zipfile.is_zipfile(upload_path):
        with zipfile.ZipFile(upload_path, "r") as zf:
            zf.extractall(extract_dir)
    else:
        # tar.gz fallback
        import tarfile
        with tarfile.open(upload_path, "r:gz") as tf:
            tf.extractall(extract_dir)

    parser = get_parser(translation_id)
    chunks = parser.parse_directory(extract_dir)

    chunks_dir = os.path.join(workspace, "chunks")
    for chunk in chunks:
        safe_name = chunk.file_path.replace("/", "__").replace("\\", "__")
        chunk_fname = f"chunk_{chunk.chunk_index:03d}_{safe_name}"
        with open(os.path.join(chunks_dir, chunk_fname), "w", encoding="utf-8") as f:
            f.write(chunk.content)

    shutil.rmtree(extract_dir, ignore_errors=True)


def _extract_spec_to_workspace(upload_path: str, workspace: str):
    """For spec-to-code: extract the uploaded spec directly into workspace/spec/."""
    spec_dir = os.path.join(workspace, "spec")

    if zipfile.is_zipfile(upload_path):
        with zipfile.ZipFile(upload_path, "r") as zf:
            zf.extractall(spec_dir)
    else:
        import tarfile
        if tarfile.is_tarfile(upload_path):
            with tarfile.open(upload_path, "r:*") as tf:
                tf.extractall(spec_dir)
        else:
            # Single file — just copy it
            shutil.copy2(upload_path, os.path.join(spec_dir, os.path.basename(upload_path)))


def _copy_context(context_ids: list, workspace: str):
    """Copy context files into workspace/context/."""
    dest = os.path.join(workspace, "context")
    for ctx_id in (context_ids or []):
        for fname in os.listdir(config.CONTEXT_DIR):
            if fname.startswith(ctx_id):
                src = os.path.join(config.CONTEXT_DIR, fname)
                shutil.copy2(src, os.path.join(dest, fname))
                break


@app.route("/api/translate/generate", methods=["POST"])
@login_required
def generate():
    data = request.get_json(silent=True) or {}
    file_id = data.get("fileId")
    translation_id = data.get("translationId")
    model = data.get("model", "claude-sonnet-4")
    prompts = data.get("prompts", {})
    pipeline_type = data.get("pipelineType", "spec-to-code")
    execution_mode = data.get("executionMode", "human")
    context_ids = data.get("contextIds", [])

    if not file_id or not translation_id:
        return jsonify(message="fileId and translationId are required"), 400

    # Check upload exists
    upload_path = _find_upload(file_id)
    if not upload_path:
        return jsonify(message="Uploaded file not found"), 404

    # Create job
    db = g.db
    job_id = f"job-{uuid4().hex[:12]}"
    workspace = _create_workspace(job_id)

    if pipeline_type == "spec-to-code":
        # Spec-to-code: uploaded file IS the spec — extract directly to workspace/spec/
        _extract_spec_to_workspace(upload_path, workspace)
    else:
        # Code-to-code: validate extensions and parse into chunks
        from validation import validate_upload
        is_valid, error_msg = validate_upload(upload_path, translation_id)
        if not is_valid:
            return jsonify(message=error_msg), 400
        _extract_and_parse(upload_path, workspace, translation_id)

    _copy_context(context_ids, workspace)

    # DB records
    step_names = PIPELINE_STEPS.get(pipeline_type, PIPELINE_STEPS["spec-to-code"])

    job = Job(
        id=job_id,
        user_id=g.user.id,
        file_id=file_id,
        translation_id=translation_id,
        model=model,
        pipeline_type=pipeline_type,
        execution_mode=execution_mode,
        workspace_path=workspace,
    )
    job.prompts = prompts
    job.context_ids = context_ids
    db.add(job)

    for i, name in enumerate(step_names):
        db.add(Step(job_id=job_id, index=i, name=name))

    db.commit()

    # Launch agent in background thread
    from code_conversion import run_job
    thread = threading.Thread(target=run_job, args=(job_id,), daemon=True)
    thread.start()

    return jsonify(jobId=job_id)


# ---------------------------------------------------------------------------
# Job status (polling endpoint)
# ---------------------------------------------------------------------------

@app.route("/api/translate/job/<job_id>", methods=["GET"])
@login_required
def get_job_status(job_id):
    db = g.db
    job = db.query(Job).filter(Job.id == job_id, Job.user_id == g.user.id).first()
    if not job:
        return jsonify(message="Job not found"), 404

    steps = db.query(Step).filter(Step.job_id == job_id).order_by(Step.index).all()

    return jsonify(
        jobId=job.id,
        status=job.status,
        currentStep=job.current_step,
        steps=[
            dict(name=s.name, status=s.status, output=s.output, error=s.error)
            for s in steps
        ],
    )


# ---------------------------------------------------------------------------
# Approve / Reprompt
# ---------------------------------------------------------------------------

# In-memory registry for human-intervention jobs
_active_jobs: dict[str, dict] = {}


@app.route("/api/translate/job/<job_id>/approve/<int:step_index>", methods=["POST"])
@login_required
def approve_step(job_id, step_index):
    db = g.db
    job = db.query(Job).filter(Job.id == job_id, Job.user_id == g.user.id).first()
    if not job:
        return jsonify(message="Job not found"), 404

    entry = _active_jobs.get(job_id)
    if entry and entry.get("event"):
        entry["event"].set()

    return jsonify(success=True)


@app.route("/api/translate/job/<job_id>/reprompt/<int:step_index>", methods=["POST"])
@login_required
def reprompt_step(job_id, step_index):
    data = request.get_json(silent=True) or {}
    new_prompt = data.get("prompt", "")

    db = g.db
    job = db.query(Job).filter(Job.id == job_id, Job.user_id == g.user.id).first()
    if not job:
        return jsonify(message="Job not found"), 404

    # Reset step
    step = db.query(Step).filter(Step.job_id == job_id, Step.index == step_index).first()
    if step:
        step.status = "running"
        step.output_json = None
        step.error = None
        db.commit()

    # Signal reprompt to the background runner
    entry = _active_jobs.get(job_id)
    if entry:
        entry["reprompt"] = {"step_index": step_index, "prompt": new_prompt}
        if entry.get("event"):
            entry["event"].set()

    return jsonify(success=True)


# ---------------------------------------------------------------------------
# Download
# ---------------------------------------------------------------------------

@app.route("/api/translate/job/<job_id>/download", methods=["GET"])
@login_required
def download_result(job_id):
    db = g.db
    job = db.query(Job).filter(Job.id == job_id, Job.user_id == g.user.id).first()
    if not job:
        return jsonify(message="Job not found"), 404

    output_dir = os.path.join(job.workspace_path, "output")
    if not os.path.isdir(output_dir):
        return jsonify(message="No output files found"), 404

    buf = BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
        for root, _dirs, files in os.walk(output_dir):
            for fname in files:
                fpath = os.path.join(root, fname)
                arcname = os.path.relpath(fpath, output_dir)
                zf.write(fpath, arcname)
    buf.seek(0)

    return send_file(
        buf,
        mimetype="application/zip",
        as_attachment=True,
        download_name=f"codeplus-modernized-{job_id}.zip",
    )


# ---------------------------------------------------------------------------
# Error handler
# ---------------------------------------------------------------------------

@app.errorhandler(Exception)
def handle_error(e):
    if hasattr(e, "code") and hasattr(e, "description"):
        return jsonify(message=str(e.description)), e.code
    return jsonify(message=str(e)), 500


# ---------------------------------------------------------------------------
# Run
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)

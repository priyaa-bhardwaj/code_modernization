from parsers.java_parser import JavaParser
from parsers.smalltalk_parser import SmalltalkParser
from parsers.cobol_parser import CobolParser
from parsers.powerbuilder_parser import PowerBuilderParser
from parsers.vb6_parser import VB6Parser
from parsers.delphi_parser import DelphiParser
from parsers.rpg_parser import RPGParser
from parsers.fortran_parser import FortranParser
from parsers.pli_parser import PLIParser
from parsers.base import BaseParser

PARSER_REGISTRY: dict[str, BaseParser] = {
    "smalltalk": SmalltalkParser(),
    "cobol": CobolParser(),
    "powerbuilder": PowerBuilderParser(),
    "vb6": VB6Parser(),
    "delphi": DelphiParser(),
    "rpg": RPGParser(),
    "fortran": FortranParser(),
    "pli": PLIParser(),
    "java": JavaParser(),
}


def get_parser(translation_id: str) -> BaseParser:
    """Extract source language from translation_id and return the parser."""
    source_lang = translation_id.split("-")[0]
    parser = PARSER_REGISTRY.get(source_lang)
    if not parser:
        raise ValueError(f"No parser registered for language: {source_lang}")
    return parser

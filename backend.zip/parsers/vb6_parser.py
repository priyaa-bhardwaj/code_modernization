from parsers.base import BaseParser, CodeChunk


class VB6Parser(BaseParser):
    @property
    def language_name(self) -> str:
        return "VB6"

    @property
    def file_extensions(self) -> set[str]:
        return {".bas", ".cls", ".frm", ".vbp"}

    def parse_file(self, file_path: str, content: str) -> list[CodeChunk]:
        return [
            CodeChunk(
                file_path=file_path,
                chunk_index=0,
                content=content,
                chunk_type="file",
                metadata={"parser": "vb6_stub"},
            )
        ]

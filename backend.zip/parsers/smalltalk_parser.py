from parsers.base import BaseParser, CodeChunk


class SmalltalkParser(BaseParser):
    @property
    def language_name(self) -> str:
        return "Smalltalk"

    @property
    def file_extensions(self) -> set[str]:
        return {".st", ".cls"}

    def parse_file(self, file_path: str, content: str) -> list[CodeChunk]:
        return [
            CodeChunk(
                file_path=file_path,
                chunk_index=0,
                content=content,
                chunk_type="file",
                metadata={"parser": "smalltalk_stub"},
            )
        ]

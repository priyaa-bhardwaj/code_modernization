from parsers.base import BaseParser, CodeChunk


class PLIParser(BaseParser):
    @property
    def language_name(self) -> str:
        return "PL/I"

    @property
    def file_extensions(self) -> set[str]:
        return {".pl1", ".pli", ".plinc"}

    def parse_file(self, file_path: str, content: str) -> list[CodeChunk]:
        return [
            CodeChunk(
                file_path=file_path,
                chunk_index=0,
                content=content,
                chunk_type="file",
                metadata={"parser": "pli_stub"},
            )
        ]

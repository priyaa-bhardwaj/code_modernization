import os
from abc import ABC, abstractmethod
from dataclasses import dataclass, field


@dataclass
class CodeChunk:
    file_path: str          # Relative path within the source archive
    chunk_index: int        # Index within the file (0 for whole-file stubs)
    content: str            # The chunk content
    chunk_type: str         # "file" (stub), future: "class", "method", etc.
    metadata: dict = field(default_factory=dict)


class BaseParser(ABC):
    """Abstract base class for language-specific parsers."""

    @property
    @abstractmethod
    def language_name(self) -> str:
        ...

    @property
    @abstractmethod
    def file_extensions(self) -> set[str]:
        ...

    @abstractmethod
    def parse_file(self, file_path: str, content: str) -> list[CodeChunk]:
        ...

    def parse_directory(self, source_dir: str) -> list[CodeChunk]:
        """Walk the directory and parse all files with matching extensions."""
        chunks: list[CodeChunk] = []
        for root, _, files in os.walk(source_dir):
            for fname in sorted(files):
                ext = os.path.splitext(fname)[1].lower()
                if ext in self.file_extensions:
                    fpath = os.path.join(root, fname)
                    rel = os.path.relpath(fpath, source_dir)
                    with open(fpath, "r", errors="replace") as f:
                        content = f.read()
                    chunks.extend(self.parse_file(rel, content))
        return chunks

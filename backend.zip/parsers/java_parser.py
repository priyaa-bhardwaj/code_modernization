from parsers.base import BaseParser, CodeChunk


class JavaParser(BaseParser):
    @property
    def language_name(self) -> str:
        return "Java"

    @property
    def file_extensions(self) -> set[str]:
        return {".java", ".xml", ".properties", ".yml", ".yaml"}

    def parse_file(self, file_path: str, content: str) -> list[CodeChunk]:
        """Stub: returns the entire file as a single chunk."""
        return [
            CodeChunk(
                file_path=file_path,
                chunk_index=0,
                content=content,
                chunk_type="file",
                metadata={"parser": "java_stub", "lines": content.count("\n") + 1},
            )
        ]

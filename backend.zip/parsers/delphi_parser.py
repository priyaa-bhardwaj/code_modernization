from parsers.base import BaseParser, CodeChunk


class DelphiParser(BaseParser):
    @property
    def language_name(self) -> str:
        return "Delphi"

    @property
    def file_extensions(self) -> set[str]:
        return {".pas", ".dfm", ".dpr", ".dpk"}

    def parse_file(self, file_path: str, content: str) -> list[CodeChunk]:
        return [
            CodeChunk(
                file_path=file_path,
                chunk_index=0,
                content=content,
                chunk_type="file",
                metadata={"parser": "delphi_stub"},
            )
        ]

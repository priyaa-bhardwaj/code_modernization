from parsers.base import BaseParser, CodeChunk


class FortranParser(BaseParser):
    @property
    def language_name(self) -> str:
        return "Fortran"

    @property
    def file_extensions(self) -> set[str]:
        return {".f", ".f90", ".f95", ".f03", ".for"}

    def parse_file(self, file_path: str, content: str) -> list[CodeChunk]:
        return [
            CodeChunk(
                file_path=file_path,
                chunk_index=0,
                content=content,
                chunk_type="file",
                metadata={"parser": "fortran_stub"},
            )
        ]

from parsers.base import BaseParser, CodeChunk


class PowerBuilderParser(BaseParser):
    @property
    def language_name(self) -> str:
        return "PowerBuilder"

    @property
    def file_extensions(self) -> set[str]:
        return {".pbl", ".pbt", ".srw", ".srd", ".srf"}

    def parse_file(self, file_path: str, content: str) -> list[CodeChunk]:
        return [
            CodeChunk(
                file_path=file_path,
                chunk_index=0,
                content=content,
                chunk_type="file",
                metadata={"parser": "powerbuilder_stub"},
            )
        ]

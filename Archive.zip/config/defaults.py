"""
All default configuration data — single source of truth.
The frontend fetches these via /api/config/* endpoints.
"""

DASHBOARD_CARDS = [
    {
        "id": "smalltalk-java-springboot",
        "from": "Smalltalk",
        "to": "Java Spring Boot",
        "fromColor": "#3468af",
        "toColor": "#6db33f",
        "description": "Migrate Smalltalk applications to modern Java Spring Boot microservices",
    },
    {
        "id": "cobol-python",
        "from": "COBOL",
        "to": "Python",
        "fromColor": "#005ca5",
        "toColor": "#3776ab",
        "description": "Transform COBOL mainframe programs into clean Python applications",
    },
    {
        "id": "powerbuilder-react",
        "from": "PowerBuilder",
        "to": "React",
        "fromColor": "#c62828",
        "toColor": "#61dafb",
        "description": "Convert PowerBuilder desktop apps to modern React web applications",
    },
    {
        "id": "vb6-csharp-dotnet",
        "from": "VB6",
        "to": "C# .NET",
        "fromColor": "#00539c",
        "toColor": "#512bd4",
        "description": "Upgrade Visual Basic 6 projects to C# .NET modern architecture",
    },
    {
        "id": "delphi-typescript",
        "from": "Delphi",
        "to": "TypeScript",
        "fromColor": "#ee1f35",
        "toColor": "#3178c6",
        "description": "Modernize Delphi applications to TypeScript-based solutions",
    },
    {
        "id": "rpg-nodejs",
        "from": "RPG",
        "to": "Node.js",
        "fromColor": "#f5a623",
        "toColor": "#339933",
        "description": "Translate IBM RPG programs to scalable Node.js services",
    },
    {
        "id": "fortran-rust",
        "from": "Fortran",
        "to": "Rust",
        "fromColor": "#734f96",
        "toColor": "#ce422b",
        "description": "Convert high-performance Fortran code to safe, fast Rust",
    },
    {
        "id": "pli-go",
        "from": "PL/I",
        "to": "Go",
        "fromColor": "#ff6b35",
        "toColor": "#00add8",
        "description": "Migrate PL/I enterprise systems to efficient Go microservices",
    },
]

MODELS = [
    {"id": "claude-opus-4", "name": "Claude Opus 4", "provider": "Anthropic"},
    {"id": "claude-sonnet-4", "name": "Claude Sonnet 4", "provider": "Anthropic"},
    {"id": "gpt-4o", "name": "GPT-4o", "provider": "OpenAI"},
    {"id": "gemini-pro", "name": "Gemini Pro", "provider": "Google"},
]

PIPELINES = {
    "spec-to-code": {
        "id": "spec-to-code",
        "label": "Spec-to-Code",
        "description": "Upload your spec directly — modernize from spec",
        "steps": ["Data Loading", "Modernization", "Reflection"],
        "stepDescriptions": [
            "Loading uploaded specification into workspace...",
            "Transforming specification into modernized code...",
            "Reviewing and validating the generated code...",
        ],
        "promptKeys": ["spec", "modernize", "reflect"],
        "promptLabels": ["Data Loading", "Modernization", "Reflection"],
        "defaultPrompts": {
            "spec": (
                "Review the uploaded specification documents and confirm all "
                "business logic, data structures, workflows, and integrations "
                "are captured."
            ),
            "modernize": (
                "Using the specification document, generate modernized code "
                "in the target language following best practices, design "
                "patterns, and production-ready standards."
            ),
            "reflect": (
                "Review the generated modern code against the original "
                "specification. Identify any gaps, inconsistencies, or "
                "improvements needed. Suggest corrections."
            ),
        },
    },
    "code-to-code": {
        "id": "code-to-code",
        "label": "Code-to-Code",
        "description": "Analyze source code directly, then modernize",
        "steps": ["Analysis", "Modernization", "Reflection"],
        "stepDescriptions": [
            "Performing deep analysis of source code structure and patterns...",
            "Directly transforming analyzed code into modernized target language...",
            "Reviewing and validating the generated code...",
        ],
        "promptKeys": ["analysis", "modernize", "reflect"],
        "promptLabels": ["Analysis", "Modernization", "Reflection"],
        "defaultPrompts": {
            "analysis": (
                "Analyze the provided source code to understand its structure, "
                "patterns, dependencies, and control flow. Identify key "
                "components and their relationships."
            ),
            "modernize": (
                "Using the analysis, directly transform the source code into "
                "the target language following best practices, design patterns, "
                "and production-ready standards."
            ),
            "reflect": (
                "Review the generated modern code against the original source. "
                "Identify any gaps, inconsistencies, or improvements needed. "
                "Suggest corrections."
            ),
        },
    },
}


def get_default_prompts(pipeline_type: str) -> dict:
    """Return the default prompts for a given pipeline type."""
    pipeline = PIPELINES.get(pipeline_type)
    if not pipeline:
        return {}
    return dict(pipeline["defaultPrompts"])

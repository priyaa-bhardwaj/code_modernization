from flask import Blueprint, jsonify

from config.defaults import DASHBOARD_CARDS, MODELS, PIPELINES

config_bp = Blueprint("config", __name__, url_prefix="/api/config")


@config_bp.route("/dashboard", methods=["GET"])
def get_dashboard_cards():
    """Return all dashboard translation cards."""
    return jsonify(DASHBOARD_CARDS)


@config_bp.route("/models", methods=["GET"])
def get_models():
    """Return all available LLM models."""
    return jsonify(MODELS)


@config_bp.route("/pipelines", methods=["GET"])
def get_pipelines():
    """Return all pipeline configurations."""
    return jsonify(PIPELINES)


@config_bp.route("/pipelines/<pipeline_type>", methods=["GET"])
def get_pipeline(pipeline_type):
    """Return a single pipeline configuration."""
    pipeline = PIPELINES.get(pipeline_type)
    if not pipeline:
        return jsonify({"message": f"Pipeline '{pipeline_type}' not found"}), 404
    return jsonify(pipeline)

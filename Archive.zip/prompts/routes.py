from flask import Blueprint, request, jsonify, g

from database import get_db
from auth.helpers import login_required
from config.defaults import get_default_prompts

prompts_bp = Blueprint("prompts", __name__, url_prefix="/api/prompts")


@prompts_bp.route("/<pipeline_type>", methods=["GET"])
@login_required
def get_prompts(pipeline_type):
    """
    Return prompts for this user + pipeline.
    Falls back to system defaults for any keys the user hasn't customised.
    """
    defaults = get_default_prompts(pipeline_type)
    if not defaults:
        return jsonify({"message": f"Unknown pipeline type: {pipeline_type}"}), 404

    db = get_db()
    rows = db.execute(
        "SELECT prompt_key, prompt_text FROM user_prompts WHERE user_id = ? AND pipeline_type = ?",
        (g.user_id, pipeline_type),
    ).fetchall()
    db.close()

    # Merge: user overrides on top of defaults
    prompts = dict(defaults)
    for row in rows:
        prompts[row["prompt_key"]] = row["prompt_text"]

    return jsonify({"prompts": prompts, "isCustom": len(rows) > 0})


@prompts_bp.route("/<pipeline_type>", methods=["PUT"])
@login_required
def save_prompts(pipeline_type):
    """Save user's custom prompts for a pipeline type."""
    defaults = get_default_prompts(pipeline_type)
    if not defaults:
        return jsonify({"message": f"Unknown pipeline type: {pipeline_type}"}), 404

    data = request.get_json(silent=True) or {}
    prompts = data.get("prompts", data)  # accept {prompts: {...}} or flat {...}

    if not isinstance(prompts, dict) or not prompts:
        return jsonify({"message": "Prompts object is required"}), 400

    db = get_db()
    for key, text in prompts.items():
        if key not in defaults:
            continue  # skip unknown keys
        db.execute(
            """
            INSERT INTO user_prompts (user_id, pipeline_type, prompt_key, prompt_text, updated_at)
            VALUES (?, ?, ?, ?, CURRENT_TIMESTAMP)
            ON CONFLICT(user_id, pipeline_type, prompt_key)
            DO UPDATE SET prompt_text = excluded.prompt_text, updated_at = CURRENT_TIMESTAMP
            """,
            (g.user_id, pipeline_type, key, str(text)),
        )
    db.commit()
    db.close()

    return jsonify({"message": "Prompts saved"})


@prompts_bp.route("/<pipeline_type>", methods=["DELETE"])
@login_required
def reset_prompts(pipeline_type):
    """Delete user's custom prompts, resetting to system defaults."""
    db = get_db()
    db.execute(
        "DELETE FROM user_prompts WHERE user_id = ? AND pipeline_type = ?",
        (g.user_id, pipeline_type),
    )
    db.commit()
    db.close()

    defaults = get_default_prompts(pipeline_type)
    return jsonify({"message": "Prompts reset to defaults", "prompts": defaults, "isCustom": False})

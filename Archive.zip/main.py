import os
import logging

from dotenv import load_dotenv
from flask import Flask
from flask_cors import CORS

from database import init_db
from auth.routes import auth_bp
from config.routes import config_bp
from prompts.routes import prompts_bp
from translate.routes import translate_bp

# Load environment variables
load_dotenv()

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)

app = Flask(__name__)
CORS(app, resources={r"/api/*": {"origins": "*"}})

# Register blueprints
app.register_blueprint(auth_bp)
app.register_blueprint(config_bp)
app.register_blueprint(prompts_bp)
app.register_blueprint(translate_bp)


@app.route("/api/health", methods=["GET"])
def health():
    return {"status": "ok", "service": "code-modernization-backend"}


# Create workspace directory
os.makedirs(os.path.join(os.path.dirname(__file__), "workspace"), exist_ok=True)

# Initialize database
init_db()

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)

from flask import Blueprint, request, jsonify

from database import get_db
from auth.helpers import hash_password, verify_password, create_token

auth_bp = Blueprint("auth", __name__, url_prefix="/api/auth")


@auth_bp.route("/signup", methods=["POST"])
def signup():
    data = request.get_json(silent=True) or {}
    name = data.get("name", "").strip()
    email = data.get("email", "").strip().lower()
    password = data.get("password", "")

    if not name or not email or not password:
        return jsonify({"message": "Name, email, and password are required"}), 400

    if len(password) < 4:
        return jsonify({"message": "Password must be at least 4 characters"}), 400

    db = get_db()
    existing = db.execute("SELECT id FROM users WHERE email = ?", (email,)).fetchone()
    if existing:
        db.close()
        return jsonify({"message": "Email already registered"}), 409

    pw_hash = hash_password(password)
    cursor = db.execute(
        "INSERT INTO users (name, email, password_hash) VALUES (?, ?, ?)",
        (name, email, pw_hash),
    )
    db.commit()
    user_id = cursor.lastrowid
    db.close()

    token = create_token(user_id)
    return jsonify({
        "user": {"id": str(user_id), "name": name, "email": email},
        "token": token,
    }), 201


@auth_bp.route("/login", methods=["POST"])
def login():
    data = request.get_json(silent=True) or {}
    email = data.get("email", "").strip().lower()
    password = data.get("password", "")

    if not email or not password:
        return jsonify({"message": "Email and password are required"}), 400

    db = get_db()
    user = db.execute(
        "SELECT id, name, email, password_hash FROM users WHERE email = ?", (email,)
    ).fetchone()
    db.close()

    if not user or not verify_password(password, user["password_hash"]):
        return jsonify({"message": "Invalid email or password"}), 401

    token = create_token(user["id"])
    return jsonify({
        "user": {
            "id": str(user["id"]),
            "name": user["name"],
            "email": user["email"],
        },
        "token": token,
    })

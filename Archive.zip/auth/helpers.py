import os
from datetime import datetime, timedelta, timezone
from functools import wraps

from flask import request, jsonify, g
from jose import jwt, JWTError
import bcrypt

from database import get_db

JWT_SECRET = os.getenv("JWT_SECRET", "dev-secret-change-in-production")
JWT_ALGORITHM = "HS256"
JWT_EXPIRY_HOURS = 24


def hash_password(password: str) -> str:
    return bcrypt.hashpw(password.encode("utf-8"), bcrypt.gensalt()).decode("utf-8")


def verify_password(plain: str, hashed: str) -> bool:
    return bcrypt.checkpw(plain.encode("utf-8"), hashed.encode("utf-8"))


def create_token(user_id: int) -> str:
    payload = {
        "sub": str(user_id),
        "exp": datetime.now(timezone.utc) + timedelta(hours=JWT_EXPIRY_HOURS),
        "iat": datetime.now(timezone.utc),
    }
    return jwt.encode(payload, JWT_SECRET, algorithm=JWT_ALGORITHM)


def decode_token(token: str) -> dict:
    return jwt.decode(token, JWT_SECRET, algorithms=[JWT_ALGORITHM])


def login_required(f):
    """Decorator that validates JWT and sets g.user_id."""

    @wraps(f)
    def decorated(*args, **kwargs):
        auth_header = request.headers.get("Authorization", "")
        if not auth_header.startswith("Bearer "):
            return jsonify({"message": "Missing or invalid token"}), 401

        token = auth_header.split(" ", 1)[1]
        try:
            payload = decode_token(token)
            g.user_id = int(payload["sub"])
        except (JWTError, KeyError, ValueError):
            return jsonify({"message": "Invalid or expired token"}), 401

        # Verify user still exists
        db = get_db()
        user = db.execute("SELECT id FROM users WHERE id = ?", (g.user_id,)).fetchone()
        db.close()
        if not user:
            return jsonify({"message": "User not found"}), 401

        return f(*args, **kwargs)

    return decorated

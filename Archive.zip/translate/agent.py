"""
DeepAgent setup for code modernization.

Uses create_deep_agent with FilesystemMiddleware for workspace I/O.
Supports both autopilot (no interrupts) and HITL (interrupt after each step).
"""

import os
import logging
import traceback

from translate.jobs import job_store, StepState

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Try to import deepagents — fall back to a simple LLM-based approach
# if the library isn't installed or importable yet.
# ---------------------------------------------------------------------------

_DEEPAGENTS_AVAILABLE = False

try:
    from deepagents import create_deep_agent
    from deepagents.backends.filesystem import FilesystemBackend
    from langgraph.checkpoint.memory import MemorySaver
    from langgraph.types import Command

    _DEEPAGENTS_AVAILABLE = True
    logger.info("deepagents library loaded successfully")
except ImportError:
    logger.warning(
        "deepagents not available — falling back to direct LangChain LLM calls"
    )

# ---------------------------------------------------------------------------
# LLM helper — resolves model ID to a LangChain chat model
# ---------------------------------------------------------------------------

def _get_llm(model_id: str):
    """Resolve a model ID string to a LangChain ChatModel instance."""
    # if model_id.startswith("claude"):
    #     from langchain_anthropic import ChatAnthropic
    #     return ChatAnthropic(model=model_id, temperature=0)
    # elif model_id.startswith("gpt"):
    #     from langchain_openai import ChatOpenAI
    #     return ChatOpenAI(model=model_id, temperature=0)
    if model_id.startswith("gemini"):
        from langchain_google_genai import ChatGoogleGenerativeAI
        # Map legacy 'gemini-pro' to the current model to avoid 404 errors
        if model_id == "gemini-pro":
            model_id = "gemini-1.5-pro"
        return ChatGoogleGenerativeAI(
            model=model_id,
            temperature=0,
        )
    # else:
    #     # Default to OpenAI-compatible
    #     from langchain_openai import ChatOpenAI
    #     return ChatOpenAI(model=model_id, temperature=0)


# ---------------------------------------------------------------------------
# Read workspace files into a string context
# ---------------------------------------------------------------------------

def _read_workspace_files(directory: str) -> str:
    """Read all files in a directory tree and return as a combined string."""
    if not os.path.isdir(directory):
        return ""

    parts = []
    for root, _dirs, files in os.walk(directory):
        for fname in sorted(files):
            fpath = os.path.join(root, fname)
            rel = os.path.relpath(fpath, directory)
            try:
                with open(fpath, "r", errors="replace") as f:
                    content = f.read()
                parts.append(f"--- FILE: {rel} ---\n{content}\n")
            except Exception:
                parts.append(f"--- FILE: {rel} --- (binary/unreadable)\n")
    return "\n".join(parts)


# ---------------------------------------------------------------------------
# Write agent output files to workspace
# ---------------------------------------------------------------------------

def _write_output_files(output_dir: str, output) -> dict:
    """
    Given agent output that may be:
      - a dict of {filepath: content}
      - a plain string
    Write files and return the dict.
    """
    os.makedirs(output_dir, exist_ok=True)

    if isinstance(output, dict):
        for filepath, content in output.items():
            full_path = os.path.join(output_dir, filepath)
            os.makedirs(os.path.dirname(full_path), exist_ok=True)
            with open(full_path, "w") as f:
                f.write(str(content))
        return output
    else:
        # Single string — write to output.md
        out_path = os.path.join(output_dir, "output.md")
        with open(out_path, "w") as f:
            f.write(str(output))
        return str(output)


# ---------------------------------------------------------------------------
# Run a pipeline step via LLM (fallback when deepagents isn't available)
# ---------------------------------------------------------------------------

def _run_step_with_llm(llm, system_context: str, user_prompt: str) -> str:
    """Run a single step by invoking the LLM directly."""
    from langchain_core.messages import SystemMessage, HumanMessage

    messages = [
        SystemMessage(content=system_context),
        HumanMessage(content=user_prompt),
    ]
    response = llm.invoke(messages)
    return response.content


# ---------------------------------------------------------------------------
# Main pipeline runner — called in a background thread
# ---------------------------------------------------------------------------

def run_pipeline(job_id: str):
    """
    Execute the 3-step modernization pipeline for a job.
    Runs in a background thread.
    """
    job = job_store.get(job_id)
    if not job:
        logger.error(f"Job {job_id} not found")
        return

    workspace = os.path.join(
        os.path.dirname(__file__), "..", "workspace", job_id
    )
    input_dir = os.path.join(workspace, "input")
    context_dir = os.path.join(workspace, "context")
    output_dir = os.path.join(workspace, "output")
    os.makedirs(output_dir, exist_ok=True)

    prompts = job.prompts
    pipeline_type = job.pipeline_type
    execution_mode = job.execution_mode
    step_names = [s.name for s in job.steps]
    prompt_keys = list(prompts.keys())

    try:
        # ---- Attempt DeepAgent approach ----
        if _DEEPAGENTS_AVAILABLE:
            _run_with_deepagent(
                job_id, job, workspace, input_dir, context_dir, output_dir,
                prompts, prompt_keys, step_names, execution_mode,
            )
        else:
            _run_with_direct_llm(
                job_id, job, workspace, input_dir, context_dir, output_dir,
                prompts, prompt_keys, step_names, execution_mode,
            )
    except Exception as e:
        logger.error(f"Pipeline error for job {job_id}: {traceback.format_exc()}")
        current = job_store.get(job_id)
        if current:
            step_idx = current.current_step
            if 0 <= step_idx < len(current.steps):
                current.steps[step_idx].status = "error"
                current.steps[step_idx].error = str(e)
            job_store.update(job_id, status="failed")


def _run_with_deepagent(
    job_id, job, workspace, input_dir, context_dir, output_dir,
    prompts, prompt_keys, step_names, execution_mode,
):
    """Run pipeline using create_deep_agent + FilesystemMiddleware."""
    checkpointer = MemorySaver()

    # Build interrupt config for HITL
    interrupt_config = {}
    if execution_mode == "human":
        interrupt_config = {"write_file": True}

    agent = create_deep_agent(
        model=_get_llm(job.model),
        backend=FilesystemBackend(root_dir=workspace),
        interrupt_on=interrupt_config,
        checkpointer=checkpointer,
        system_prompt=(
            "You are a code modernization agent. "
            "Read source files from /input/ directory. "
            "Write modernized output files to /output/ directory. "
            "Follow the user's prompts exactly for each step."
        ),
    )

    config = {"configurable": {"thread_id": job.thread_id}}

    # Read source files for context
    source_context = _read_workspace_files(input_dir)
    context_text = _read_workspace_files(context_dir)

    accumulated_context = ""

    for step_idx in range(len(step_names)):
        # Mark step running
        job_store.get(job_id).steps[step_idx].status = "running"
        job_store.update(job_id, current_step=step_idx)

        prompt_key = prompt_keys[step_idx] if step_idx < len(prompt_keys) else "reflect"
        user_prompt = prompts.get(prompt_key, "Proceed with this step.")

        # Build step message
        if step_idx == 0:
            message = (
                f"STEP {step_idx + 1} — {step_names[step_idx]}:\n\n"
                f"{user_prompt}\n\n"
                f"SOURCE FILES:\n{source_context}\n\n"
            )
            if context_text:
                message += f"ADDITIONAL CONTEXT:\n{context_text}\n\n"
        elif step_idx == 1:
            message = (
                f"STEP {step_idx + 1} — {step_names[step_idx]}:\n\n"
                f"{user_prompt}\n\n"
                f"Previous step output:\n{accumulated_context}\n\n"
                f"Write the modernized code files to the /output/ directory."
            )
        else:
            message = (
                f"STEP {step_idx + 1} — {step_names[step_idx]}:\n\n"
                f"{user_prompt}\n\n"
                f"Previous step output:\n{accumulated_context}\n\n"
                f"Original source:\n{source_context[:3000]}\n"
            )

        try:
            result = agent.invoke(
                {"messages": [{"role": "user", "content": message}]},
                config=config,
            )

            # Extract output
            if hasattr(result, "messages") and result.messages:
                step_output = result.messages[-1].content
            elif isinstance(result, dict) and "messages" in result:
                msgs = result["messages"]
                step_output = msgs[-1].content if msgs else ""
            else:
                step_output = str(result)

            accumulated_context = step_output

            # For step 1, try to write output files
            if step_idx == 1:
                _write_output_files(output_dir, step_output)

            job_store.get(job_id).steps[step_idx].status = "complete"
            job_store.get(job_id).steps[step_idx].output = step_output

            # In HITL mode, pause after step completion
            if execution_mode == "human" and step_idx < len(step_names) - 1:
                job_store.get(job_id).steps[step_idx].status = "waiting_approval"
                job_store.update(job_id, status="waiting_approval")
                # The thread will exit here — resume is handled by approve/reprompt
                return

        except Exception as e:
            if "interrupt" in str(e).lower():
                # Agent was interrupted for HITL
                job_store.get(job_id).steps[step_idx].status = "waiting_approval"
                job_store.update(job_id, status="waiting_approval")
                return
            raise

    job_store.update(job_id, status="completed")


def _run_with_direct_llm(
    job_id, job, workspace, input_dir, context_dir, output_dir,
    prompts, prompt_keys, step_names, execution_mode,
):
    """Fallback: run pipeline using direct LLM calls (no deepagents)."""
    llm = _get_llm(job.model)

    source_context = _read_workspace_files(input_dir)
    context_text = _read_workspace_files(context_dir)

    system_context = (
        "You are a code modernization agent. "
        "You analyze source code and generate modernized versions. "
        "Be thorough, follow best practices, and produce production-ready output."
    )

    accumulated_context = ""

    for step_idx in range(len(step_names)):
        # Mark step running
        job_store.get(job_id).steps[step_idx].status = "running"
        job_store.update(job_id, current_step=step_idx)

        prompt_key = prompt_keys[step_idx] if step_idx < len(prompt_keys) else "reflect"
        user_prompt = prompts.get(prompt_key, "Proceed with this step.")

        # Build the message for this step
        if step_idx == 0:
            full_prompt = (
                f"STEP: {step_names[step_idx]}\n\n"
                f"INSTRUCTION: {user_prompt}\n\n"
                f"SOURCE FILES:\n{source_context}\n"
            )
            if context_text:
                full_prompt += f"\nADDITIONAL CONTEXT:\n{context_text}\n"
        elif step_idx == 1:
            full_prompt = (
                f"STEP: {step_names[step_idx]}\n\n"
                f"INSTRUCTION: {user_prompt}\n\n"
                f"PREVIOUS STEP OUTPUT:\n{accumulated_context}\n\n"
                f"Generate the modernized code. For each file, use the format:\n"
                f"--- FILE: path/to/file.ext ---\n<file content>\n"
            )
        else:
            full_prompt = (
                f"STEP: {step_names[step_idx]}\n\n"
                f"INSTRUCTION: {user_prompt}\n\n"
                f"PREVIOUS STEP OUTPUT:\n{accumulated_context}\n\n"
                f"ORIGINAL SOURCE (first 3000 chars):\n{source_context[:3000]}\n"
            )

        step_output = _run_step_with_llm(llm, system_context, full_prompt)
        accumulated_context = step_output

        # For step 1 (modernization), write output files
        if step_idx == 1:
            parsed_files = _parse_file_output(step_output)
            if parsed_files:
                _write_output_files(output_dir, parsed_files)
                step_output = parsed_files
            else:
                _write_output_files(output_dir, step_output)

        job_store.get(job_id).steps[step_idx].status = "complete"
        job_store.get(job_id).steps[step_idx].output = step_output

        # In HITL mode, after completing a step, set waiting_approval
        if execution_mode == "human" and step_idx < len(step_names) - 1:
            job_store.get(job_id).steps[step_idx].status = "waiting_approval"
            job_store.update(job_id, status="waiting_approval")
            return  # Thread exits — resume via approve endpoint

    job_store.update(job_id, status="completed")


def _parse_file_output(text: str) -> dict | None:
    """
    Try to parse LLM output that uses --- FILE: path --- markers
    into a dict of {filepath: content}.
    """
    import re

    pattern = r"---\s*FILE:\s*(.+?)\s*---\n(.*?)(?=---\s*FILE:|$)"
    matches = re.findall(pattern, text, re.DOTALL)
    if not matches:
        return None
    return {path.strip(): content.strip() for path, content in matches}


# ---------------------------------------------------------------------------
# Resume a paused HITL job from a specific step
# ---------------------------------------------------------------------------

def resume_pipeline(job_id: str, from_step: int, new_prompt: str | None = None):
    """
    Resume a HITL job from a given step.
    If new_prompt is provided, re-run the step with the new prompt.
    Otherwise, approve the step and move to the next one.
    """
    job = job_store.get(job_id)
    if not job:
        return

    if new_prompt:
        # Re-run the current step with updated prompt
        prompt_keys = list(job.prompts.keys())
        if from_step < len(prompt_keys):
            key = prompt_keys[from_step]
            job.prompts[key] = new_prompt

        # Reset this step
        job.steps[from_step].status = "running"
        job.steps[from_step].output = None
        job.steps[from_step].error = None
        job_store.update(job_id, status="running", current_step=from_step)
    else:
        # Approve — mark current step as complete, start next
        job.steps[from_step].status = "complete"

        next_step = from_step + 1
        if next_step >= len(job.steps):
            job_store.update(job_id, status="completed")
            return
        else:
            job_store.update(job_id, status="running", current_step=next_step)

    # Re-run from the current step in a thread
    import threading
    t = threading.Thread(target=_continue_pipeline, args=(job_id,), daemon=True)
    t.start()


def _continue_pipeline(job_id: str):
    """Continue the pipeline from wherever current_step is."""
    job = job_store.get(job_id)
    if not job:
        return

    workspace = os.path.join(os.path.dirname(__file__), "..", "workspace", job_id)
    input_dir = os.path.join(workspace, "input")
    context_dir = os.path.join(workspace, "context")
    output_dir = os.path.join(workspace, "output")
    os.makedirs(output_dir, exist_ok=True)

    prompts = job.prompts
    prompt_keys = list(prompts.keys())
    step_names = [s.name for s in job.steps]
    execution_mode = job.execution_mode
    start_step = job.current_step

    try:
        llm = _get_llm(job.model)
    except Exception as e:
        logger.error(f"Failed to initialise LLM for job {job_id}: {e}")
        job_store.update(job_id, status="failed")
        return

    source_context = _read_workspace_files(input_dir)
    context_text = _read_workspace_files(context_dir)

    # Gather accumulated context from previous completed steps
    accumulated_context = ""
    for i in range(start_step):
        step = job.steps[i]
        if step.output:
            if isinstance(step.output, dict):
                accumulated_context = "\n".join(
                    f"--- FILE: {k} ---\n{v}" for k, v in step.output.items()
                )
            else:
                accumulated_context = str(step.output)

    system_context = (
        "You are a code modernization agent. "
        "You analyze source code and generate modernized versions. "
        "Be thorough, follow best practices, and produce production-ready output."
    )

    try:
        for step_idx in range(start_step, len(step_names)):
            job_store.get(job_id).steps[step_idx].status = "running"
            job_store.update(job_id, current_step=step_idx)

            prompt_key = prompt_keys[step_idx] if step_idx < len(prompt_keys) else "reflect"
            user_prompt = prompts.get(prompt_key, "Proceed with this step.")

            if step_idx == 0:
                full_prompt = (
                    f"STEP: {step_names[step_idx]}\n\nINSTRUCTION: {user_prompt}\n\n"
                    f"SOURCE FILES:\n{source_context}\n"
                )
                if context_text:
                    full_prompt += f"\nADDITIONAL CONTEXT:\n{context_text}\n"
            elif step_idx == 1:
                full_prompt = (
                    f"STEP: {step_names[step_idx]}\n\nINSTRUCTION: {user_prompt}\n\n"
                    f"PREVIOUS STEP OUTPUT:\n{accumulated_context}\n\n"
                    f"Generate the modernized code. For each file, use the format:\n"
                    f"--- FILE: path/to/file.ext ---\n<file content>\n"
                )
            else:
                full_prompt = (
                    f"STEP: {step_names[step_idx]}\n\nINSTRUCTION: {user_prompt}\n\n"
                    f"PREVIOUS STEP OUTPUT:\n{accumulated_context}\n\n"
                    f"ORIGINAL SOURCE (first 3000 chars):\n{source_context[:3000]}\n"
                )

            step_output = _run_step_with_llm(llm, system_context, full_prompt)
            accumulated_context = step_output

            if step_idx == 1:
                parsed_files = _parse_file_output(step_output)
                if parsed_files:
                    _write_output_files(output_dir, parsed_files)
                    step_output = parsed_files
                else:
                    _write_output_files(output_dir, step_output)

            job_store.get(job_id).steps[step_idx].status = "complete"
            job_store.get(job_id).steps[step_idx].output = step_output

            if execution_mode == "human" and step_idx < len(step_names) - 1:
                job_store.get(job_id).steps[step_idx].status = "waiting_approval"
                job_store.update(job_id, status="waiting_approval")
                return

        job_store.update(job_id, status="completed")

    except Exception as e:
        logger.error(f"Continue pipeline error for {job_id}: {traceback.format_exc()}")
        current = job_store.get(job_id)
        if current:
            si = current.current_step
            if 0 <= si < len(current.steps):
                current.steps[si].status = "error"
                current.steps[si].error = str(e)
            job_store.update(job_id, status="failed")

import os
import uuid
import shutil
import zipfile
import threading
import logging
from io import BytesIO

from flask import Blueprint, request, jsonify, g, send_file

from auth.helpers import login_required
from config.defaults import PIPELINES, get_default_prompts
from translate.jobs import job_store, JobState, StepState
from translate.agent import run_pipeline, resume_pipeline
from database import get_db

logger = logging.getLogger(__name__)

translate_bp = Blueprint("translate", __name__, url_prefix="/api/translate")

WORKSPACE_ROOT = os.path.join(os.path.dirname(__file__), "..", "workspace")


# ---------------------------------------------------------------------------
# Upload source zip
# ---------------------------------------------------------------------------

@translate_bp.route("/upload", methods=["POST"])
@login_required
def upload_zip():
    """Receive a zip file, extract to workspace/<file_id>/input/."""
    if "file" not in request.files:
        return jsonify({"message": "No file uploaded"}), 400

    file = request.files["file"]
    file_id = f"file-{uuid.uuid4().hex[:12]}"
    input_dir = os.path.join(WORKSPACE_ROOT, file_id, "input")
    os.makedirs(input_dir, exist_ok=True)

    # Save and extract zip
    zip_path = os.path.join(WORKSPACE_ROOT, file_id, "upload.zip")
    file.save(zip_path)

    try:
        with zipfile.ZipFile(zip_path, "r") as zf:
            zf.extractall(input_dir)
        os.remove(zip_path)
    except zipfile.BadZipFile:
        # Not a zip — save as raw file
        shutil.move(zip_path, os.path.join(input_dir, file.filename or "uploaded_file"))

    return jsonify({"fileId": file_id}), 201


# ---------------------------------------------------------------------------
# Upload context files
# ---------------------------------------------------------------------------

@translate_bp.route("/context", methods=["POST"])
@login_required
def upload_context():
    """Receive context files, store in workspace/<file_id>/context/."""
    files = request.files.getlist("context")
    if not files:
        return jsonify({"message": "No context files uploaded"}), 400

    # Use the file_id from the query param or generate one
    file_id = request.args.get("fileId", f"file-{uuid.uuid4().hex[:12]}")
    context_dir = os.path.join(WORKSPACE_ROOT, file_id, "context")
    os.makedirs(context_dir, exist_ok=True)

    context_ids = []
    for f in files:
        ctx_id = f"ctx-{uuid.uuid4().hex[:8]}"
        f.save(os.path.join(context_dir, f.filename or ctx_id))
        context_ids.append(ctx_id)

    return jsonify({"contextIds": context_ids}), 201


# ---------------------------------------------------------------------------
# Start generation
# ---------------------------------------------------------------------------

@translate_bp.route("/generate", methods=["POST"])
@login_required
def generate():
    """Start the modernization pipeline."""
    data = request.get_json(silent=True) or {}

    file_id = data.get("fileId")
    translation_id = data.get("translationId", "")
    model = data.get("model", "claude-sonnet-4")
    pipeline_type = data.get("pipelineType", "spec-to-code")
    execution_mode = data.get("executionMode", "human")
    context_ids = data.get("contextIds", [])
    user_prompts = data.get("prompts", {})

    if not file_id:
        return jsonify({"message": "fileId is required"}), 400

    pipeline = PIPELINES.get(pipeline_type)
    if not pipeline:
        return jsonify({"message": f"Unknown pipeline: {pipeline_type}"}), 400

    # Resolve prompts: user-submitted > user-saved > defaults
    defaults = get_default_prompts(pipeline_type)
    saved_prompts = _load_user_prompts(g.user_id, pipeline_type)

    # Merge: defaults < saved < submitted
    final_prompts = {**defaults, **saved_prompts, **user_prompts}

    # Create job
    job_id = f"job-{uuid.uuid4().hex[:12]}"
    thread_id = str(uuid.uuid4())

    # Move input files into the job workspace
    source_dir = os.path.join(WORKSPACE_ROOT, file_id)
    job_dir = os.path.join(WORKSPACE_ROOT, job_id)

    if os.path.exists(source_dir):
        shutil.copytree(source_dir, job_dir, dirs_exist_ok=True)
        # Clean up uploaded file workspace
        shutil.rmtree(source_dir, ignore_errors=True)

    # Create step states
    steps = [StepState(name=name) for name in pipeline["steps"]]
    steps[0].status = "running"

    job = JobState(
        job_id=job_id,
        user_id=g.user_id,
        thread_id=thread_id,
        pipeline_type=pipeline_type,
        execution_mode=execution_mode,
        model=model,
        prompts=final_prompts,
        file_id=file_id,
        translation_id=translation_id,
        context_ids=context_ids,
        steps=steps,
    )
    job_store.create(job)

    # Run pipeline in background thread
    t = threading.Thread(target=run_pipeline, args=(job_id,), daemon=True)
    t.start()

    return jsonify({"jobId": job_id}), 202


def _load_user_prompts(user_id: int, pipeline_type: str) -> dict:
    """Load user's saved prompts from DB."""
    db = get_db()
    rows = db.execute(
        "SELECT prompt_key, prompt_text FROM user_prompts WHERE user_id = ? AND pipeline_type = ?",
        (user_id, pipeline_type),
    ).fetchall()
    db.close()
    return {row["prompt_key"]: row["prompt_text"] for row in rows}


# ---------------------------------------------------------------------------
# Poll job status
# ---------------------------------------------------------------------------

@translate_bp.route("/job/<job_id>", methods=["GET"])
@login_required
def get_job_status(job_id):
    """Return current job status for frontend polling."""
    status = job_store.to_status_dict(job_id)
    if not status:
        return jsonify({"message": "Job not found"}), 404
    return jsonify(status)


# ---------------------------------------------------------------------------
# Approve step (HITL)
# ---------------------------------------------------------------------------

@translate_bp.route("/job/<job_id>/approve/<int:step_index>", methods=["POST"])
@login_required
def approve_step(job_id, step_index):
    """Approve a step and advance the pipeline."""
    job = job_store.get(job_id)
    if not job:
        return jsonify({"message": "Job not found"}), 404

    if step_index < 0 or step_index >= len(job.steps):
        return jsonify({"message": "Invalid step index"}), 400

    resume_pipeline(job_id, step_index, new_prompt=None)
    return jsonify({"message": "Step approved, pipeline advancing"})


# ---------------------------------------------------------------------------
# Reprompt step (HITL)
# ---------------------------------------------------------------------------

@translate_bp.route("/job/<job_id>/reprompt/<int:step_index>", methods=["POST"])
@login_required
def reprompt_step(job_id, step_index):
    """Re-run a step with a new prompt."""
    job = job_store.get(job_id)
    if not job:
        return jsonify({"message": "Job not found"}), 404

    data = request.get_json(silent=True) or {}
    new_prompt = data.get("prompt", "")
    if not new_prompt:
        return jsonify({"message": "Prompt is required"}), 400

    resume_pipeline(job_id, step_index, new_prompt=new_prompt)
    return jsonify({"message": "Step re-running with new prompt"})


# ---------------------------------------------------------------------------
# Download result + auto-cleanup
# ---------------------------------------------------------------------------

@translate_bp.route("/job/<job_id>/download", methods=["GET"])
@login_required
def download_result(job_id):
    """Zip the output directory, send it, then clean up the workspace."""
    job = job_store.get(job_id)
    if not job:
        return jsonify({"message": "Job not found"}), 404

    output_dir = os.path.join(WORKSPACE_ROOT, job_id, "output")
    if not os.path.isdir(output_dir):
        return jsonify({"message": "No output files found"}), 404

    # Create zip in memory
    zip_buffer = BytesIO()
    with zipfile.ZipFile(zip_buffer, "w", zipfile.ZIP_DEFLATED) as zf:
        for root, _dirs, files in os.walk(output_dir):
            for fname in files:
                fpath = os.path.join(root, fname)
                arcname = os.path.relpath(fpath, output_dir)
                zf.write(fpath, arcname)
    zip_buffer.seek(0)

    # Schedule cleanup after response
    workspace_dir = os.path.join(WORKSPACE_ROOT, job_id)

    def cleanup():
        import time
        time.sleep(2)  # brief delay to ensure response is sent
        shutil.rmtree(workspace_dir, ignore_errors=True)
        job_store.delete(job_id)
        logger.info(f"Auto-cleaned workspace for job {job_id}")

    threading.Thread(target=cleanup, daemon=True).start()

    return send_file(
        zip_buffer,
        mimetype="application/zip",
        as_attachment=True,
        download_name=f"modernized-{job_id}.zip",
    )

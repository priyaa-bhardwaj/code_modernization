"""
Thread-safe in-memory job state store.
"""

import threading
from dataclasses import dataclass, field
from typing import Any


@dataclass
class StepState:
    name: str
    status: str = "pending"  # pending | running | complete | error | waiting_approval
    output: Any = None
    error: str | None = None


@dataclass
class JobState:
    job_id: str
    user_id: int
    thread_id: str
    pipeline_type: str
    execution_mode: str  # "human" | "autopilot"
    model: str
    prompts: dict
    file_id: str
    translation_id: str
    context_ids: list = field(default_factory=list)
    status: str = "running"  # running | completed | failed
    current_step: int = 0
    steps: list = field(default_factory=list)


class JobStore:
    """Thread-safe job store."""

    def __init__(self):
        self._jobs: dict[str, JobState] = {}
        self._lock = threading.Lock()

    def create(self, job: JobState) -> None:
        with self._lock:
            self._jobs[job.job_id] = job

    def get(self, job_id: str) -> JobState | None:
        with self._lock:
            return self._jobs.get(job_id)

    def update(self, job_id: str, **kwargs) -> None:
        with self._lock:
            job = self._jobs.get(job_id)
            if job:
                for k, v in kwargs.items():
                    setattr(job, k, v)

    def delete(self, job_id: str) -> None:
        with self._lock:
            self._jobs.pop(job_id, None)

    def get_step(self, job_id: str, step_index: int) -> StepState | None:
        with self._lock:
            job = self._jobs.get(job_id)
            if job and 0 <= step_index < len(job.steps):
                return job.steps[step_index]
            return None

    def to_status_dict(self, job_id: str) -> dict | None:
        with self._lock:
            job = self._jobs.get(job_id)
            if not job:
                return None
            return {
                "jobId": job.job_id,
                "status": job.status,
                "currentStep": job.current_step,
                "executionMode": job.execution_mode,
                "pipelineType": job.pipeline_type,
                "steps": [
                    {
                        "name": s.name,
                        "status": s.status,
                        "output": s.output,
                        "error": s.error,
                    }
                    for s in job.steps
                ],
            }


# Singleton
job_store = JobStore()

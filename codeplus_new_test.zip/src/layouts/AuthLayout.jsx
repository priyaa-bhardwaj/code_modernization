import { Outlet, Link } from 'react-router-dom'
import { Code2, Sun, Moon } from 'lucide-react'
import useThemeStore from '../stores/themeStore'

export default function AuthLayout() {
  const { theme, toggleTheme } = useThemeStore()

  return (
    <div className="min-h-screen bg-surface flex items-center justify-center p-4 relative overflow-hidden">
      {/* Theme toggle */}
      <button
        onClick={toggleTheme}
        className="absolute top-4 right-4 z-10 p-2.5 rounded-xl bg-surface-card border border-surface-border hover:bg-surface-hover text-text-secondary hover:text-text-primary transition-all cursor-pointer"
        title={theme === 'dark' ? 'Switch to light mode' : 'Switch to dark mode'}
      >
        {theme === 'dark' ? (
          <Sun className="w-4 h-4" />
        ) : (
          <Moon className="w-4 h-4" />
        )}
      </button>
      {/* Background grid pattern */}
      <div
        className="absolute inset-0 opacity-[0.03]"
        style={{
          backgroundImage:
            'linear-gradient(rgba(99,102,241,0.5) 1px, transparent 1px), linear-gradient(90deg, rgba(99,102,241,0.5) 1px, transparent 1px)',
          backgroundSize: '60px 60px',
        }}
      />

      {/* Gradient orbs */}
      <div className="absolute top-1/4 -left-32 w-96 h-96 bg-brand-600/20 rounded-full blur-3xl" />
      <div className="absolute bottom-1/4 -right-32 w-96 h-96 bg-brand-400/10 rounded-full blur-3xl" />

      <div className="relative w-full max-w-md">
        {/* Logo */}
        <Link to="/" className="flex items-center justify-center gap-3 mb-8">
          <div className="w-10 h-10 bg-gradient-to-br from-brand-500 to-brand-700 rounded-xl flex items-center justify-center">
            <Code2 className="w-5 h-5 text-white" />
          </div>
          <span className="text-2xl font-bold text-text-primary tracking-tight">
            CODE<span className="text-brand-400">PLUS</span>
          </span>
        </Link>

        <p className="text-center text-text-secondary text-sm mb-8">
          Modernize your legacy code with AI-powered intelligence
        </p>

        {/* Auth card */}
        <div className="bg-surface-card border border-surface-border rounded-2xl p-8 shadow-2xl shadow-black/20">
          <Outlet />
        </div>
      </div>
    </div>
  )
}

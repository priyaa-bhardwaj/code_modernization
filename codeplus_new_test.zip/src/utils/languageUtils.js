const EXT_TO_LANGUAGE = {
  java: 'java',
  xml: 'xml',
  yml: 'yaml',
  yaml: 'yaml',
  json: 'json',
  properties: 'ini',
  md: 'markdown',
  js: 'javascript',
  jsx: 'javascript',
  ts: 'typescript',
  tsx: 'typescript',
  html: 'html',
  css: 'css',
  sql: 'sql',
  sh: 'shell',
  gradle: 'groovy',
  kt: 'kotlin',
  py: 'python',
  go: 'go',
  rs: 'rust',
  rb: 'ruby',
  cs: 'csharp',
  cpp: 'cpp',
  c: 'c',
  h: 'c',
}

export function inferLanguage(filePath) {
  const ext = filePath.split('.').pop().toLowerCase()
  return EXT_TO_LANGUAGE[ext] || 'plaintext'
}

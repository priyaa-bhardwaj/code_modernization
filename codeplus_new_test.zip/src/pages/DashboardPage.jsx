import { motion } from 'framer-motion'
import { Sparkles } from 'lucide-react'
import TranslationGrid from '../components/dashboard/TranslationGrid'

export default function DashboardPage() {
  return (
    <div>
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-8"
      >
        <div className="flex items-center gap-3 mb-2">
          <Sparkles className="w-6 h-6 text-brand-400" />
          <h1 className="text-2xl font-bold text-text-primary">
            Choose a Modernization Path
          </h1>
        </div>
        <p className="text-text-secondary max-w-2xl">
          Select a source-to-target language pair to begin your code modernization
          journey. Our AI-powered pipeline will analyze, transform, and validate
          your codebase.
        </p>
      </motion.div>

      {/* Translation Grid */}
      <TranslationGrid />
    </div>
  )
}

import { useEffect, useState } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import { motion } from 'framer-motion'
import { ArrowLeft, ArrowRight, Zap } from 'lucide-react'
import { getTranslationById } from '../config/translations'
import useTranslationStore from '../stores/translationStore'
import useWorkflowStore from '../stores/workflowStore'
import { translationService } from '../services/translationService'
import PipelineSelector from '../components/workspace/PipelineSelector'
import FileUpload from '../components/workspace/FileUpload'
import ContextUpload from '../components/workspace/ContextUpload'
import ModelSelector from '../components/workspace/ModelSelector'
import PromptEditor from '../components/workspace/PromptEditor'
import ExecutionModeSelector from '../components/workspace/ExecutionModeSelector'
import Button from '../components/ui/Button'
import toast from 'react-hot-toast'

export default function WorkspacePage() {
  const { id } = useParams()
  const navigate = useNavigate()
  const translation = getTranslationById(id)
  const {
    uploadedFile,
    selectedModel,
    prompts,
    pipelineType,
    executionMode,
    contextFiles,
    setTranslation,
  } = useTranslationStore()
  const { startGeneration } = useWorkflowStore()
  const [isSubmitting, setIsSubmitting] = useState(false)

  useEffect(() => {
    if (translation) {
      setTranslation(translation)
    }
  }, [translation, setTranslation])

  if (!translation) {
    return (
      <div className="flex flex-col items-center justify-center py-20">
        <p className="text-text-secondary mb-4">Translation path not found</p>
        <Button variant="secondary" onClick={() => navigate('/dashboard')}>
          Back to Dashboard
        </Button>
      </div>
    )
  }

  const handleGenerate = async () => {
    if (!uploadedFile) {
      toast.error('Please upload a project file first')
      return
    }

    setIsSubmitting(true)
    try {
      // Upload source code
      const { fileId } = await translationService.uploadZip(uploadedFile)

      // Upload context files if any
      let contextIds = []
      if (contextFiles.length > 0) {
        const result = await translationService.uploadContext(contextFiles)
        contextIds = result.contextIds
      }

      // Start generation
      const { jobId } = await translationService.generate({
        fileId,
        translationId: id,
        model: selectedModel,
        prompts,
        pipelineType,
        executionMode,
        contextIds,
      })

      toast.success('Generation started!')
      startGeneration(jobId, executionMode, pipelineType)
      navigate(`/workflow/${jobId}`)
    } catch {
      toast.error('Failed to start generation')
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <div className="max-w-4xl mx-auto">
      {/* Back button */}
      <button
        onClick={() => navigate('/dashboard')}
        className="flex items-center gap-1.5 text-sm text-text-muted hover:text-text-primary transition-colors mb-6 cursor-pointer"
      >
        <ArrowLeft className="w-4 h-4" />
        Back to Dashboard
      </button>

      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-8"
      >
        <div className="flex items-center gap-3 mb-2">
          <span
            className="inline-flex items-center px-3 py-1 text-sm font-semibold rounded-lg border"
            style={{
              backgroundColor: translation.fromColor + '15',
              color: translation.fromColor,
              borderColor: translation.fromColor + '30',
            }}
          >
            {translation.from}
          </span>
          <ArrowRight className="w-5 h-5 text-text-muted" />
          <span
            className="inline-flex items-center px-3 py-1 text-sm font-semibold rounded-lg border"
            style={{
              backgroundColor: translation.toColor + '15',
              color: translation.toColor,
              borderColor: translation.toColor + '30',
            }}
          >
            {translation.to}
          </span>
        </div>
        <p className="text-text-secondary text-sm">{translation.description}</p>
      </motion.div>

      {/* Sections */}
      <div className="space-y-8">
        {/* 1. Pipeline Selection */}
        <motion.section
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.05 }}
        >
          <h3 className="text-sm font-medium text-text-secondary mb-3">
            1. Choose Pipeline
          </h3>
          <PipelineSelector />
        </motion.section>

        {/* 2. Upload Source Code */}
        <motion.section
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
        >
          <h3 className="text-sm font-medium text-text-secondary mb-3">
            2. Upload Source Code
          </h3>
          <FileUpload />
        </motion.section>

        {/* 3. Execution Mode */}
        <motion.section
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
        >
          <h3 className="text-sm font-medium text-text-secondary mb-3">
            3. Execution Mode
          </h3>
          <ExecutionModeSelector />
        </motion.section>

        {/* 4. Enterprise Context (Optional) */}
        <motion.section
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.15 }}
        >
          <h3 className="text-sm font-medium text-text-secondary mb-3">
            4. Enterprise Context{' '}
            <span className="text-text-muted font-normal">(Optional)</span>
          </h3>
          <ContextUpload />
        </motion.section>

        {/* 5. Model Selection */}
        <motion.section
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
        >
          <h3 className="text-sm font-medium text-text-secondary mb-3">
            5. Choose AI Model
          </h3>
          <ModelSelector />
        </motion.section>

        {/* 6. Prompts */}
        <motion.section
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.25 }}
        >
          <h3 className="text-sm font-medium text-text-secondary mb-3">
            6. Configure Prompts
          </h3>
          <PromptEditor />
        </motion.section>

        
      </div>

      {/* Generate Button - Sticky Bottom */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.35 }}
        className="sticky bottom-0 bg-gradient-to-t from-surface via-surface to-transparent pt-8 pb-4 mt-8"
      >
        <Button
          onClick={handleGenerate}
          isLoading={isSubmitting}
          disabled={!uploadedFile}
          size="lg"
          className="w-full text-base"
        >
          <Zap className="w-5 h-5" />
          Generate Modernized Code
        </Button>
        {!uploadedFile && (
          <p className="text-xs text-text-muted text-center mt-2">
            Upload a project file to enable generation
          </p>
        )}
      </motion.div>
    </div>
  )
}

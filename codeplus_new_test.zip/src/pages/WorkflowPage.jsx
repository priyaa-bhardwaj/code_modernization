import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { motion } from 'framer-motion'
import { ArrowLeft, ChevronDown, ChevronRight } from 'lucide-react'
import useWorkflowStore from '../stores/workflowStore'
import Stepper from '../components/workflow/Stepper'
import StepPanel from '../components/workflow/StepPanel'
import DownloadPanel from '../components/workflow/DownloadPanel'

export default function WorkflowPage() {
  const navigate = useNavigate()
  const {
    jobId,
    currentStep,
    steps,
    isComplete,
    executionMode,
    pipelineType,
    approveStep,
    editStepOutput,
    repromptStep,
  } = useWorkflowStore()

  const isAutopilot = executionMode === 'autopilot'

  // For autopilot completed state: track which step panels are expanded
  const [expandedSteps, setExpandedSteps] = useState({})

  const toggleStep = (index) => {
    setExpandedSteps((prev) => ({ ...prev, [index]: !prev[index] }))
  }

  const title =
    pipelineType === 'code-to-code'
      ? 'Code-to-Code Workflow'
      : 'Spec Driven Workflow'

  if (!jobId) {
    return (
      <div className="flex flex-col items-center justify-center py-20">
        <p className="text-text-secondary mb-4">No active workflow found</p>
        <button
          onClick={() => navigate('/dashboard')}
          className="text-sm text-brand-400 hover:text-brand-300 transition-colors cursor-pointer"
        >
          Go to Dashboard
        </button>
      </div>
    )
  }

  return (
    <div className="max-w-4xl mx-auto">
      {/* Back button */}
      <button
        onClick={() => navigate('/dashboard')}
        className="flex items-center gap-1.5 text-sm text-text-muted hover:text-text-primary transition-colors mb-6 cursor-pointer"
      >
        <ArrowLeft className="w-4 h-4" />
        Back to Dashboard
      </button>

      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center mb-8"
      >
        <h1 className="text-2xl font-bold text-text-primary mb-1">
          {title}
        </h1>
        <p className="text-sm text-text-muted">
          {/* Job ID: {jobId} */}
          {isAutopilot && (
            <span className="ml-2 inline-flex items-center px-2 py-0.5 text-[10px] font-medium bg-brand-600/20 text-brand-400 rounded-full">
              Autopilot
            </span>
          )}
        </p>
      </motion.div>

      {/* Stepper */}
      <Stepper steps={steps} currentStep={currentStep} />

      {/* Autopilot complete: show all steps as collapsible panels */}
      {isAutopilot && isComplete ? (
        <div className="space-y-3">
          {steps.map((step, index) => (
            <div
              key={index}
              className="border border-surface-border rounded-xl overflow-hidden"
            >
              <button
                onClick={() => toggleStep(index)}
                className="w-full flex items-center gap-3 px-5 py-3.5 bg-surface-card hover:bg-surface-hover transition-colors cursor-pointer"
              >
                <span className="w-6 h-6 bg-success/20 text-success rounded-full flex items-center justify-center text-xs font-bold">
                  {index + 1}
                </span>
                <span className="text-sm font-medium text-text-primary flex-1 text-left">
                  {step.name}
                </span>
                {expandedSteps[index] ? (
                  <ChevronDown className="w-4 h-4 text-text-muted" />
                ) : (
                  <ChevronRight className="w-4 h-4 text-text-muted" />
                )}
              </button>
              {expandedSteps[index] && (
                <div className="p-4 border-t border-surface-border">
                  <StepPanel
                    step={step}
                    stepIndex={index}
                    onApprove={approveStep}
                    onEditOutput={editStepOutput}
                    onReprompt={repromptStep}
                    readOnly
                  />
                </div>
              )}
            </div>
          ))}
        </div>
      ) : isAutopilot ? (
        /* Autopilot in-progress: show current running step */
        <StepPanel
          step={steps[currentStep]}
          stepIndex={currentStep}
          onApprove={approveStep}
          onEditOutput={editStepOutput}
          onReprompt={repromptStep}
          readOnly
        />
      ) : (
        /* Human intervention: show active step panel */
        <StepPanel
          step={steps[currentStep]}
          stepIndex={currentStep}
          onApprove={approveStep}
          onEditOutput={editStepOutput}
          onReprompt={repromptStep}
        />
      )}

      {/* Download panel when complete */}
      {isComplete && <DownloadPanel jobId={jobId} />}
    </div>
  )
}

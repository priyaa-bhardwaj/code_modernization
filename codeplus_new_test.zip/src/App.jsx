import { BrowserRouter, Routes, Route, Navigate, Outlet } from 'react-router-dom'
import { Toaster } from 'react-hot-toast'
import useAuthStore from './stores/authStore'
import useThemeStore from './stores/themeStore'
import AuthLayout from './layouts/AuthLayout'
import AppLayout from './layouts/AppLayout'
import LoginPage from './pages/LoginPage'
import SignupPage from './pages/SignupPage'
import DashboardPage from './pages/DashboardPage'
import WorkspacePage from './pages/WorkspacePage'
import WorkflowPage from './pages/WorkflowPage'

function ProtectedRoute() {
  const { token } = useAuthStore()
  if (!token) return <Navigate to="/login" replace />
  return <Outlet />
}

function PublicRoute() {
  const { token } = useAuthStore()
  if (token) return <Navigate to="/dashboard" replace />
  return <Outlet />
}

export default function App() {
  const { theme } = useThemeStore()
  const isDark = theme === 'dark'

  return (
    <BrowserRouter>
      <Toaster
        position="top-right"
        toastOptions={{
          style: {
            background: isDark ? '#1a1d2e' : '#ffffff',
            color: isDark ? '#f1f5f9' : '#111827',
            border: `1px solid ${isDark ? '#2e3348' : '#e2e5ef'}`,
            fontSize: '14px',
          },
          success: {
            iconTheme: { primary: '#22c55e', secondary: isDark ? '#1a1d2e' : '#ffffff' },
          },
          error: {
            iconTheme: { primary: '#ef4444', secondary: isDark ? '#1a1d2e' : '#ffffff' },
          },
        }}
      />

      <Routes>
        {/* Public auth routes */}
        <Route element={<PublicRoute />}>
          <Route element={<AuthLayout />}>
            <Route path="/login" element={<LoginPage />} />
            <Route path="/signup" element={<SignupPage />} />
          </Route>
        </Route>

        {/* Protected app routes */}
        <Route element={<ProtectedRoute />}>
          <Route element={<AppLayout />}>
            <Route path="/dashboard" element={<DashboardPage />} />
            <Route path="/workspace/:id" element={<WorkspacePage />} />
            <Route path="/workflow/:id" element={<WorkflowPage />} />
          </Route>
        </Route>

        {/* Default redirect */}
        <Route path="*" element={<Navigate to="/dashboard" replace />} />
      </Routes>
    </BrowserRouter>
  )
}

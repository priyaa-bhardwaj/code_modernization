export const models = [
  {
    id: 'claude-opus-4',
    name: 'Claude Opus 4',
    provider: 'Anthropic',
    // description: 'Most capable model for complex modernization tasks',
  },
  {
    id: 'claude-sonnet-4',
    name: 'Claude Sonnet 4',
    provider: 'Anthropic',
    // description: 'Balanced performance and speed',
  },
  {
    id: 'gpt-4o',
    name: 'GPT-4o',
    provider: 'OpenAI',
    // description: 'Multimodal model with strong code understanding',
  },
  // {
  //   id: 'gpt-4-turbo',
  //   name: 'GPT-4 Turbo',
  //   provider: 'OpenAI',
  //   // description: 'Fast, capable model for code generation',
  // },
  {
    id: 'gemini-pro',
    name: 'Gemini Pro',
    provider: 'Google',
    // description: 'Large context window for big codebases',
  },
]

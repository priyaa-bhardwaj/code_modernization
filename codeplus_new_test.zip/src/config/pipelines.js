export const PIPELINE_TYPES = {
  SPEC_TO_CODE: 'spec-to-code',
  CODE_TO_CODE: 'code-to-code',
}

export const PIPELINES = {
  [PIPELINE_TYPES.SPEC_TO_CODE]: {
    id: 'spec-to-code',
    label: 'Spec-to-Code',
    description: 'Generate specification first, then modernize from spec',
    steps: ['Spec Creation', 'Modernization', 'Reflection'],
    stepDescriptions: [
      'Analyzing source code and generating specification document...',
      'Transforming specification into modernized code...',
      'Reviewing and validating the generated code...',
    ],
    promptKeys: ['spec', 'modernize', 'reflect'],
    promptLabels: ['Spec Creation', 'Modernization', 'Reflection'],
    defaultPrompts: {
      spec: 'Analyze the provided source code and generate a detailed specification document that captures all business logic, data structures, workflows, and integrations.',
      modernize:
        'Using the specification document, generate modernized code in the target language following best practices, design patterns, and production-ready standards.',
      reflect:
        'Review the generated modern code against the original specification. Identify any gaps, inconsistencies, or improvements needed. Suggest corrections.',
    },
  },
  [PIPELINE_TYPES.CODE_TO_CODE]: {
    id: 'code-to-code',
    label: 'Code-to-Code',
    description: 'Analyze source code directly, then modernize',
    steps: ['Analysis', 'Modernization', 'Reflection'],
    stepDescriptions: [
      'Performing deep analysis of source code structure and patterns...',
      'Directly transforming analyzed code into modernized target language...',
      'Reviewing and validating the generated code...',
    ],
    promptKeys: ['analysis', 'modernize', 'reflect'],
    promptLabels: ['Analysis', 'Modernization', 'Reflection'],
    defaultPrompts: {
      analysis:
        'Analyze the provided source code to understand its structure, patterns, dependencies, and control flow. Identify key components and their relationships.',
      modernize:
        'Using the analysis, directly transform the source code into the target language following best practices, design patterns, and production-ready standards.',
      reflect:
        'Review the generated modern code against the original source. Identify any gaps, inconsistencies, or improvements needed. Suggest corrections.',
    },
  },
}

export const getPipeline = (type) =>
  PIPELINES[type] || PIPELINES[PIPELINE_TYPES.SPEC_TO_CODE]

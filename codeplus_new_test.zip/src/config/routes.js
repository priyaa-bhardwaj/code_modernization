export const ROUTES = {
  LOGIN: '/login',
  SIGNUP: '/signup',
  DASHBOARD: '/dashboard',
  WORKSPACE: '/workspace/:id',
  WORKFLOW: '/workflow/:id',
}

export const buildWorkspacePath = (id) => `/workspace/${id}`
export const buildWorkflowPath = (id) => `/workflow/${id}`

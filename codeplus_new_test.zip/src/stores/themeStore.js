import { create } from 'zustand'

const useThemeStore = create((set) => ({
  theme: localStorage.getItem('codeplus_theme') || 'dark',

  toggleTheme: () =>
    set((state) => {
      const next = state.theme === 'dark' ? 'light' : 'dark'
      localStorage.setItem('codeplus_theme', next)
      document.documentElement.classList.toggle('light', next === 'light')
      return { theme: next }
    }),

  hydrate: () => {
    const saved = localStorage.getItem('codeplus_theme') || 'dark'
    document.documentElement.classList.toggle('light', saved === 'light')
    return saved
  },
}))

export default useThemeStore

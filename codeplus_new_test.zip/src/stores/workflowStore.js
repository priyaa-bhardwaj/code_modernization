import { create } from 'zustand'
import { getPipeline } from '../config/pipelines'

const createInitialSteps = (pipelineType = 'spec-to-code') => {
  const pipeline = getPipeline(pipelineType)
  return pipeline.steps.map((name) => ({
    name,
    status: 'pending',
    output: null,
    error: null,
  }))
}

// --- Mock outputs (shared between both pipelines) ---

const mockSpecOutput = `# Specification Document\n\n## Overview\nThis specification describes the complete business logic, data structures,\nand workflows extracted from the source codebase.\n\n## Business Rules\n1. User authentication via session-based tokens\n2. Order processing pipeline with validation stages\n3. Inventory management with real-time stock tracking\n\n## Data Models\n\`\`\`\nUser {\n  id: UUID\n  email: String\n  role: Enum[ADMIN, USER, VIEWER]\n  created_at: DateTime\n}\n\nOrder {\n  id: UUID\n  user_id: FK(User)\n  items: List[OrderItem]\n  status: Enum[PENDING, PROCESSING, COMPLETED, CANCELLED]\n  total: Decimal\n}\n\`\`\`\n\n## API Endpoints\n- POST /api/auth/login\n- GET /api/orders\n- POST /api/orders\n- PUT /api/orders/:id/status\n\n## Integration Points\n- Payment gateway (Stripe)\n- Email service (SendGrid)\n- Logging (ELK Stack)`

const mockAnalysisOutput = `# Code Analysis Report\n\n## Overview\nDeep analysis of the source codebase structure, patterns, dependencies, and control flow.\n\n## Architecture\n- **Pattern**: Monolithic with procedural modules\n- **Entry Point**: Main module with event-driven dispatcher\n- **Data Layer**: Direct database calls via embedded SQL\n\n## Component Inventory\n| Component | Type | Lines | Complexity |\n|-----------|------|-------|------------|\n| AuthModule | Authentication | 340 | Medium |\n| OrderProcessor | Business Logic | 820 | High |\n| InventoryManager | Data Access | 510 | Medium |\n| ReportEngine | Output | 290 | Low |\n\n## Dependencies\n- External DB connector (proprietary)\n- File system I/O for batch processing\n- Socket-based IPC for service communication\n\n## Key Patterns Identified\n1. Transaction scripts with inline validation\n2. Shared global state via common blocks\n3. Error handling through return codes (no exceptions)\n4. String-based message passing between modules\n\n## Migration Considerations\n- Global state must be refactored into scoped services\n- Return-code error handling → exception-based patterns\n- Embedded SQL → ORM or repository pattern\n- Batch file processing → streaming/async approach`

const mockModernizationFiles = {
  'src/main/java/com/codeplus/Application.java': `package com.codeplus.modernized;\n\nimport org.springframework.boot.SpringApplication;\nimport org.springframework.boot.autoconfigure.SpringBootApplication;\n\n@SpringBootApplication\npublic class Application {\n\n    public static void main(String[] args) {\n        SpringApplication.run(Application.class, args);\n    }\n}`,
  'src/main/java/com/codeplus/controller/AuthController.java': `package com.codeplus.controller;\n\nimport org.springframework.beans.factory.annotation.Autowired;\nimport org.springframework.http.ResponseEntity;\nimport org.springframework.web.bind.annotation.*;\nimport javax.validation.Valid;\n\n@RestController\n@RequestMapping("/api/auth")\npublic class AuthController {\n\n    @Autowired\n    private AuthService authService;\n\n    @PostMapping("/login")\n    public ResponseEntity<AuthResponse> login(\n            @RequestBody @Valid LoginRequest request) {\n        return ResponseEntity.ok(authService.authenticate(request));\n    }\n\n    @PostMapping("/register")\n    public ResponseEntity<AuthResponse> register(\n            @RequestBody @Valid RegisterRequest request) {\n        return ResponseEntity.ok(authService.register(request));\n    }\n}`,
  'src/main/java/com/codeplus/controller/OrderController.java': `package com.codeplus.controller;\n\nimport org.springframework.beans.factory.annotation.Autowired;\nimport org.springframework.http.ResponseEntity;\nimport org.springframework.web.bind.annotation.*;\nimport java.util.List;\n\n@RestController\n@RequestMapping("/api/orders")\npublic class OrderController {\n\n    @Autowired\n    private OrderService orderService;\n\n    @GetMapping\n    public ResponseEntity<List<Order>> getOrders() {\n        return ResponseEntity.ok(orderService.findAll());\n    }\n\n    @PostMapping\n    public ResponseEntity<Order> createOrder(\n            @RequestBody @Valid CreateOrderRequest request) {\n        return ResponseEntity.ok(orderService.createOrder(request));\n    }\n\n    @PutMapping("/{id}/status")\n    public ResponseEntity<Order> updateStatus(\n            @PathVariable Long id,\n            @RequestBody UpdateStatusRequest request) {\n        return ResponseEntity.ok(orderService.updateStatus(id, request));\n    }\n}`,
  'src/main/java/com/codeplus/service/OrderService.java': `package com.codeplus.service;\n\nimport org.springframework.beans.factory.annotation.Autowired;\nimport org.springframework.stereotype.Service;\nimport org.springframework.transaction.annotation.Transactional;\n\n@Service\n@Transactional\npublic class OrderService {\n\n    @Autowired\n    private OrderRepository orderRepository;\n\n    public Order createOrder(CreateOrderRequest request) {\n        Order order = Order.builder()\n            .userId(request.getUserId())\n            .items(request.getItems())\n            .status(OrderStatus.PENDING)\n            .total(calculateTotal(request.getItems()))\n            .build();\n        return orderRepository.save(order);\n    }\n\n    public List<Order> findAll() {\n        return orderRepository.findAll();\n    }\n\n    public Order updateStatus(Long id, UpdateStatusRequest request) {\n        Order order = orderRepository.findById(id)\n            .orElseThrow(() -> new NotFoundException("Order not found"));\n        order.setStatus(request.getStatus());\n        return orderRepository.save(order);\n    }\n\n    private BigDecimal calculateTotal(List<OrderItem> items) {\n        return items.stream()\n            .map(i -> i.getPrice().multiply(BigDecimal.valueOf(i.getQuantity())))\n            .reduce(BigDecimal.ZERO, BigDecimal::add);\n    }\n}`,
  'src/main/java/com/codeplus/model/Order.java': `package com.codeplus.model;\n\nimport lombok.*;\nimport javax.persistence.*;\nimport java.math.BigDecimal;\nimport java.time.LocalDateTime;\nimport java.util.List;\n\n@Entity\n@Table(name = "orders")\n@Data\n@Builder\n@NoArgsConstructor\n@AllArgsConstructor\npublic class Order {\n\n    @Id\n    @GeneratedValue(strategy = GenerationType.IDENTITY)\n    private Long id;\n\n    @Column(nullable = false)\n    private Long userId;\n\n    @OneToMany(cascade = CascadeType.ALL, mappedBy = "order")\n    private List<OrderItem> items;\n\n    @Enumerated(EnumType.STRING)\n    private OrderStatus status;\n\n    @Column(precision = 10, scale = 2)\n    private BigDecimal total;\n\n    private LocalDateTime createdAt;\n    private LocalDateTime updatedAt;\n}`,
  'src/main/resources/application.yml': `server:\n  port: 8080\n\nspring:\n  application:\n    name: codeplus-modernized\n  datasource:\n    url: jdbc:postgresql://localhost:5432/codeplus\n    username: \${DB_USERNAME}\n    password: \${DB_PASSWORD}\n  jpa:\n    hibernate:\n      ddl-auto: validate\n    show-sql: false\n\nlogging:\n  level:\n    root: INFO\n    com.codeplus: DEBUG`,
  'pom.xml': `<?xml version="1.0" encoding="UTF-8"?>\n<project xmlns="http://maven.apache.org/POM/4.0.0"\n         xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"\n         xsi:schemaLocation="http://maven.apache.org/POM/4.0.0\n         https://maven.apache.org/xsd/maven-4.0.0.xsd">\n    <modelVersion>4.0.0</modelVersion>\n\n    <parent>\n        <groupId>org.springframework.boot</groupId>\n        <artifactId>spring-boot-starter-parent</artifactId>\n        <version>3.2.0</version>\n    </parent>\n\n    <groupId>com.codeplus</groupId>\n    <artifactId>modernized</artifactId>\n    <version>1.0.0</version>\n\n    <dependencies>\n        <dependency>\n            <groupId>org.springframework.boot</groupId>\n            <artifactId>spring-boot-starter-web</artifactId>\n        </dependency>\n        <dependency>\n            <groupId>org.springframework.boot</groupId>\n            <artifactId>spring-boot-starter-data-jpa</artifactId>\n        </dependency>\n        <dependency>\n            <groupId>org.projectlombok</groupId>\n            <artifactId>lombok</artifactId>\n            <scope>provided</scope>\n        </dependency>\n    </dependencies>\n</project>`,
}

const mockReflection = `# Reflection Report\n\n## Coverage Analysis\n✅ All 4 API endpoints implemented\n✅ All data models translated correctly\n✅ Authentication flow preserved\n✅ Order processing pipeline complete\n\n## Code Quality Assessment\n- **Architecture**: Clean layered architecture (Controller → Service → Repository)\n- **Validation**: Input validation via @Valid annotations\n- **Error Handling**: Global exception handler recommended\n- **Testing**: Unit tests should be added for OrderService\n\n## Identified Gaps\n1. ⚠️ Payment gateway integration (Stripe) - needs API key configuration\n2. ⚠️ Email service - SendGrid template setup required\n3. ℹ️ Logging configuration matches ELK Stack requirements\n\n## Recommendations\n1. Add integration tests for payment flow\n2. Configure Spring Security for role-based access\n3. Add Swagger/OpenAPI documentation\n4. Set up CI/CD pipeline for deployment\n\n## Confidence Score: 94%\nThe modernized code faithfully represents the original business logic\nwith improvements in type safety, error handling, and maintainability.`

const MOCK_OUTPUTS = [null, mockModernizationFiles, mockReflection]

const getStep0Output = (pipelineType) =>
  pipelineType === 'code-to-code' ? mockAnalysisOutput : mockSpecOutput

// --- Store ---

const useWorkflowStore = create((set, get) => ({
  jobId: null,
  currentStep: 0,
  steps: createInitialSteps(),
  isGenerating: false,
  isComplete: false,
  executionMode: null,
  pipelineType: null,

  startGeneration: async (jobId, executionMode = 'human', pipelineType = 'spec-to-code') => {
    const steps = createInitialSteps(pipelineType)
    steps[0].status = 'running'
    set({
      jobId,
      currentStep: 0,
      steps,
      isGenerating: true,
      isComplete: false,
      executionMode,
      pipelineType,
    })

    // Simulate step 0
    await new Promise((r) => setTimeout(r, 3000))
    const step0Output = getStep0Output(pipelineType)

    set((state) => {
      const steps = [...state.steps]
      steps[0] = { ...steps[0], status: 'complete', output: step0Output }
      return { steps, isGenerating: false }
    })

    // Autopilot: chain remaining steps automatically
    if (executionMode === 'autopilot') {
      for (let i = 1; i < 3; i++) {
        // Start next step
        set((state) => {
          const steps = [...state.steps]
          steps[i] = { ...steps[i], status: 'running' }
          return { currentStep: i, steps, isGenerating: true }
        })

        await new Promise((r) => setTimeout(r, 3000))

        const output = i === 1 ? mockModernizationFiles : mockReflection
        set((state) => {
          const steps = [...state.steps]
          steps[i] = { ...steps[i], status: 'complete', output }
          return { steps, isGenerating: false }
        })
      }

      // All done
      set({ isComplete: true })
    }
  },

  approveStep: async (stepIndex) => {
    if (stepIndex >= 2) {
      set({ isComplete: true })
      return
    }

    const nextIndex = stepIndex + 1
    set((state) => {
      const steps = [...state.steps]
      steps[nextIndex] = { ...steps[nextIndex], status: 'running' }
      return { currentStep: nextIndex, steps, isGenerating: true }
    })

    await new Promise((r) => setTimeout(r, 3000))

    set((state) => {
      const steps = [...state.steps]
      steps[nextIndex] = {
        ...steps[nextIndex],
        status: 'complete',
        output: MOCK_OUTPUTS[nextIndex],
      }
      return { steps, isGenerating: false }
    })
  },

  editStepOutput: (stepIndex, newOutput) => {
    set((state) => {
      const steps = [...state.steps]
      steps[stepIndex] = { ...steps[stepIndex], output: newOutput }
      return { steps }
    })
  },

  editFileInStep: (stepIndex, filePath, newContent) => {
    set((state) => {
      const steps = [...state.steps]
      const output = { ...steps[stepIndex].output, [filePath]: newContent }
      steps[stepIndex] = { ...steps[stepIndex], output }
      return { steps }
    })
  },

  repromptStep: async (stepIndex, newPrompt) => {
    set((state) => {
      const steps = [...state.steps]
      steps[stepIndex] = { ...steps[stepIndex], status: 'running', output: null }
      return { steps, isGenerating: true }
    })

    await new Promise((r) => setTimeout(r, 3000))

    let regeneratedOutput
    if (stepIndex === 1) {
      regeneratedOutput = {
        'src/main/java/com/codeplus/Application.java': `package com.codeplus.modernized;\n\n// Regenerated based on: "${newPrompt}"\n\nimport org.springframework.boot.SpringApplication;\nimport org.springframework.boot.autoconfigure.SpringBootApplication;\n\n@SpringBootApplication\npublic class Application {\n    public static void main(String[] args) {\n        SpringApplication.run(Application.class, args);\n    }\n}`,
        'src/main/java/com/codeplus/controller/AuthController.java': `package com.codeplus.controller;\n\n// Updated based on re-prompt instructions\n\n@RestController\n@RequestMapping("/api/auth")\npublic class AuthController {\n\n    @Autowired\n    private AuthService authService;\n\n    @PostMapping("/login")\n    public ResponseEntity<AuthResponse> login(\n            @RequestBody @Valid LoginRequest request) {\n        return ResponseEntity.ok(authService.authenticate(request));\n    }\n}`,
        'src/main/resources/application.yml': `server:\n  port: 8080\n\nspring:\n  application:\n    name: codeplus-regenerated`,
        'pom.xml': `<?xml version="1.0" encoding="UTF-8"?>\n<project>\n    <modelVersion>4.0.0</modelVersion>\n    <groupId>com.codeplus</groupId>\n    <artifactId>modernized</artifactId>\n    <version>1.0.0</version>\n</project>`,
      }
    } else {
      regeneratedOutput = `# Regenerated Output (Step ${stepIndex + 1})\n\nRegenerated based on updated prompt:\n"${newPrompt}"\n\nThis content has been regenerated with the updated instructions.\nAll previous concerns have been addressed in this new version.\n\n## Updated Sections\n- Improved data model definitions\n- Enhanced API endpoint specifications\n- Updated integration requirements\n- Refined business logic rules`
    }

    set((state) => {
      const steps = [...state.steps]
      steps[stepIndex] = {
        ...steps[stepIndex],
        status: 'complete',
        output: regeneratedOutput,
      }
      return { steps, isGenerating: false }
    })
  },

  reset: () =>
    set({
      jobId: null,
      currentStep: 0,
      steps: createInitialSteps(),
      isGenerating: false,
      isComplete: false,
      executionMode: null,
      pipelineType: null,
    }),
}))

export default useWorkflowStore

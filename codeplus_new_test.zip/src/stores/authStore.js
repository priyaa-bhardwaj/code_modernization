import { create } from 'zustand'
import { authService } from '../services/authService'

const useAuthStore = create((set) => ({
  user: JSON.parse(localStorage.getItem('codeplus_user') || 'null'),
  token: localStorage.getItem('codeplus_token') || null,
  isLoading: false,
  error: null,

  login: async (email, password) => {
    set({ isLoading: true, error: null })
    try {
      const data = await authService.login(email, password)
      localStorage.setItem('codeplus_token', data.token)
      localStorage.setItem('codeplus_user', JSON.stringify(data.user))
      set({ user: data.user, token: data.token, isLoading: false })
      return data
    } catch (err) {
      set({ error: err.message, isLoading: false })
      throw err
    }
  },

  signup: async (name, email, password) => {
    set({ isLoading: true, error: null })
    try {
      const data = await authService.signup(name, email, password)
      localStorage.setItem('codeplus_token', data.token)
      localStorage.setItem('codeplus_user', JSON.stringify(data.user))
      set({ user: data.user, token: data.token, isLoading: false })
      return data
    } catch (err) {
      set({ error: err.message, isLoading: false })
      throw err
    }
  },

  logout: () => {
    localStorage.removeItem('codeplus_token')
    localStorage.removeItem('codeplus_user')
    set({ user: null, token: null, error: null })
  },

  clearError: () => set({ error: null }),
}))

export default useAuthStore

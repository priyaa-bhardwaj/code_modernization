import { create } from 'zustand'
import { getPipeline } from '../config/pipelines'

const defaultPipeline = getPipeline('spec-to-code')

const useTranslationStore = create((set) => ({
  selectedTranslation: null,
  uploadedFile: null,
  selectedModel: 'claude-sonnet-4',
  pipelineType: 'spec-to-code',
  executionMode: 'human',
  contextFiles: [],
  prompts: { ...defaultPipeline.defaultPrompts },

  setTranslation: (translation) => set({ selectedTranslation: translation }),
  setFile: (file) => set({ uploadedFile: file }),
  setModel: (model) => set({ selectedModel: model }),

  setPipelineType: (type) => {
    const pipeline = getPipeline(type)
    set({ pipelineType: type, prompts: { ...pipeline.defaultPrompts } })
  },

  setExecutionMode: (mode) => set({ executionMode: mode }),

  addContextFiles: (files) =>
    set((state) => ({
      contextFiles: [...state.contextFiles, ...Array.from(files)],
    })),
  removeContextFile: (index) =>
    set((state) => ({
      contextFiles: state.contextFiles.filter((_, i) => i !== index),
    })),
  clearContextFiles: () => set({ contextFiles: [] }),

  updatePrompt: (step, text) =>
    set((state) => ({
      prompts: { ...state.prompts, [step]: text },
    })),

  reset: () =>
    set({
      selectedTranslation: null,
      uploadedFile: null,
      selectedModel: 'claude-sonnet-4',
      pipelineType: 'spec-to-code',
      executionMode: 'human',
      contextFiles: [],
      prompts: { ...defaultPipeline.defaultPrompts },
    }),
}))

export default useTranslationStore

import clsx from 'clsx'

const colorMap = {
  brand: 'bg-brand-500/15 text-brand-400 border-brand-500/20',
  success: 'bg-success/15 text-success border-success/20',
  warning: 'bg-warning/15 text-warning border-warning/20',
  error: 'bg-error/15 text-error border-error/20',
  neutral: 'bg-surface-hover text-text-secondary border-surface-border',
}

export default function Badge({
  children,
  color = 'brand',
  className,
  style,
}) {
  return (
    <span
      className={clsx(
        'inline-flex items-center px-2.5 py-0.5 text-xs font-medium rounded-full border',
        colorMap[color] || colorMap.neutral,
        className,
      )}
      style={style}
    >
      {children}
    </span>
  )
}

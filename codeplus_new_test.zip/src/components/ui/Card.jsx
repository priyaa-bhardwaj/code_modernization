import clsx from 'clsx'

export default function Card({ children, hover = false, className, ...props }) {
  return (
    <div
      className={clsx(
        'bg-surface-card border border-surface-border rounded-xl p-6',
        hover &&
          'cursor-pointer ring-1 ring-brand-500/0 hover:ring-brand-500/30 hover:border-brand-500/30 hover:-translate-y-0.5 transition-all duration-300',
        className,
      )}
      {...props}
    >
      {children}
    </div>
  )
}

import { forwardRef } from 'react'
import clsx from 'clsx'

const Input = forwardRef(
  ({ label, error, icon: Icon, className, ...props }, ref) => {
    return (
      <div className="w-full">
        {label && (
          <label className="block text-sm font-medium text-text-secondary mb-1.5">
            {label}
          </label>
        )}
        <div className="relative">
          {Icon && (
            <div className="absolute left-3 top-1/2 -translate-y-1/2 text-text-muted">
              <Icon className="w-4 h-4" />
            </div>
          )}
          <input
            ref={ref}
            className={clsx(
              'w-full bg-surface-input border border-surface-border rounded-lg px-4 py-2.5 text-sm text-text-primary',
              'placeholder:text-text-muted',
              'focus:outline-none focus:ring-2 focus:ring-brand-500/50 focus:border-brand-500',
              'transition-all duration-200',
              Icon && 'pl-10',
              error && 'border-error focus:ring-error/50 focus:border-error',
              className,
            )}
            {...props}
          />
        </div>
        {error && <p className="mt-1 text-xs text-error">{error}</p>}
      </div>
    )
  },
)

Input.displayName = 'Input'
export default Input

import { translations } from '../../config/translations'
import TranslationCard from './TranslationCard'

export default function TranslationGrid() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
      {translations.map((t, i) => (
        <TranslationCard key={t.id} translation={t} index={i} />
      ))}
    </div>
  )
}

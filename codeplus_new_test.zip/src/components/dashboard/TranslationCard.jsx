import { useNavigate } from 'react-router-dom'
import { ArrowRight } from 'lucide-react'
import { motion } from 'framer-motion'
import { buildWorkspacePath } from '../../config/routes'

export default function TranslationCard({ translation, index }) {
  const navigate = useNavigate()
  const { id, from, to, fromColor, toColor, description } = translation

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, delay: index * 0.05 }}
      onClick={() => navigate(buildWorkspacePath(id))}
      className="group bg-surface-card border border-surface-border rounded-xl p-6 cursor-pointer
        ring-1 ring-brand-500/0 hover:ring-brand-500/30 hover:border-brand-500/30
        hover:-translate-y-1 transition-all duration-300 hover:shadow-lg hover:shadow-brand-500/5"
    >
      {/* Language badges */}
      <div className="flex items-center gap-3 mb-4">
        <span
          className="inline-flex items-center px-3 py-1 text-xs font-semibold rounded-lg border"
          style={{
            backgroundColor: fromColor + '15',
            color: fromColor,
            borderColor: fromColor + '30',
          }}
        >
          {from}
        </span>

        <ArrowRight className="w-4 h-4 text-text-muted group-hover:text-brand-400 group-hover:translate-x-0.5 transition-all duration-300" />

        <span
          className="inline-flex items-center px-3 py-1 text-xs font-semibold rounded-lg border"
          style={{
            backgroundColor: toColor + '15',
            color: toColor,
            borderColor: toColor + '30',
          }}
        >
          {to}
        </span>
      </div>

      {/* Description */}
      <p className="text-sm text-text-secondary leading-relaxed">
        {description}
      </p>

      {/* Bottom action hint */}
      <div className="mt-4 flex items-center gap-1.5 text-xs font-medium text-text-muted group-hover:text-brand-400 transition-colors">
        Start modernization
        <ArrowRight className="w-3 h-3 group-hover:translate-x-0.5 transition-transform" />
      </div>
    </motion.div>
  )
}

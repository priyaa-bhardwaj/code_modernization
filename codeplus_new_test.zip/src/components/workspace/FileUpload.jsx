import { useState, useRef } from 'react'
import { Upload, File, X, CheckCircle2 } from 'lucide-react'
import clsx from 'clsx'
import useTranslationStore from '../../stores/translationStore'

export default function FileUpload() {
  const { uploadedFile, setFile } = useTranslationStore()
  const [isDragging, setIsDragging] = useState(false)
  const fileInputRef = useRef(null)

  const handleDragOver = (e) => {
    e.preventDefault()
    setIsDragging(true)
  }

  const handleDragLeave = (e) => {
    e.preventDefault()
    setIsDragging(false)
  }

  const handleDrop = (e) => {
    e.preventDefault()
    setIsDragging(false)
    const file = e.dataTransfer.files[0]
    if (file && (file.name.endsWith('.zip') || file.name.endsWith('.tar.gz'))) {
      setFile(file)
    }
  }

  const handleFileSelect = (e) => {
    const file = e.target.files[0]
    if (file) setFile(file)
  }

  const formatSize = (bytes) => {
    if (bytes < 1024) return bytes + ' B'
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB'
    return (bytes / (1024 * 1024)).toFixed(1) + ' MB'
  }

  if (uploadedFile) {
    return (
      <div className="bg-surface-card border border-surface-border rounded-xl p-5">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-success/10 rounded-lg flex items-center justify-center">
              <CheckCircle2 className="w-5 h-5 text-success" />
            </div>
            <div>
              <p className="text-sm font-medium text-text-primary">
                {uploadedFile.name}
              </p>
              <p className="text-xs text-text-muted">
                {formatSize(uploadedFile.size)}
              </p>
            </div>
          </div>
          <button
            onClick={() => setFile(null)}
            className="p-1.5 rounded-lg hover:bg-surface-hover text-text-muted hover:text-error transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>
    )
  }

  return (
    <div
      onDragOver={handleDragOver}
      onDragLeave={handleDragLeave}
      onDrop={handleDrop}
      onClick={() => fileInputRef.current?.click()}
      className={clsx(
        'border-2 border-dashed rounded-xl p-8 text-center cursor-pointer transition-all duration-200',
        isDragging
          ? 'border-brand-500 bg-brand-500/5'
          : 'border-surface-border hover:border-brand-500/50 hover:bg-surface-card',
      )}
    >
      <input
        ref={fileInputRef}
        type="file"
        accept=".zip,.tar.gz"
        className="hidden"
        onChange={handleFileSelect}
      />
      <Upload className="w-8 h-8 text-text-muted mx-auto mb-3" />
      <p className="text-sm font-medium text-text-primary mb-1">
        Drag & drop your project folder
      </p>
      <p className="text-xs text-text-muted">
        Supports .zip and .tar.gz files
      </p>
    </div>
  )
}

import { FileSearch, ArrowRightLeft } from 'lucide-react'
import { PIPELINES } from '../../config/pipelines'
import useTranslationStore from '../../stores/translationStore'

const options = [
  {
    type: 'spec-to-code',
    icon: FileSearch,
    flow: 'Spec Creation → Modernization → Reflection',
  },
  {
    type: 'code-to-code',
    icon: ArrowRightLeft,
    flow: 'Analysis → Modernization → Reflection',
  },
]

export default function PipelineSelector() {
  const { pipelineType, setPipelineType } = useTranslationStore()

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
      {options.map(({ type, icon: Icon, flow }) => {
        const pipeline = PIPELINES[type]
        const selected = pipelineType === type

        return (
          <button
            key={type}
            onClick={() => setPipelineType(type)}
            className={`text-left p-5 rounded-xl border transition-all duration-200 cursor-pointer ${
              selected
                ? 'border-brand-100 bg-brand-100/10 ring-1 ring-brand-100/30'
                : 'border-surface-border bg-surface-card hover:border-surface-hover hover:bg-surface-hover'
            }`}
          >
            <div className="flex items-center gap-3 mb-2">
              <div
                className={`w-9 h-9 rounded-lg flex items-center justify-center ${
                  selected
                    ? 'bg-brand-600/20 text-brand-400'
                    : 'bg-surface-hover text-text-muted'
                }`}
              >
                <Icon className="w-4.5 h-4.5" />
              </div>
              <span className="text-sm font-semibold text-text-primary">
                {pipeline.label}
              </span>
            </div>
            <p className="text-xs text-text-muted leading-relaxed mb-2">
              {pipeline.description}
            </p>
            <div className="text-[11px] font-mono text-text-muted bg-surface-hover/60 px-2.5 py-1.5 rounded-lg">
              {flow}
            </div>
          </button>
        )
      })}
    </div>
  )
}

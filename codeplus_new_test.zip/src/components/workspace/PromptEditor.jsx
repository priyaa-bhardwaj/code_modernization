import { useMemo, useState } from 'react'
import { ChevronDown, ChevronRight, FileText } from 'lucide-react'
import { motion, AnimatePresence } from 'framer-motion'
import { getPipeline } from '../../config/pipelines'
import useTranslationStore from '../../stores/translationStore'

export default function PromptEditor() {
  const [openStep, setOpenStep] = useState(null)
  const { pipelineType, prompts, updatePrompt } = useTranslationStore()

  const steps = useMemo(() => {
    const pipeline = getPipeline(pipelineType)
    return pipeline.promptKeys.map((key, i) => ({
      key,
      label: pipeline.promptLabels[i],
      icon: String(i + 1),
    }))
  }, [pipelineType])

  const toggle = (key) => setOpenStep(openStep === key ? null : key)

  return (
    <div>
      <div className="flex items-center gap-2 mb-3">
        <FileText className="w-4 h-4 text-text-muted" />
        <label className="text-sm font-medium text-text-secondary">
          Prompts (View / Edit)
        </label>
      </div>

      <div className="space-y-2">
        {steps.map((step) => (
          <div
            key={step.key}
            className="border border-surface-border rounded-xl overflow-hidden"
          >
            <button
              onClick={() => toggle(step.key)}
              className="w-full flex items-center gap-3 px-4 py-3 bg-surface-card hover:bg-surface-hover transition-colors cursor-pointer"
            >
              <span className="w-6 h-6 bg-brand-600/20 text-brand-400 rounded-full flex items-center justify-center text-xs font-bold">
                {step.icon}
              </span>
              <span className="text-sm font-medium text-text-primary flex-1 text-left">
                {step.label}
              </span>
              {openStep === step.key ? (
                <ChevronDown className="w-4 h-4 text-text-muted" />
              ) : (
                <ChevronRight className="w-4 h-4 text-text-muted" />
              )}
            </button>

            <AnimatePresence>
              {openStep === step.key && (
                <motion.div
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: 'auto', opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  transition={{ duration: 0.2 }}
                  className="overflow-hidden"
                >
                  <div className="px-4 pb-4">
                    <textarea
                      value={prompts[step.key] || ''}
                      onChange={(e) => updatePrompt(step.key, e.target.value)}
                      rows={4}
                      className="w-full bg-surface-input border border-surface-border rounded-lg px-4 py-3 text-sm text-text-primary font-mono
                        placeholder:text-text-muted resize-none
                        focus:outline-none focus:ring-2 focus:ring-brand-500/50 focus:border-brand-500 transition-all"
                    />
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        ))}
      </div>
    </div>
  )
}

import { models } from '../../config/models'
import useTranslationStore from '../../stores/translationStore'

export default function ModelSelector() {
  const { selectedModel, setModel } = useTranslationStore()
  return (
    <div>
      <label className="block text-sm font-medium text-text-secondary mb-3">
        Select AI Model
      </label>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
        {models.map((model) => (
          <button
            key={model.id}
            onClick={() => setModel(model.id)}
            className={`text-left p-4 rounded-xl border transition-all duration-200 cursor-pointer ${
              selectedModel === model.id
                ? 'border-brand-100 bg-brand-100/10 ring-1 ring-brand-100/30'
                : 'border-surface-border bg-surface-card hover:border-surface-hover hover:bg-surface-hover'
            }`}
          >
            <div className="flex items-center justify-between mb-1">
              <span className="text-sm font-medium text-text-primary">
                {model.name}
              </span>
              <span className="text-[10px] font-medium text-text-muted bg-surface-hover px-1.5 py-0.5 rounded">
                {model.provider}
              </span>
            </div>
            <p className="text-xs text-text-muted leading-relaxed">
              {model.description}
            </p>
          </button>
        ))}
      </div>
    </div>
  )
}

import { Rocket, UserCheck } from 'lucide-react'
import useTranslationStore from '../../stores/translationStore'

const modes = [
  {
    id: 'autopilot',
    label: 'Autopilot',
    icon: Rocket,
    description: 'All steps run automatically — review outputs at the end',
  },
  {
    id: 'human',
    label: 'Human Intervention',
    icon: UserCheck,
    description: 'Review and approve each step before proceeding',
  },
]

export default function ExecutionModeSelector() {
  const { executionMode, setExecutionMode } = useTranslationStore()

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
      {modes.map(({ id, label, icon: Icon, description }) => {
        const selected = executionMode === id

        return (
          <button
            key={id}
            onClick={() => setExecutionMode(id)}
            className={`text-left p-5 rounded-xl border transition-all duration-200 cursor-pointer ${
              selected
                ? 'border-brand-100 bg-brand-100/10 ring-1 ring-brand-100/30'
                : 'border-surface-border bg-surface-card hover:border-surface-hover hover:bg-surface-hover'
            }`}
          >
            <div className="flex items-center gap-3 mb-2">
              <div
                className={`w-9 h-9 rounded-lg flex items-center justify-center ${
                  selected
                    ? 'bg-brand-600/20 text-brand-400'
                    : 'bg-surface-hover text-text-muted'
                }`}
              >
                <Icon className="w-4.5 h-4.5" />
              </div>
              <span className="text-sm font-semibold text-text-primary">
                {label}
              </span>
            </div>
            <p className="text-xs text-text-muted leading-relaxed">
              {description}
            </p>
          </button>
        )
      })}
    </div>
  )
}

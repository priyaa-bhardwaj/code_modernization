import { useRef } from 'react'
import { Upload, FileText, X } from 'lucide-react'
import useTranslationStore from '../../stores/translationStore'

const formatSize = (bytes) => {
  if (bytes < 1024) return bytes + ' B'
  if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB'
  return (bytes / (1024 * 1024)).toFixed(1) + ' MB'
}

export default function ContextUpload() {
  const { contextFiles, addContextFiles, removeContextFile } =
    useTranslationStore()
  const inputRef = useRef(null)

  const handleFiles = (files) => {
    if (files && files.length > 0) {
      addContextFiles(files)
    }
  }

  const handleDrop = (e) => {
    e.preventDefault()
    handleFiles(e.dataTransfer.files)
  }

  const handleDragOver = (e) => {
    e.preventDefault()
  }

  return (
    <div>
      {/* Drop zone */}
      <div
        onDrop={handleDrop}
        onDragOver={handleDragOver}
        onClick={() => inputRef.current?.click()}
        className="border-2 border-dashed border-surface-border rounded-xl p-6 text-center
          hover:border-brand-500/40 hover:bg-brand-600/5 transition-all cursor-pointer"
      >
        <Upload className="w-6 h-6 text-text-muted mx-auto mb-2" />
        <p className="text-sm text-text-secondary">
          Drag & drop context files or{' '}
          <span className="text-brand-400 font-medium">browse</span>
        </p>
        <p className="text-xs text-text-muted mt-1">
          Reference documents, architecture guides, coding standards, etc.
        </p>
        <input
          ref={inputRef}
          type="file"
          multiple
          className="hidden"
          onChange={(e) => {
            handleFiles(e.target.files)
            e.target.value = ''
          }}
        />
      </div>

      {/* Uploaded files list */}
      {contextFiles.length > 0 && (
        <div className="mt-3 border border-surface-border rounded-xl overflow-hidden divide-y divide-surface-border">
          {contextFiles.map((file, index) => (
            <div
              key={`${file.name}-${index}`}
              className="flex items-center gap-3 px-4 py-2.5 bg-surface-card"
            >
              <FileText className="w-4 h-4 text-text-muted shrink-0" />
              <span className="text-sm text-text-primary truncate flex-1">
                {file.name}
              </span>
              <span className="text-xs text-text-muted shrink-0">
                {formatSize(file.size)}
              </span>
              <button
                onClick={(e) => {
                  e.stopPropagation()
                  removeContextFile(index)
                }}
                className="p-1 rounded-md hover:bg-surface-hover text-text-muted hover:text-error transition-colors cursor-pointer"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}

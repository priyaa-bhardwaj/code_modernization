import Editor from '@monaco-editor/react'
import clsx from 'clsx'
import Spinner from '../ui/Spinner'
import useThemeStore from '../../stores/themeStore'

export default function CodeViewer({ value, language = 'markdown', height = '400px', borderless = false }) {
  const { theme } = useThemeStore()

  return (
    <div
      className={clsx(
        'overflow-hidden h-full',
        !borderless && 'border border-surface-border rounded-xl'
      )}
    >
      <Editor
        height={height}
        language={language}
        value={value || ''}
        theme={theme === 'dark' ? 'vs-dark' : 'light'}
        loading={
          <div className="flex items-center justify-center h-full min-h-[200px] bg-surface-card">
            <Spinner />
          </div>
        }
        options={{
          readOnly: true,
          minimap: { enabled: false },
          fontSize: 13,
          fontFamily: "'JetBrains Mono', 'Fira Code', monospace",
          lineNumbers: 'on',
          wordWrap: 'on',
          scrollBeyondLastLine: false,
          renderLineHighlight: 'none',
          padding: { top: 16, bottom: 16 },
          overviewRulerBorder: false,
          hideCursorInOverviewRuler: true,
          scrollbar: {
            verticalScrollbarSize: 6,
            horizontalScrollbarSize: 6,
          },
        }}
      />
    </div>
  )
}

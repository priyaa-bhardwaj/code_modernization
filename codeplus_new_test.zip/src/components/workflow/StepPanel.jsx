import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Loader2, AlertCircle, Save } from 'lucide-react'
import { getPipeline } from '../../config/pipelines'
import useWorkflowStore from '../../stores/workflowStore'
import CodeViewer from './CodeViewer'
import CodeEditor from './CodeEditor'
import FileTreePanel from './FileTreePanel'
import ApprovalToolbar from './ApprovalToolbar'
import RepromptModal from './RepromptModal'
import Button from '../ui/Button'

const isFileTreeOutput = (output) =>
  typeof output === 'object' && output !== null

export default function StepPanel({
  step,
  stepIndex,
  onApprove,
  onEditOutput,
  onReprompt,
  readOnly = false,
}) {
  const { pipelineType } = useWorkflowStore()
  const pipeline = getPipeline(pipelineType)

  const [isEditing, setIsEditing] = useState(false)
  const [editedOutput, setEditedOutput] = useState('')
  const [editedFiles, setEditedFiles] = useState({})
  const [showReprompt, setShowReprompt] = useState(false)

  const stepLabel = pipeline.steps[stepIndex] || step.name
  const stepDescription = pipeline.stepDescriptions[stepIndex] || ''

  const isFileTree = isFileTreeOutput(step.output)

  // --- Handlers for single-string output (steps 0 & 2) ---
  const handleManualEdit = () => {
    setEditedOutput(step.output || '')
    setIsEditing(true)
  }

  const handleSaveEdit = () => {
    onEditOutput(stepIndex, editedOutput)
    setIsEditing(false)
  }

  // --- Handlers for file-tree output (step 1) ---
  const handleManualEditFiles = () => {
    setEditedFiles({ ...step.output })
    setIsEditing(true)
  }

  const handleSaveFileEdit = () => {
    onEditOutput(stepIndex, editedFiles)
    setIsEditing(false)
  }

  const handleFileChange = (filePath, content) => {
    setEditedFiles((prev) => ({ ...prev, [filePath]: content }))
  }

  // --- Shared ---
  const handleReprompt = async (prompt) => {
    await onReprompt(stepIndex, prompt)
  }

  const getLanguage = () => {
    if (stepIndex === 1) return 'java'
    return 'markdown'
  }

  const getCopyOutput = () => {
    if (isFileTree) {
      const files = Object.values(step.output)
      return files[0] || ''
    }
    return step.output || ''
  }

  return (
    <AnimatePresence mode="wait">
      <motion.div
        key={`step-${stepIndex}-${step.status}`}
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: -10 }}
        transition={{ duration: 0.3 }}
      >
        {/* Step Header */}
        <div className="mb-4">
          <h3 className="text-lg font-semibold text-text-primary">
            Step {stepIndex + 1}: {stepLabel}
          </h3>
          {isFileTree && step.status === 'complete' && (
            <p className="text-xs text-text-muted mt-1">
              {Object.keys(step.output).length} files generated
            </p>
          )}
        </div>

        {/* Running state */}
        {step.status === 'running' && (
          <div className="bg-surface-card border border-surface-border rounded-xl p-12 flex flex-col items-center justify-center">
            <div className="relative mb-4">
              <div className="w-16 h-16 rounded-full bg-brand-600/10 flex items-center justify-center">
                <Loader2 className="w-8 h-8 text-brand-500 animate-spin" />
              </div>
              <div className="absolute inset-0 w-16 h-16 rounded-full bg-brand-500/20 animate-ping" />
            </div>
            <p className="text-sm text-text-secondary text-center">
              {stepDescription}
            </p>
            <p className="text-xs text-text-muted mt-2">
              This may take a few moments
            </p>
          </div>
        )}

        {/* Error state */}
        {step.status === 'error' && (
          <div className="bg-error/5 border border-error/20 rounded-xl p-8 flex flex-col items-center">
            <AlertCircle className="w-8 h-8 text-error mb-3" />
            <p className="text-sm text-error font-medium">
              An error occurred during {stepLabel.toLowerCase()}
            </p>
            <p className="text-xs text-text-muted mt-1">
              {step.error || 'Please try again'}
            </p>
          </div>
        )}

        {/* Complete state */}
        {step.status === 'complete' && (
          <div>
            {isEditing && !readOnly ? (
              isFileTree ? (
                /* File tree editing mode */
                <div>
                  <FileTreePanel
                    files={editedFiles}
                    isEditing={true}
                    onFileChange={handleFileChange}
                  />
                  <div className="flex items-center gap-3 mt-4">
                    <Button onClick={handleSaveFileEdit} className="gap-2">
                      <Save className="w-4 h-4" />
                      Save & Proceed
                    </Button>
                    <Button
                      variant="ghost"
                      onClick={() => setIsEditing(false)}
                    >
                      Cancel
                    </Button>
                  </div>
                </div>
              ) : (
                /* Single string editing mode */
                <div>
                  <CodeEditor
                    value={editedOutput}
                    onChange={setEditedOutput}
                    language={getLanguage()}
                  />
                  <div className="flex items-center gap-3 mt-4">
                    <Button onClick={handleSaveEdit} className="gap-2">
                      <Save className="w-4 h-4" />
                      Save & Proceed
                    </Button>
                    <Button
                      variant="ghost"
                      onClick={() => setIsEditing(false)}
                    >
                      Cancel
                    </Button>
                  </div>
                </div>
              )
            ) : isFileTree ? (
              /* File tree viewing mode */
              <div>
                <FileTreePanel
                  files={step.output}
                  isEditing={false}
                  onFileChange={() => {}}
                />
                {!readOnly && (
                  <ApprovalToolbar
                    output={getCopyOutput()}
                    onApprove={() => onApprove(stepIndex)}
                    onManualEdit={handleManualEditFiles}
                    onReprompt={() => setShowReprompt(true)}
                  />
                )}
              </div>
            ) : (
              /* Single string viewing mode */
              <div>
                <CodeViewer value={step.output} language={getLanguage()} />
                {!readOnly && (
                  <ApprovalToolbar
                    output={getCopyOutput()}
                    onApprove={() => onApprove(stepIndex)}
                    onManualEdit={handleManualEdit}
                    onReprompt={() => setShowReprompt(true)}
                  />
                )}
              </div>
            )}
          </div>
        )}

        {/* Pending state */}
        {step.status === 'pending' && (
          <div className="bg-surface-card border border-surface-border rounded-xl p-8 flex flex-col items-center">
            <div className="w-12 h-12 rounded-full bg-surface-hover flex items-center justify-center mb-3">
              <span className="text-lg font-bold text-text-muted">
                {stepIndex + 1}
              </span>
            </div>
            <p className="text-sm text-text-muted">
              Waiting for previous step to complete
            </p>
          </div>
        )}

        {/* Reprompt modal */}
        {!readOnly && (
          <RepromptModal
            isOpen={showReprompt}
            onClose={() => setShowReprompt(false)}
            onSubmit={handleReprompt}
            stepName={stepLabel}
          />
        )}
      </motion.div>
    </AnimatePresence>
  )
}

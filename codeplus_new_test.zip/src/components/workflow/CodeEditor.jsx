import Editor from '@monaco-editor/react'
import clsx from 'clsx'
import Spinner from '../ui/Spinner'
import useThemeStore from '../../stores/themeStore'

export default function CodeEditor({ value, onChange, language = 'markdown', height = '400px', borderless = false }) {
  const { theme } = useThemeStore()

  return (
    <div
      className={clsx(
        'overflow-hidden h-full flex flex-col',
        !borderless && 'border border-brand-500/30 rounded-xl ring-1 ring-brand-500/20'
      )}
    >
      <div className="bg-brand-600/10 px-4 py-2 border-b border-brand-500/20 shrink-0">
        <span className="text-xs font-medium text-brand-400">
          Editing Mode — Make your changes below
        </span>
      </div>
      <div className="flex-1 min-h-0">
        <Editor
          height={height}
          language={language}
          value={value || ''}
          theme={theme === 'dark' ? 'vs-dark' : 'light'}
          onChange={onChange}
          loading={
            <div className="flex items-center justify-center h-full min-h-[200px] bg-surface-card">
              <Spinner />
            </div>
          }
          options={{
            minimap: { enabled: false },
            fontSize: 13,
            fontFamily: "'JetBrains Mono', 'Fira Code', monospace",
            lineNumbers: 'on',
            wordWrap: 'on',
            scrollBeyondLastLine: false,
            padding: { top: 16, bottom: 16 },
            overviewRulerBorder: false,
            scrollbar: {
              verticalScrollbarSize: 6,
              horizontalScrollbarSize: 6,
            },
          }}
        />
      </div>
    </div>
  )
}

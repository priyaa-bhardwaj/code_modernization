import { useState, useRef, useEffect } from 'react'
import { Check, Pencil, Copy, ChevronDown, FileEdit, MessageSquare } from 'lucide-react'
import Button from '../ui/Button'
import toast from 'react-hot-toast'

export default function ApprovalToolbar({
  output,
  onApprove,
  onManualEdit,
  onReprompt,
  isLoading,
}) {
  const [editDropdown, setEditDropdown] = useState(false)
  const dropdownRef = useRef(null)

  useEffect(() => {
    const handleClick = (e) => {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target)) {
        setEditDropdown(false)
      }
    }
    document.addEventListener('mousedown', handleClick)
    return () => document.removeEventListener('mousedown', handleClick)
  }, [])

  const handleCopy = () => {
    navigator.clipboard.writeText(output || '')
    toast.success('Copied to clipboard')
  }

  return (
    <div className="flex items-center gap-3 mt-4">
      {/* Approve */}
      <Button
        onClick={onApprove}
        variant="success"
        isLoading={isLoading}
        className="gap-2"
      >
        <Check className="w-4 h-4" />
        Approve
      </Button>

      {/* Edit dropdown */}
      <div className="relative" ref={dropdownRef}>
        <Button
          variant="secondary"
          onClick={() => setEditDropdown(!editDropdown)}
          className="gap-2"
        >
          <Pencil className="w-4 h-4" />
          Edit
          <ChevronDown className="w-3.5 h-3.5" />
        </Button>

        {editDropdown && (
          <div className="absolute left-0 mt-2 w-56 bg-surface-card border border-surface-border rounded-xl shadow-2xl shadow-black/30 py-1 z-10">
            <button
              onClick={() => {
                setEditDropdown(false)
                onManualEdit()
              }}
              className="w-full flex items-center gap-3 px-4 py-2.5 text-sm text-text-primary hover:bg-surface-hover transition-colors cursor-pointer"
            >
              <FileEdit className="w-4 h-4 text-text-muted" />
              <div className="text-left">
                <p className="font-medium">Manual Edit</p>
                <p className="text-xs text-text-muted">
                  Edit the output directly
                </p>
              </div>
            </button>
            <button
              onClick={() => {
                setEditDropdown(false)
                onReprompt()
              }}
              className="w-full flex items-center gap-3 px-4 py-2.5 text-sm text-text-primary hover:bg-surface-hover transition-colors cursor-pointer"
            >
              <MessageSquare className="w-4 h-4 text-text-muted" />
              <div className="text-left">
                <p className="font-medium">Re-prompt</p>
                <p className="text-xs text-text-muted">
                  Give new instructions to regenerate
                </p>
              </div>
            </button>
          </div>
        )}
      </div>

      {/* Copy */}
      <Button variant="ghost" onClick={handleCopy} className="gap-2">
        <Copy className="w-4 h-4" />
        Copy
      </Button>
    </div>
  )
}

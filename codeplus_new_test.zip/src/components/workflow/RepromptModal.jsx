import { useState } from 'react'
import Modal from '../ui/Modal'
import Button from '../ui/Button'
import { Send } from 'lucide-react'

export default function RepromptModal({ isOpen, onClose, onSubmit, stepName }) {
  const [prompt, setPrompt] = useState('')
  const [isSubmitting, setIsSubmitting] = useState(false)

  const handleSubmit = async () => {
    if (!prompt.trim()) return
    setIsSubmitting(true)
    await onSubmit(prompt)
    setPrompt('')
    setIsSubmitting(false)
    onClose()
  }

  return (
    <Modal isOpen={isOpen} onClose={onClose} title={`Re-prompt: ${stepName}`} size="lg">
      <div className="space-y-4">
        <p className="text-sm text-text-secondary">
          Provide updated instructions to regenerate the output for this step.
          Be specific about what changes you want.
        </p>

        <textarea
          value={prompt}
          onChange={(e) => setPrompt(e.target.value)}
          placeholder="e.g., Include more detailed error handling, add pagination support, use a different design pattern..."
          rows={6}
          className="w-full bg-surface-input border border-surface-border rounded-lg px-4 py-3 text-sm text-text-primary font-mono
            placeholder:text-text-muted resize-none
            focus:outline-none focus:ring-2 focus:ring-brand-500/50 focus:border-brand-500 transition-all"
          autoFocus
        />

        <div className="flex justify-end gap-3 pt-2">
          <Button variant="ghost" onClick={onClose}>
            Cancel
          </Button>
          <Button
            onClick={handleSubmit}
            isLoading={isSubmitting}
            disabled={!prompt.trim()}
            className="gap-2"
          >
            <Send className="w-4 h-4" />
            Regenerate
          </Button>
        </div>
      </div>
    </Modal>
  )
}

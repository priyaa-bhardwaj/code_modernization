import { useState, useEffect, useMemo } from 'react'
import { FileCode } from 'lucide-react'
import FileExplorer from './FileExplorer'
import CodeViewer from './CodeViewer'
import CodeEditor from './CodeEditor'
import { inferLanguage } from '../../utils/languageUtils'

export default function FileTreePanel({ files, isEditing, onFileChange }) {
  const filePaths = useMemo(() => Object.keys(files), [files])
  const [selectedFile, setSelectedFile] = useState(null)

  // Auto-select first file on mount or when files change
  useEffect(() => {
    if (filePaths.length > 0 && (!selectedFile || !files[selectedFile])) {
      setSelectedFile(filePaths[0])
    }
  }, [filePaths, selectedFile, files])

  const currentContent = selectedFile ? files[selectedFile] || '' : ''
  const currentLanguage = selectedFile ? inferLanguage(selectedFile) : 'plaintext'

  return (
    <div className="border border-surface-border rounded-xl overflow-hidden flex" style={{ height: '500px' }}>
      {/* File tree sidebar */}
      <div className="w-60 shrink-0 border-r border-surface-border bg-surface-card overflow-y-auto">
        <FileExplorer
          files={files}
          selectedFile={selectedFile}
          onSelectFile={setSelectedFile}
        />
      </div>

      {/* Editor area */}
      <div className="flex-1 min-w-0 flex flex-col">
        {/* Breadcrumb bar */}
        {selectedFile && (
          <div className="flex items-center gap-2 px-4 py-2 bg-surface-card border-b border-surface-border">
            <FileCode className="w-3.5 h-3.5 text-text-muted shrink-0" />
            <span className="text-xs text-text-secondary truncate font-mono">
              {selectedFile}
            </span>
          </div>
        )}

        {/* Content area */}
        <div className="flex-1 min-h-0">
          {selectedFile ? (
            isEditing ? (
              <CodeEditor
                value={currentContent}
                onChange={(val) => onFileChange(selectedFile, val)}
                language={currentLanguage}
                height="100%"
                borderless
              />
            ) : (
              <CodeViewer
                value={currentContent}
                language={currentLanguage}
                height="100%"
                borderless
              />
            )
          ) : (
            <div className="flex items-center justify-center h-full bg-surface-card">
              <p className="text-sm text-text-muted">Select a file to view</p>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

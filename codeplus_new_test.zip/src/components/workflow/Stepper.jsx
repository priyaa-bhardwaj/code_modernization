import { motion } from 'framer-motion'
import { Check, Loader2, AlertCircle } from 'lucide-react'
import clsx from 'clsx'

export default function Stepper({ steps, currentStep }) {
  return (
    <div className="flex items-center justify-center w-full max-w-2xl mx-auto mb-8">
      {steps.map((step, index) => (
        <div key={index} className="flex items-center flex-1 last:flex-initial">
          {/* Step node */}
          <div className="flex flex-col items-center">
            <motion.div
              initial={false}
              animate={{
                scale: step.status === 'running' ? [1, 1.1, 1] : 1,
              }}
              transition={{
                duration: 1.5,
                repeat: step.status === 'running' ? Infinity : 0,
              }}
              className={clsx(
                'w-10 h-10 rounded-full flex items-center justify-center border-2 transition-all duration-500',
                step.status === 'complete' &&
                  'bg-success border-success text-white',
                step.status === 'running' &&
                  'bg-brand-600/20 border-brand-500 text-brand-400',
                step.status === 'error' &&
                  'bg-error/20 border-error text-error',
                step.status === 'pending' &&
                  'bg-surface-card border-surface-border text-text-muted',
              )}
            >
              {step.status === 'complete' && <Check className="w-5 h-5" />}
              {step.status === 'running' && (
                <Loader2 className="w-5 h-5 animate-spin" />
              )}
              {step.status === 'error' && (
                <AlertCircle className="w-5 h-5" />
              )}
              {step.status === 'pending' && (
                <span className="text-sm font-semibold">{index + 1}</span>
              )}
            </motion.div>

            <span
              className={clsx(
                'text-xs font-medium mt-2 whitespace-nowrap transition-colors',
                step.status === 'complete' && 'text-success',
                step.status === 'running' && 'text-brand-400',
                step.status === 'error' && 'text-error',
                step.status === 'pending' && 'text-text-muted',
              )}
            >
              {step.name}
            </span>
          </div>

          {/* Connector line */}
          {index < steps.length - 1 && (
            <div className="flex-1 h-0.5 mx-4 mt-[-1.25rem] relative">
              <div className="absolute inset-0 bg-surface-border rounded-full" />
              <motion.div
                initial={{ width: '0%' }}
                animate={{
                  width:
                    step.status === 'complete'
                      ? '100%'
                      : step.status === 'running'
                        ? '50%'
                        : '0%',
                }}
                transition={{ duration: 0.6, ease: 'easeInOut' }}
                className="absolute inset-y-0 left-0 bg-brand-500 rounded-full"
              />
            </div>
          )}
        </div>
      ))}
    </div>
  )
}

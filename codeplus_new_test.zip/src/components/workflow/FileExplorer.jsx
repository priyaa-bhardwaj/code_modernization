import { useState, useMemo } from 'react'
import {
  ChevronRight,
  ChevronDown,
  Folder,
  FolderOpen,
  FileCode,
  File,
} from 'lucide-react'
import clsx from 'clsx'

const CODE_EXTENSIONS = new Set([
  'java', 'js', 'jsx', 'ts', 'tsx', 'py', 'go', 'rs', 'rb',
  'kt', 'cs', 'cpp', 'c', 'h', 'sql', 'html', 'css', 'xml',
  'yml', 'yaml', 'json', 'gradle', 'sh',
])

function buildTree(filePaths) {
  const root = { name: '', type: 'folder', children: [], path: '' }

  filePaths.forEach((filePath) => {
    const parts = filePath.split('/')
    let current = root

    parts.forEach((part, i) => {
      const isFile = i === parts.length - 1
      const existing = current.children.find(
        (c) => c.name === part && c.type === (isFile ? 'file' : 'folder')
      )

      if (existing) {
        current = existing
      } else {
        const node = {
          name: part,
          type: isFile ? 'file' : 'folder',
          children: isFile ? null : [],
          path: isFile ? filePath : parts.slice(0, i + 1).join('/'),
        }
        current.children.push(node)
        current = node
      }
    })
  })

  // Sort: folders first, then alphabetical
  const sortChildren = (node) => {
    if (!node.children) return
    node.children.sort((a, b) => {
      if (a.type !== b.type) return a.type === 'folder' ? -1 : 1
      return a.name.localeCompare(b.name)
    })
    node.children.forEach(sortChildren)
  }
  sortChildren(root)

  return root.children
}

function collectFolderPaths(nodes) {
  const paths = new Set()
  const walk = (list) => {
    list.forEach((node) => {
      if (node.type === 'folder') {
        paths.add(node.path)
        walk(node.children)
      }
    })
  }
  walk(nodes)
  return paths
}

function TreeNode({ node, depth, selectedFile, onSelectFile, expanded, onToggle }) {
  const isFolder = node.type === 'folder'
  const isSelected = !isFolder && node.path === selectedFile
  const isExpanded = isFolder && expanded.has(node.path)

  const ext = !isFolder ? node.name.split('.').pop().toLowerCase() : ''
  const isCodeFile = CODE_EXTENSIONS.has(ext)

  const handleClick = () => {
    if (isFolder) {
      onToggle(node.path)
    } else {
      onSelectFile(node.path)
    }
  }

  return (
    <>
      <button
        onClick={handleClick}
        className={clsx(
          'w-full flex items-center gap-1.5 py-1 px-2 text-left text-xs transition-colors cursor-pointer rounded-md',
          isSelected
            ? 'bg-brand-600/15 text-brand-400'
            : 'text-text-secondary hover:bg-surface-hover hover:text-text-primary'
        )}
        style={{ paddingLeft: `${depth * 12 + 8}px` }}
        title={node.path}
      >
        {isFolder ? (
          <>
            {isExpanded ? (
              <ChevronDown className="w-3.5 h-3.5 shrink-0 text-text-muted" />
            ) : (
              <ChevronRight className="w-3.5 h-3.5 shrink-0 text-text-muted" />
            )}
            {isExpanded ? (
              <FolderOpen className="w-3.5 h-3.5 shrink-0 text-brand-400" />
            ) : (
              <Folder className="w-3.5 h-3.5 shrink-0 text-brand-400" />
            )}
          </>
        ) : (
          <>
            <span className="w-3.5 shrink-0" />
            {isCodeFile ? (
              <FileCode className="w-3.5 h-3.5 shrink-0 text-text-muted" />
            ) : (
              <File className="w-3.5 h-3.5 shrink-0 text-text-muted" />
            )}
          </>
        )}
        <span className="truncate">{node.name}</span>
      </button>

      {isFolder && isExpanded &&
        node.children.map((child) => (
          <TreeNode
            key={child.path}
            node={child}
            depth={depth + 1}
            selectedFile={selectedFile}
            onSelectFile={onSelectFile}
            expanded={expanded}
            onToggle={onToggle}
          />
        ))}
    </>
  )
}

export default function FileExplorer({ files, selectedFile, onSelectFile }) {
  const filePaths = useMemo(() => Object.keys(files), [files])
  const tree = useMemo(() => buildTree(filePaths), [filePaths])
  const allFolders = useMemo(() => collectFolderPaths(tree), [tree])

  const [expanded, setExpanded] = useState(() => new Set(allFolders))

  const handleToggle = (folderPath) => {
    setExpanded((prev) => {
      const next = new Set(prev)
      if (next.has(folderPath)) {
        next.delete(folderPath)
      } else {
        next.add(folderPath)
      }
      return next
    })
  }

  return (
    <div className="py-2 space-y-0.5">
      <div className="px-3 pb-2 mb-1 border-b border-surface-border">
        <span className="text-[10px] font-semibold uppercase tracking-wider text-text-muted">
          Explorer
        </span>
      </div>
      {tree.map((node) => (
        <TreeNode
          key={node.path}
          node={node}
          depth={0}
          selectedFile={selectedFile}
          onSelectFile={onSelectFile}
          expanded={expanded}
          onToggle={handleToggle}
        />
      ))}
    </div>
  )
}

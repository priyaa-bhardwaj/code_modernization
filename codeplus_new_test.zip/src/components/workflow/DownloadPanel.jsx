import { useState } from 'react'
import { motion } from 'framer-motion'
import { Download, CheckCircle2, PartyPopper } from 'lucide-react'
import Button from '../ui/Button'
import { translationService } from '../../services/translationService'
import toast from 'react-hot-toast'

export default function DownloadPanel({ jobId }) {
  const [isDownloading, setIsDownloading] = useState(false)

  const handleDownload = async () => {
    setIsDownloading(true)
    try {
      const blob = await translationService.downloadResult(jobId)
      const url = URL.createObjectURL(blob)
      const a = document.createElement('a')
      a.href = url
      a.download = `codeplus-modernized-${jobId}.zip`
      document.body.appendChild(a)
      a.click()
      document.body.removeChild(a)
      URL.revokeObjectURL(url)
      toast.success('Download started!')
    } catch {
      toast.error('Download failed')
    } finally {
      setIsDownloading(false)
    }
  }

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.5, ease: 'easeOut' }}
      className="mt-8 bg-gradient-to-br from-brand-600/10 via-surface-card to-success/5 border border-brand-500/20 rounded-2xl p-8 text-center"
    >
      <motion.div
        initial={{ scale: 0 }}
        animate={{ scale: 1 }}
        transition={{ delay: 0.2, type: 'spring', stiffness: 200 }}
        className="w-16 h-16 bg-success/10 rounded-full flex items-center justify-center mx-auto mb-4"
      >
        <CheckCircle2 className="w-8 h-8 text-success" />
      </motion.div>

      <div className="flex items-center justify-center gap-2 mb-2">
        <PartyPopper className="w-5 h-5 text-warning" />
        <h3 className="text-xl font-bold text-text-primary">
          Modernization Complete!
        </h3>
      </div>

      <p className="text-sm text-text-secondary mb-6 max-w-md mx-auto">
        All three stages have been completed successfully. Your modernized code
        is ready for download.
      </p>

      <Button
        onClick={handleDownload}
        isLoading={isDownloading}
        size="lg"
        className="gap-2 px-8"
      >
        <Download className="w-5 h-5" />
        Download Modernized Code
      </Button>
    </motion.div>
  )
}

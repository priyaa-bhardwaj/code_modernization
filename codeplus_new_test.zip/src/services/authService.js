import { apiFetch } from './api'

const MOCK = import.meta.env.VITE_MOCK_API === 'true' || !import.meta.env.VITE_API_URL

const delay = (ms) => new Promise((r) => setTimeout(r, ms))

export const authService = {
  login: async (email, password) => {
    if (MOCK) {
      await delay(800)
      if (!email || !password) throw new Error('Email and password are required')
      return {
        user: {
          id: '1',
          name: email.split('@')[0].replace(/[._]/g, ' ').replace(/\b\w/g, (c) => c.toUpperCase()),
          email,
        },
        token: 'mock-jwt-token-' + Date.now(),
      }
    }

    return apiFetch('/auth/login', {
      method: 'POST',
      body: JSON.stringify({ email, password }),
    })
  },

  signup: async (name, email, password) => {
    if (MOCK) {
      await delay(800)
      if (!name || !email || !password) throw new Error('All fields are required')
      return {
        user: { id: '1', name, email },
        token: 'mock-jwt-token-' + Date.now(),
      }
    }

    return apiFetch('/auth/signup', {
      method: 'POST',
      body: JSON.stringify({ name, email, password }),
    })
  },
}

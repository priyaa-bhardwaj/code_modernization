const BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:8000/api'

export async function apiFetch(path, options = {}) {
  const token = localStorage.getItem('codeplus_token')

  const headers = {
    ...options.headers,
  }

  if (!(options.body instanceof FormData)) {
    headers['Content-Type'] = 'application/json'
  }

  if (token) {
    headers['Authorization'] = `Bearer ${token}`
  }

  const response = await fetch(`${BASE_URL}${path}`, {
    ...options,
    headers,
  })

  if (response.status === 401) {
    localStorage.removeItem('codeplus_token')
    localStorage.removeItem('codeplus_user')
    window.location.href = '/login'
    throw new Error('Session expired')
  }

  if (!response.ok) {
    const data = await response.json().catch(() => ({}))
    throw new Error(data.message || `Request failed (${response.status})`)
  }

  if (response.headers.get('content-type')?.includes('application/json')) {
    return response.json()
  }

  return response
}

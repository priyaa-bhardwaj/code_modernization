import { apiFetch } from './api'

const MOCK = import.meta.env.VITE_MOCK_API === 'true' || !import.meta.env.VITE_API_URL

const delay = (ms) => new Promise((r) => setTimeout(r, ms))

export const translationService = {
  uploadZip: async (file) => {
    if (MOCK) {
      await delay(1000)
      return { fileId: 'file-' + Date.now() }
    }

    const formData = new FormData()
    formData.append('file', file)
    return apiFetch('/translate/upload', {
      method: 'POST',
      body: formData,
    })
  },

  uploadContext: async (files) => {
    if (MOCK) {
      await delay(800)
      return {
        contextIds: Array.from(files).map(
          (_, i) => `ctx-${Date.now()}-${i}`
        ),
      }
    }

    const formData = new FormData()
    Array.from(files).forEach((file) => formData.append('context', file))
    return apiFetch('/translate/context', {
      method: 'POST',
      body: formData,
    })
  },

  generate: async ({ fileId, translationId, model, prompts, pipelineType, executionMode, contextIds }) => {
    if (MOCK) {
      await delay(500)
      return { jobId: 'job-' + Date.now() }
    }

    return apiFetch('/translate/generate', {
      method: 'POST',
      body: JSON.stringify({
        fileId,
        translationId,
        model,
        prompts,
        pipelineType,
        executionMode,
        contextIds,
      }),
    })
  },

  getJobStatus: async (jobId) => {
    if (MOCK) {
      await delay(300)
      return { jobId, status: 'running', steps: [] }
    }

    return apiFetch(`/translate/job/${jobId}`)
  },

  approveStep: async (jobId, stepIndex) => {
    if (MOCK) {
      await delay(500)
      return { success: true }
    }

    return apiFetch(`/translate/job/${jobId}/approve/${stepIndex}`, {
      method: 'POST',
    })
  },

  repromptStep: async (jobId, stepIndex, newPrompt) => {
    if (MOCK) {
      await delay(500)
      return { success: true }
    }

    return apiFetch(`/translate/job/${jobId}/reprompt/${stepIndex}`, {
      method: 'POST',
      body: JSON.stringify({ prompt: newPrompt }),
    })
  },

  downloadResult: async (jobId) => {
    if (MOCK) {
      await delay(500)
      const content = 'Mock modernized code output - this would be a real zip in production'
      return new Blob([content], { type: 'application/zip' })
    }

    const response = await apiFetch(`/translate/job/${jobId}/download`)
    return response.blob()
  },
}

import { useMemo, useState } from 'react'
import { ChevronDown, ChevronRight, FileText, Save, RotateCcw, Loader2 } from 'lucide-react'
import { motion, AnimatePresence } from 'framer-motion'
import useConfigStore from '../../stores/configStore'
import useTranslationStore from '../../stores/translationStore'
import toast from 'react-hot-toast'

export default function PromptEditor() {
  const [openStep, setOpenStep] = useState(null)
  const [isSaving, setIsSaving] = useState(false)
  const [isResetting, setIsResetting] = useState(false)
  const {
    pipelineType,
    prompts,
    isCustomPrompts,
    isLoadingPrompts,
    updatePrompt,
    savePrompts,
    resetPrompts,
  } = useTranslationStore()
  const { pipelines } = useConfigStore()

  const steps = useMemo(() => {
    const pipeline = pipelines[pipelineType]
    if (!pipeline) return []
    return pipeline.promptKeys.map((key, i) => ({
      key,
      label: pipeline.promptLabels[i],
      icon: String(i + 1),
    }))
  }, [pipelineType, pipelines])

  const toggle = (key) => setOpenStep(openStep === key ? null : key)

  const handleSave = async () => {
    setIsSaving(true)
    try {
      await savePrompts(pipelineType, prompts)
      toast.success('Prompts saved for your account')
    } catch {
      toast.error('Failed to save prompts')
    } finally {
      setIsSaving(false)
    }
  }

  const handleReset = async () => {
    setIsResetting(true)
    try {
      await resetPrompts(pipelineType)
      toast.success('Prompts reset to defaults')
    } catch {
      toast.error('Failed to reset prompts')
    } finally {
      setIsResetting(false)
    }
  }

  if (isLoadingPrompts) {
    return (
      <div className="flex items-center justify-center py-8">
        <Loader2 className="w-5 h-5 text-brand-400 animate-spin" />
        <span className="ml-2 text-sm text-text-muted">Loading prompts...</span>
      </div>
    )
  }

  return (
    <div>
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <FileText className="w-4 h-4 text-text-muted" />
          <label className="text-sm font-medium text-text-secondary">
            Prompts (View / Edit)
          </label>
          {isCustomPrompts && (
            <span className="text-[10px] font-medium px-1.5 py-0.5 rounded bg-brand-600/20 text-brand-400">
              Custom
            </span>
          )}
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={handleSave}
            disabled={isSaving}
            className="flex items-center gap-1 px-3 py-1.5 text-xs font-medium rounded-lg
              bg-brand-600/10 text-brand-400 hover:bg-brand-600/20
              disabled:opacity-50 transition-colors cursor-pointer"
          >
            {isSaving ? (
              <Loader2 className="w-3 h-3 animate-spin" />
            ) : (
              <Save className="w-3 h-3" />
            )}
            Save
          </button>
          <button
            onClick={handleReset}
            disabled={isResetting}
            className="flex items-center gap-1 px-3 py-1.5 text-xs font-medium rounded-lg
              bg-surface-hover text-text-muted hover:text-text-secondary
              disabled:opacity-50 transition-colors cursor-pointer"
          >
            {isResetting ? (
              <Loader2 className="w-3 h-3 animate-spin" />
            ) : (
              <RotateCcw className="w-3 h-3" />
            )}
            Defaults
          </button>
        </div>
      </div>

      <div className="space-y-2">
        {steps.map((step) => (
          <div
            key={step.key}
            className="border border-surface-border rounded-xl overflow-hidden"
          >
            <button
              onClick={() => toggle(step.key)}
              className="w-full flex items-center gap-3 px-4 py-3 bg-surface-card hover:bg-surface-hover transition-colors cursor-pointer"
            >
              <span className="w-6 h-6 bg-brand-600/20 text-brand-400 rounded-full flex items-center justify-center text-xs font-bold">
                {step.icon}
              </span>
              <span className="text-sm font-medium text-text-primary flex-1 text-left">
                {step.label}
              </span>
              {openStep === step.key ? (
                <ChevronDown className="w-4 h-4 text-text-muted" />
              ) : (
                <ChevronRight className="w-4 h-4 text-text-muted" />
              )}
            </button>

            <AnimatePresence>
              {openStep === step.key && (
                <motion.div
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: 'auto', opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  transition={{ duration: 0.2 }}
                  className="overflow-hidden"
                >
                  <div className="px-4 pb-4">
                    <textarea
                      value={prompts[step.key] || ''}
                      onChange={(e) => updatePrompt(step.key, e.target.value)}
                      rows={4}
                      className="w-full bg-surface-input border border-surface-border rounded-lg px-4 py-3 text-sm text-text-primary font-mono
                        placeholder:text-text-muted resize-none
                        focus:outline-none focus:ring-2 focus:ring-brand-500/50 focus:border-brand-500 transition-all"
                    />
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        ))}
      </div>
    </div>
  )
}

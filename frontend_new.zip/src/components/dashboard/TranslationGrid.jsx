import useConfigStore from '../../stores/configStore'
import TranslationCard from './TranslationCard'
import { Loader2 } from 'lucide-react'

export default function TranslationGrid() {
  const { dashboardCards, isLoading } = useConfigStore()

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-16">
        <Loader2 className="w-6 h-6 text-brand-400 animate-spin" />
        <span className="ml-2 text-sm text-text-muted">Loading modernization paths...</span>
      </div>
    )
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
      {dashboardCards.map((t, i) => (
        <TranslationCard key={t.id} translation={t} index={i} />
      ))}
    </div>
  )
}

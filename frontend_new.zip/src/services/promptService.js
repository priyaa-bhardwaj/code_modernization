import { apiFetch } from './api'

const MOCK = import.meta.env.VITE_MOCK_API === 'true' || !import.meta.env.VITE_API_URL

export const promptService = {
  getPrompts: async (pipelineType) => {
    if (MOCK) {
      const { getPipeline } = await import('../config/pipelines')
      const pipeline = getPipeline(pipelineType)
      return { prompts: { ...pipeline.defaultPrompts }, isCustom: false }
    }
    return apiFetch(`/prompts/${pipelineType}`)
  },

  savePrompts: async (pipelineType, prompts) => {
    if (MOCK) {
      return { message: 'Saved (mock)' }
    }
    return apiFetch(`/prompts/${pipelineType}`, {
      method: 'PUT',
      body: JSON.stringify({ prompts }),
    })
  },

  resetPrompts: async (pipelineType) => {
    if (MOCK) {
      const { getPipeline } = await import('../config/pipelines')
      const pipeline = getPipeline(pipelineType)
      return { prompts: { ...pipeline.defaultPrompts }, isCustom: false }
    }
    return apiFetch(`/prompts/${pipelineType}`, {
      method: 'DELETE',
    })
  },
}

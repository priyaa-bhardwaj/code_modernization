import { apiFetch } from './api'

const MOCK = import.meta.env.VITE_MOCK_API === 'true' || !import.meta.env.VITE_API_URL

export const configService = {
  getDashboardCards: async () => {
    if (MOCK) {
      // Fallback to hardcoded data in mock mode
      const { translations } = await import('../config/translations')
      return translations
    }
    return apiFetch('/config/dashboard')
  },

  getModels: async () => {
    if (MOCK) {
      const { models } = await import('../config/models')
      return models
    }
    return apiFetch('/config/models')
  },

  getPipelines: async () => {
    if (MOCK) {
      const { PIPELINES } = await import('../config/pipelines')
      return PIPELINES
    }
    return apiFetch('/config/pipelines')
  },

  getPipeline: async (type) => {
    if (MOCK) {
      const { getPipeline } = await import('../config/pipelines')
      return getPipeline(type)
    }
    return apiFetch(`/config/pipelines/${type}`)
  },
}

import { create } from 'zustand'
import { configService } from '../services/configService'

const useConfigStore = create((set, get) => ({
  dashboardCards: [],
  models: [],
  pipelines: {},
  isLoading: true,
  error: null,

  fetchConfig: async () => {
    if (!get().isLoading && get().dashboardCards.length > 0) return // already loaded
    set({ isLoading: true, error: null })
    try {
      const [cards, models, pipelines] = await Promise.all([
        configService.getDashboardCards(),
        configService.getModels(),
        configService.getPipelines(),
      ])
      set({
        dashboardCards: cards,
        models,
        pipelines,
        isLoading: false,
      })
    } catch (err) {
      console.error('Failed to fetch config:', err)
      set({ error: err.message, isLoading: false })
    }
  },

  getPipeline: (type) => {
    const { pipelines } = get()
    return pipelines[type] || pipelines['spec-to-code'] || null
  },

  getCardById: (id) => {
    return get().dashboardCards.find((c) => c.id === id) || null
  },
}))

export default useConfigStore

import { create } from 'zustand'
import { promptService } from '../services/promptService'

const useTranslationStore = create((set, get) => ({
  selectedTranslation: null,
  uploadedFile: null,
  selectedModel: 'claude-sonnet-4',
  pipelineType: 'spec-to-code',
  executionMode: 'human',
  contextFiles: [],
  prompts: {},
  isCustomPrompts: false,
  isLoadingPrompts: false,

  setTranslation: (translation) => set({ selectedTranslation: translation }),
  setFile: (file) => set({ uploadedFile: file }),
  setModel: (model) => set({ selectedModel: model }),

  setPipelineType: (type) => {
    set({ pipelineType: type, isLoadingPrompts: true })
    // Fetch user's prompts from backend
    get().fetchPrompts(type)
  },

  setExecutionMode: (mode) => set({ executionMode: mode }),

  addContextFiles: (files) =>
    set((state) => ({
      contextFiles: [...state.contextFiles, ...Array.from(files)],
    })),
  removeContextFile: (index) =>
    set((state) => ({
      contextFiles: state.contextFiles.filter((_, i) => i !== index),
    })),
  clearContextFiles: () => set({ contextFiles: [] }),

  updatePrompt: (step, text) =>
    set((state) => ({
      prompts: { ...state.prompts, [step]: text },
    })),

  // Fetch prompts from backend (per-user, with defaults fallback)
  fetchPrompts: async (pipelineType) => {
    set({ isLoadingPrompts: true })
    try {
      const data = await promptService.getPrompts(pipelineType || get().pipelineType)
      set({
        prompts: data.prompts || {},
        isCustomPrompts: data.isCustom || false,
        isLoadingPrompts: false,
      })
    } catch (err) {
      console.error('Failed to fetch prompts:', err)
      set({ isLoadingPrompts: false })
    }
  },

  // Save user's custom prompts to backend
  savePrompts: async (pipelineType, prompts) => {
    await promptService.savePrompts(pipelineType, prompts)
    set({ isCustomPrompts: true })
  },

  // Reset prompts to system defaults
  resetPrompts: async (pipelineType) => {
    const data = await promptService.resetPrompts(pipelineType)
    set({
      prompts: data.prompts || {},
      isCustomPrompts: false,
    })
  },

  reset: () =>
    set({
      selectedTranslation: null,
      uploadedFile: null,
      selectedModel: 'claude-sonnet-4',
      pipelineType: 'spec-to-code',
      executionMode: 'human',
      contextFiles: [],
      prompts: {},
      isCustomPrompts: false,
      isLoadingPrompts: false,
    }),
}))

export default useTranslationStore

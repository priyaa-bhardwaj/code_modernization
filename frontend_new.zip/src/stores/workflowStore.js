import { create } from 'zustand'
import useConfigStore from './configStore'
import { translationService } from '../services/translationService'

const MOCK =
  import.meta.env.VITE_MOCK_API === 'true' || !import.meta.env.VITE_API_URL

const POLL_INTERVAL_MS = 2000

const createInitialSteps = (pipelineType = 'spec-to-code') => {
  // Try to get from configStore first, fall back to basic defaults
  const configStore = useConfigStore.getState()
  const pipeline = configStore.getPipeline(pipelineType)
  if (pipeline && pipeline.steps) {
    return pipeline.steps.map((name) => ({
      name,
      status: 'pending',
      output: null,
      error: null,
    }))
  }
  // Fallback
  const fallbackSteps = pipelineType === 'code-to-code'
    ? ['Analysis', 'Modernization', 'Reflection']
    : ['Data Loading', 'Modernization', 'Reflection']
  return fallbackSteps.map((name) => ({
    name,
    status: 'pending',
    output: null,
    error: null,
  }))
}

// ---------------------------------------------------------------------------
// Mock data (used only in MOCK mode)
// ---------------------------------------------------------------------------

const mockSpecOutput = `# Specification Document\n\n## Overview\nThis specification describes the complete business logic, data structures,\nand workflows extracted from the source codebase.\n\n## Business Rules\n1. User authentication via session-based tokens\n2. Order processing pipeline with validation stages\n3. Inventory management with real-time stock tracking\n\n## Data Models\n\`\`\`\nUser {\n  id: UUID\n  email: String\n  role: Enum[ADMIN, USER, VIEWER]\n  created_at: DateTime\n}\n\nOrder {\n  id: UUID\n  user_id: FK(User)\n  items: List[OrderItem]\n  status: Enum[PENDING, PROCESSING, COMPLETED, CANCELLED]\n  total: Decimal\n}\n\`\`\`\n\n## API Endpoints\n- POST /api/auth/login\n- GET /api/orders\n- POST /api/orders\n- PUT /api/orders/:id/status\n\n## Integration Points\n- Payment gateway (Stripe)\n- Email service (SendGrid)\n- Logging (ELK Stack)`

const mockAnalysisOutput = `# Code Analysis Report\n\n## Overview\nDeep analysis of the source codebase structure, patterns, dependencies, and control flow.\n\n## Architecture\n- **Pattern**: Monolithic with procedural modules\n- **Entry Point**: Main module with event-driven dispatcher\n- **Data Layer**: Direct database calls via embedded SQL\n\n## Component Inventory\n| Component | Type | Lines | Complexity |\n|-----------|------|-------|------------|\n| AuthModule | Authentication | 340 | Medium |\n| OrderProcessor | Business Logic | 820 | High |\n| InventoryManager | Data Access | 510 | Medium |\n| ReportEngine | Output | 290 | Low |\n\n## Dependencies\n- External DB connector (proprietary)\n- File system I/O for batch processing\n- Socket-based IPC for service communication`

const mockModernizationFiles = {
  'src/main/java/com/codeplus/Application.java': `package com.codeplus.modernized;\n\nimport org.springframework.boot.SpringApplication;\nimport org.springframework.boot.autoconfigure.SpringBootApplication;\n\n@SpringBootApplication\npublic class Application {\n    public static void main(String[] args) {\n        SpringApplication.run(Application.class, args);\n    }\n}`,
  'src/main/java/com/codeplus/controller/OrderController.java': `package com.codeplus.controller;\n\nimport org.springframework.web.bind.annotation.*;\n\n@RestController\n@RequestMapping("/api/orders")\npublic class OrderController {\n    @GetMapping\n    public ResponseEntity<List<Order>> getOrders() {\n        return ResponseEntity.ok(orderService.findAll());\n    }\n}`,
}

const mockReflection = `# Reflection Report\n\n## Coverage Analysis\n✅ All 4 API endpoints implemented\n✅ All data models translated correctly\n✅ Authentication flow preserved\n✅ Order processing pipeline complete\n\n## Code Quality Assessment\n- **Architecture**: Clean layered architecture\n- **Validation**: Input validation via @Valid annotations\n- **Error Handling**: Global exception handler recommended\n\n## Confidence Score: 94%`

const MOCK_OUTPUTS = [null, mockModernizationFiles, mockReflection]

const getStep0Output = (pipelineType) =>
  pipelineType === 'code-to-code' ? mockAnalysisOutput : mockSpecOutput

// ---------------------------------------------------------------------------
// Store
// ---------------------------------------------------------------------------

let _pollTimer = null

const useWorkflowStore = create((set, get) => ({
  jobId: null,
  currentStep: 0,
  steps: createInitialSteps(),
  isGenerating: false,
  isComplete: false,
  executionMode: null,
  pipelineType: null,

  // ----- Polling (real backend) -----

  startPolling: () => {
    const { stopPolling, pollJobStatus } = get()
    stopPolling()
    _pollTimer = setInterval(pollJobStatus, POLL_INTERVAL_MS)
  },

  stopPolling: () => {
    if (_pollTimer) {
      clearInterval(_pollTimer)
      _pollTimer = null
    }
  },

  pollJobStatus: async () => {
    const { jobId, stopPolling } = get()
    if (!jobId) return

    try {
      const data = await translationService.getJobStatus(jobId)
      const isComplete = data.status === 'completed'
      const isFailed = data.status === 'failed'
      const isWaiting = data.status === 'waiting_approval'

      // Map backend step statuses
      const steps = data.steps?.map((s) => ({
        name: s.name,
        status: s.status === 'waiting_approval' ? 'complete' : s.status,
        output: s.output,
        error: s.error,
      })) || get().steps

      set({
        steps,
        currentStep: data.currentStep ?? get().currentStep,
        isGenerating: data.status === 'running',
        isComplete,
      })

      // In HITL mode, when waiting_approval, stop polling — user needs to act
      if (isComplete || isFailed || isWaiting) {
        stopPolling()
      }
    } catch {
      // Silently retry on next interval
    }
  },

  // ----- Start generation -----

  startGeneration: async (jobId, executionMode = 'human', pipelineType = 'spec-to-code') => {
    const steps = createInitialSteps(pipelineType)
    steps[0].status = 'running'
    set({
      jobId,
      currentStep: 0,
      steps,
      isGenerating: true,
      isComplete: false,
      executionMode,
      pipelineType,
    })

    if (!MOCK) {
      // Real backend: start polling — the backend handles everything
      get().startPolling()
      return
    }

    // ----- Mock mode: simulate locally -----
    await new Promise((r) => setTimeout(r, 3000))
    const step0Output = getStep0Output(pipelineType)

    set((state) => {
      const steps = [...state.steps]
      steps[0] = { ...steps[0], status: 'complete', output: step0Output }
      return { steps, isGenerating: false }
    })

    if (executionMode === 'autopilot') {
      for (let i = 1; i < 3; i++) {
        set((state) => {
          const steps = [...state.steps]
          steps[i] = { ...steps[i], status: 'running' }
          return { currentStep: i, steps, isGenerating: true }
        })

        await new Promise((r) => setTimeout(r, 3000))

        const output = i === 1 ? mockModernizationFiles : mockReflection
        set((state) => {
          const steps = [...state.steps]
          steps[i] = { ...steps[i], status: 'complete', output }
          return { steps, isGenerating: false }
        })
      }
      set({ isComplete: true })
    }
  },

  // ----- Approve -----

  approveStep: async (stepIndex) => {
    if (!MOCK) {
      const { jobId } = get()
      await translationService.approveStep(jobId, stepIndex)
      // Restart polling to pick up the next step
      get().startPolling()
      return
    }

    // Mock mode
    if (stepIndex >= 2) {
      set({ isComplete: true })
      return
    }

    const nextIndex = stepIndex + 1
    set((state) => {
      const steps = [...state.steps]
      steps[nextIndex] = { ...steps[nextIndex], status: 'running' }
      return { currentStep: nextIndex, steps, isGenerating: true }
    })

    await new Promise((r) => setTimeout(r, 3000))

    set((state) => {
      const steps = [...state.steps]
      steps[nextIndex] = {
        ...steps[nextIndex],
        status: 'complete',
        output: MOCK_OUTPUTS[nextIndex],
      }
      return { steps, isGenerating: false }
    })
  },

  // ----- Edit output -----

  editStepOutput: (stepIndex, newOutput) => {
    set((state) => {
      const steps = [...state.steps]
      steps[stepIndex] = { ...steps[stepIndex], output: newOutput }
      return { steps }
    })
  },

  editFileInStep: (stepIndex, filePath, newContent) => {
    set((state) => {
      const steps = [...state.steps]
      const output = { ...steps[stepIndex].output, [filePath]: newContent }
      steps[stepIndex] = { ...steps[stepIndex], output }
      return { steps }
    })
  },

  // ----- Reprompt -----

  repromptStep: async (stepIndex, newPrompt) => {
    if (!MOCK) {
      const { jobId } = get()
      set((state) => {
        const steps = [...state.steps]
        steps[stepIndex] = { ...steps[stepIndex], status: 'running', output: null }
        return { steps, isGenerating: true }
      })
      await translationService.repromptStep(jobId, stepIndex, newPrompt)
      // Restart polling
      get().startPolling()
      return
    }

    // Mock mode
    set((state) => {
      const steps = [...state.steps]
      steps[stepIndex] = { ...steps[stepIndex], status: 'running', output: null }
      return { steps, isGenerating: true }
    })

    await new Promise((r) => setTimeout(r, 3000))

    let regeneratedOutput
    if (stepIndex === 1) {
      regeneratedOutput = {
        'src/main/java/com/codeplus/Application.java': `package com.codeplus.modernized;\n\n// Regenerated based on: "${newPrompt}"\n\nimport org.springframework.boot.SpringApplication;\n\n@SpringBootApplication\npublic class Application {\n    public static void main(String[] args) {\n        SpringApplication.run(Application.class, args);\n    }\n}`,
      }
    } else {
      regeneratedOutput = `# Regenerated Output (Step ${stepIndex + 1})\n\nRegenerated based on updated prompt:\n"${newPrompt}"\n\nAll previous concerns have been addressed in this new version.`
    }

    set((state) => {
      const steps = [...state.steps]
      steps[stepIndex] = {
        ...steps[stepIndex],
        status: 'complete',
        output: regeneratedOutput,
      }
      return { steps, isGenerating: false }
    })
  },

  // ----- Reset -----

  reset: () => {
    get().stopPolling()
    set({
      jobId: null,
      currentStep: 0,
      steps: createInitialSteps(),
      isGenerating: false,
      isComplete: false,
      executionMode: null,
      pipelineType: null,
    })
  },
}))

export default useWorkflowStore

/**
 * Translations config — now a thin fallback.
 * Real data comes from GET /api/config/dashboard via configStore.
 */

export const translations = [
  {
    id: 'smalltalk-java-springboot',
    from: 'Smalltalk',
    to: 'Java Spring Boot',
    fromColor: '#3468af',
    toColor: '#6db33f',
    description: 'Migrate Smalltalk applications to modern Java Spring Boot microservices',
  },
  {
    id: 'cobol-python',
    from: 'COBOL',
    to: 'Python',
    fromColor: '#005ca5',
    toColor: '#3776ab',
    description: 'Transform COBOL mainframe programs into clean Python applications',
  },
  {
    id: 'powerbuilder-react',
    from: 'PowerBuilder',
    to: 'React',
    fromColor: '#c62828',
    toColor: '#61dafb',
    description: 'Convert PowerBuilder desktop apps to modern React web applications',
  },
  {
    id: 'vb6-csharp-dotnet',
    from: 'VB6',
    to: 'C# .NET',
    fromColor: '#00539c',
    toColor: '#512bd4',
    description: 'Upgrade Visual Basic 6 projects to C# .NET modern architecture',
  },
  {
    id: 'delphi-typescript',
    from: 'Delphi',
    to: 'TypeScript',
    fromColor: '#ee1f35',
    toColor: '#3178c6',
    description: 'Modernize Delphi applications to TypeScript-based solutions',
  },
  {
    id: 'rpg-nodejs',
    from: 'RPG',
    to: 'Node.js',
    fromColor: '#f5a623',
    toColor: '#339933',
    description: 'Translate IBM RPG programs to scalable Node.js services',
  },
  {
    id: 'fortran-rust',
    from: 'Fortran',
    to: 'Rust',
    fromColor: '#734f96',
    toColor: '#ce422b',
    description: 'Convert high-performance Fortran code to safe, fast Rust',
  },
  {
    id: 'pli-go',
    from: 'PL/I',
    to: 'Go',
    fromColor: '#ff6b35',
    toColor: '#00add8',
    description: 'Migrate PL/I enterprise systems to efficient Go microservices',
  },
]

export const getTranslationById = (id) => translations.find((t) => t.id === id)
